device layer api

Swagger UI: http://localhost:8080/api/swagger-ui.html


Here are the three API projects which were built for the POC:

https://onecode.polycom-labs.com/pholio/logging-analytics/tree/master/DeviceAnalyticsAPI_POC
https://onecode.polycom-labs.com/pholio/logging-analytics/tree/master/LogAPI_POC
https://onecode.polycom-labs.com/pholio/logging-analytics/tree/master/VisualizationAPI_POC
