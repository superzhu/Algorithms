package com.polycom.analytics.device.resources.token;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class VerifyResponseVO implements Serializable  {
    private static final long serialVersionUID = 990881L;

    @JsonProperty(value = "DA_Token")
    private String daToken;
}
