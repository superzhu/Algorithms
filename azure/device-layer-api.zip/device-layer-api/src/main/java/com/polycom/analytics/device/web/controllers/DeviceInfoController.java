package com.polycom.analytics.device.web.controllers;

import com.polycom.analytics.device.exceptions.ValidationFailureException;
import com.polycom.analytics.device.resources.info.AbstractDeviceInfo;
import com.polycom.analytics.device.resources.ResponseVO;
import com.polycom.analytics.device.resources.info.InfoMessage;
import com.polycom.analytics.device.services.geoip2.GeoIPService;
import com.polycom.analytics.device.services.info.DeviceInfoCheckService;
import com.polycom.analytics.device.services.kafka.KafkaProducer;
import com.polycom.analytics.device.services.orion.DeviceIdentityService;
import com.polycom.analytics.device.utils.KafkaTopic;
import com.polycom.analytics.device.utils.RequestConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(consumes = MediaType.APPLICATION_JSON_UTF8_VALUE,produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class DeviceInfoController {
    private final static Logger logger = LoggerFactory.getLogger(DeviceInfoController.class);

    @Autowired
    private DeviceInfoCheckService deviceInfoCheckService;
    @Autowired
    private GeoIPService geoIPService;
    @Autowired
    private KafkaProducer kafkaProducer;

    @Autowired
    private DeviceIdentityService deviceIdentityService;

    @PostMapping(value="/v1.0/deviceanalytics/deviceinfo")
    public ResponseEntity<ResponseVO> uploadDeviceInfo(
            @Valid @RequestBody InfoMessage deviceMessage,
            Errors errors,
            HttpServletRequest request) {
        String realIP = request.getHeader(RequestConstants.REALIP_HEADER_NAME);
        logger.info("uploadDeviceInfo-input json: {},real IP Address: {}", deviceMessage,realIP);

        if (errors.hasErrors()) {
            throw new ValidationFailureException(errors, RequestConstants.DEVICE_INFO_API);
        }
        Optional<ResponseEntity<ResponseVO>> uploadTimeCheck =
                deviceInfoCheckService.verifyDateFormat(deviceMessage.getUploadTime(), RequestConstants.DEVICE_INFO_API);
        if(uploadTimeCheck.isPresent()) {
            //upload time is not valid
            return uploadTimeCheck.get();
        }

       Optional<ResponseEntity<ResponseVO>> verifyResponse = deviceIdentityService.verifyDAToken(request);
        if(verifyResponse.isPresent()) {
            return verifyResponse.get();
        }

        deviceMessage.setIngestionTime(deviceInfoCheckService.getCurrentISO8601Time());
        deviceMessage.setGeoLoc(geoIPService.getGeoLocatioin(realIP));

        String header = deviceMessage.convert();
        String payload = "";
        for(AbstractDeviceInfo info : deviceMessage.getDeviceInfo()) {
            payload = info.convert(header).get(0);

            switch (info.getInfoType()) {
                case RequestConstants.DEVICE_INFO_PRIMARY:
                    kafkaProducer.send(KafkaTopic.DEVICEINFO_PRIMARY,payload);
                    break;
                case RequestConstants.DEVICE_INFO_NETWORK:
                    kafkaProducer.send(KafkaTopic.DEVICEINFO_NETWORK,payload);
                    break;
                case RequestConstants.DEVICE_INFO_HEALTH:
                    kafkaProducer.send(KafkaTopic.DEVICEINFO_HEALTH,payload);
                    break;
                case RequestConstants.DEVICE_INFO_DCR:
                    kafkaProducer.send(KafkaTopic.DEVICEINFO_DCR,payload);
                    break;
                case RequestConstants.DEVICE_INFO_SECONDARY:
                    List<String> attachedDevice = info.convert(header);
                    for(String attached : attachedDevice) {
                        kafkaProducer.send(KafkaTopic.DEVICEINFO_SECONDARY,attached);
                    }
                    break;
                default:
                    logger.error("Input contains unknown device info type : {}",info.getInfoType());
            }
        }

        logger.info("uploadDeviceInfo processed successfully, uploadTime: {},deviceID: {},realIP: {},payload: {}",
                deviceMessage.getUploadTime(),
                deviceMessage.getDeviceID(), realIP,payload);

        ResponseVO response = new ResponseVO(RequestConstants.RESPONSE_SUCCESS,
                RequestConstants.DEVICE_INFO_API);
        return new ResponseEntity<>(response,HttpStatus.OK);
    }
}
