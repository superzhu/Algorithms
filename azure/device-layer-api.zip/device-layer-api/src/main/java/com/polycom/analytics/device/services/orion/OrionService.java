package com.polycom.analytics.device.services.orion;

import com.polycom.analytics.device.services.orion.message.DITTokenResponse;

import java.io.UnsupportedEncodingException;
import java.util.Map;
import java.util.Optional;

public interface OrionService {
    //https://confluence.polycom.com:8443/display/CLOUDP/Inter-Service+Authentication#Inter-ServiceAuthentication-PEC2PolycomExperienceCloudSignaturev2
    String generateToken(String queryString,String serviceId,
                         Map<String, Object> jsonBody,int expireTimeInSeconds,boolean addPrefix) throws UnsupportedEncodingException;

    String generateToken(String serviceId, int expireTimeInSeconds,
                         DITTokenResponse verifyTokenResponse) throws UnsupportedEncodingException;

    boolean isDeviceAnalyticsTokenValid(String daToken);

    DITTokenResponse getDITTokenResponse(String daToken);

    Optional<String> getServiceUrl(String serviceName);
}
