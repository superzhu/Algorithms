package com.polycom.analytics.device.resources.info;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.polycom.analytics.device.utils.JsonConverter;
import com.polycom.analytics.device.utils.RequestConstants;
import lombok.Data;
import org.hibernate.validator.constraints.NotBlank;

import java.util.List;

@Data
@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        include = JsonTypeInfo.As.PROPERTY,
        property = RequestConstants.DEVICE_INFO_TYPE,
        visible = true,
        defaultImpl=UnknownDeviceInfo.class)
@JsonSubTypes({
        @JsonSubTypes.Type(value = PrimaryDeviceInfo.class, name = RequestConstants.DEVICE_INFO_PRIMARY),
        @JsonSubTypes.Type(value = SecondaryDeviceInfo.class, name = RequestConstants.DEVICE_INFO_SECONDARY),
        @JsonSubTypes.Type(value = NetworkInfo.class, name = RequestConstants.DEVICE_INFO_NETWORK),
        @JsonSubTypes.Type(value = DeviceHealthInfo.class, name = RequestConstants.DEVICE_INFO_HEALTH),
        @JsonSubTypes.Type(value = DeviceConfigurationRecord.class, name = RequestConstants.DEVICE_INFO_DCR)
})
public abstract class AbstractDeviceInfo {
    //http://www.baeldung.com/jackson-annotations
    @NotBlank(message = "{deviceinfo.common.infoType.blank}")
    @JsonProperty(value = RequestConstants.DEVICE_INFO_TYPE)
    String infoType;
    String trigger;

    public abstract List<String> convert(String header);

    public void convertSubCommon(StringBuilder builder) {
        JsonConverter.buildStrField(builder,RequestConstants.DEVICE_INFO_TYPE,infoType);
        JsonConverter.buildStrField(builder,"trigger",trigger);
    }
}
