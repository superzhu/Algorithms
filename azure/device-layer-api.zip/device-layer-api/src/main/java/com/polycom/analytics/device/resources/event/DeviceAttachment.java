package com.polycom.analytics.device.resources.event;

import com.fasterxml.jackson.annotation.JsonTypeName;
import com.polycom.analytics.device.utils.JsonConverter;
import com.polycom.analytics.device.utils.RequestConstants;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=true)
@JsonTypeName(RequestConstants.DEVICE_EVENT_ATTACHMENT)
public class DeviceAttachment extends AbstractDeviceEvent{
    private String serialNumber;
    private String version = "1.0";
    private int attachmentState;//0 - detached, 1 - attached

    @Override
    public  String convert(String header) {
        StringBuilder builder = new StringBuilder(header);
        super.convertSubCommon(builder);

        JsonConverter.buildStrField(builder,"attachedSerialNumber",serialNumber);
        JsonConverter.buildStrField(builder,"version",version);
        JsonConverter.buildIntLast(builder,"attachmentState",attachmentState);
        return builder.toString();
    }
}
