package com.polycom.analytics.device.resources;

import lombok.Data;

@Data
public class GeoIP2 {
    //https://www.npmjs.com/package/geoip-lite
    private final static String UNKNOWN = "unknown";

    private int rangeLower;//lower bound of IP block
    private int rangeUpper;
    private double longitude;
    private double latitude;
    private int metro;

    private String city;
    private String postalCode;
    private String region;
    private String country;
    private String realIP;

    public GeoIP2() {
        this.rangeLower = 0;
        this.rangeUpper = 0;
        this.longitude = 0.0;
        this.latitude = 0.0;
        this.metro = 0;

        this.city = UNKNOWN;
        this.postalCode = UNKNOWN;
        this.region = UNKNOWN;
        this.country = UNKNOWN;
        this.realIP = UNKNOWN;
    }
}
