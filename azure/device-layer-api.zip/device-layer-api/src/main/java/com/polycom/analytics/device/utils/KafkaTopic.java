package com.polycom.analytics.device.utils;

public class KafkaTopic {
    //Topics for device information
    public final static String DEVICEINFO_PRIMARY = "DeviceInfo.primaryDeviceInfo";
    public final static String DEVICEINFO_NETWORK= "DeviceInfo.networkInfo";
    public final static String DEVICEINFO_HEALTH= "DeviceInfo.deviceHealthInfo";
    public final static String DEVICEINFO_SECONDARY= "DeviceInfo.attachedDevice";
    public final static String DEVICEINFO_DCR= "DeviceInfo.deviceConfigurationRecord";

    //Topics for device events
    public final static String DE_REGISTRATION = "DeviceEvent.serviceRegistrationStatus";
    public final static String DE_CALL_ERROR = "DeviceEvent.callError";
    public final static String DE_CALL_CONN = "DeviceCallEvent.callConnection";
    public final static String DE_REBOOT = "DeviceEvent.reboot";
    public final static String DE_SERVICE_ISSUE = "DeviceEvent.service";

    public final static String DE_DEVICE_ERROR = "DeviceEvent.deviceError";
    public final static String DE_DEVICE_ATTACHMENT = "DeviceEvent.deviceAttachment";
    public final static String DE_NAVIGATION = "DeviceEvent.navigation";
    public final static String DE_DCR = "DeviceEvent.deviceConfigRecord";
    public final static String DE_CALL_QUALITY = "DeviceEvent.callQuality";

    //Topics for call detail record
    public final static String DEVICE_CDR = "DeviceCDR";
    public final static String DEVICE_LOG_UPLOAD = "DeviceLogUpload";
}
