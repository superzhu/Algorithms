package com.polycom.analytics.device.config;

import com.maxmind.geoip2.DatabaseReader;
import com.polycom.analytics.device.services.geoip2.GeoIPService;
import com.polycom.analytics.device.services.geoip2.GeoIPServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConditionalOnProperty(prefix = MaxmindGeoIP2Properties.PROPERTY_PREFIX, value = { "enabled" }, matchIfMissing = true)
@EnableConfigurationProperties(MaxmindGeoIP2Properties.class)
public class MaxmindGeoIP2Autoconfiguration {
    @Autowired
    private MaxmindGeoIP2Properties properties;

    @Bean
    public DatabaseReader geoIp2CityReader() throws Exception {
        return new DatabaseReader.Builder(properties.getGeolite2CityMmdb().getInputStream()).build();
    }

    @Bean
    public GeoIPService geoIpService() throws Exception {
        return new GeoIPServiceImpl(geoIp2CityReader());
    }
}
