package com.polycom.analytics.device.services.messages;

public interface MessageByLocaleService {
    public String getMessage(String id);
    public String getMessage(String id,Object[] args);
}
