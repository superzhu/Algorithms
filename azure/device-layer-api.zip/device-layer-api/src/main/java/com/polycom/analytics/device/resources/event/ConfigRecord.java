package com.polycom.analytics.device.resources.event;

import com.fasterxml.jackson.annotation.JsonTypeName;
import com.polycom.analytics.device.utils.JsonConverter;
import com.polycom.analytics.device.utils.RequestConstants;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=true)
@JsonTypeName(RequestConstants.DEVICE_EVENT_DCR)
public class ConfigRecord extends AbstractDeviceEvent {
    private String source;
    private String version = "1.0";

    @Override
    public  String convert(String header) {
        StringBuilder builder = new StringBuilder(header);
        super.convertSubCommon(builder);

        JsonConverter.buildStrField(builder,"source",source);
        JsonConverter.buildStrLast(builder,"version",version);
        return builder.toString();
    }
}
