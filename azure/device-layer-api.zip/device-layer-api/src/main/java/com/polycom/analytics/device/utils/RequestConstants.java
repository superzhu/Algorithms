package com.polycom.analytics.device.utils;

public class RequestConstants {
    public final static String HELLO_API = "hello";
    public final static String DEVICE_INFO_API = "deviceinfo";
    public final static String DEVICE_EVENT_API = "deviceevents";
    public final static String DEVICE_CDR_API = "cdrinfo";
    public final static String FILE_UPLOAD_API = "fileupload";
    public final static String FILE_UPLOAD_REQUEST_API = "fileupload request";

    public final static String DEVICE_INFO_TYPE = "infoType";
    public final static String DEVICE_INFO_PRIMARY = "primaryDeviceInfo";
    public final static String DEVICE_INFO_SECONDARY = "secondaryDeviceInfo";
    public final static String DEVICE_INFO_NETWORK = "networkInfo";
    public final static String DEVICE_INFO_HEALTH = "deviceHealthInfo";
    public final static String DEVICE_INFO_DCR = "deviceConfigurationRecord";

    public final static String DEVICE_EVENT_TYPE = "eventType";
    public final static String DEVICE_EVENT_REGISTRATION = "serviceRegistrationStatus";
    public final static String DEVICE_EVENT_INCALL_ERROR = "inCallError";
    public final static String DEVICE_EVENT_CALL_CONN = "callConnection";
    public final static String DEVICE_EVENT_REBOOT = "reboot";

    public final static String DEVICE_EVENT_SERVICE_ISSUE = "serviceIssue";
    public final static String DEVICE_EVENT_DEVICE_ERROR = "deviceError";
    public final static String DEVICE_EVENT_ATTACHMENT = "deviceAttachment";
    public final static String DEVICE_EVENT_NAVIGATION = "uiNavigation";
    public final static String DEVICE_EVENT_DCR = "deviceConfigRecord";

    public final static String DEVICE_EVENT_CALL_QUALITY = "callQuality";

    public final static String REALIP_HEADER_NAME = "x-real-ip";

    public final static String RESPONSE_SUCCESS = "success";

    public final static String DA_TOKEN_HEADER = "Authorization";
}
