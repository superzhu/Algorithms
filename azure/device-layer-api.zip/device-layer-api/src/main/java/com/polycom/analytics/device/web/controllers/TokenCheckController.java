package com.polycom.analytics.device.web.controllers;

import com.polycom.analytics.device.exceptions.ValidationFailureException;
import com.polycom.analytics.device.resources.ResponseVO;
import com.polycom.analytics.device.resources.token.VerifyRequestVO;
import com.polycom.analytics.device.resources.token.VerifyResponseVO;
import com.polycom.analytics.device.services.orion.DeviceIdentityService;
import com.polycom.analytics.device.utils.RequestConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.Objects;
import java.util.Optional;

@RestController
public class TokenCheckController {
	private final static Logger logger = LoggerFactory.getLogger(TokenCheckController.class);

    @Autowired
    private DeviceIdentityService deviceIdentityService;

	@ResponseBody
	@RequestMapping(value="/hello",method = RequestMethod.GET)
    public ResponseEntity<ResponseVO> hello(HttpServletRequest request) {
        logger.debug("TokenCheckController, checking... ");

        Optional<ResponseEntity<ResponseVO>> verifyResponse = deviceIdentityService.verifyDAToken(request);
        if(verifyResponse.isPresent()) {
            return verifyResponse.get();
        } else {
            ResponseVO response = new ResponseVO(RequestConstants.RESPONSE_SUCCESS,
                    RequestConstants.HELLO_API);
            return new ResponseEntity<>(response,HttpStatus.OK);
        }
    }

    @ResponseBody
    @PostMapping(value="/v1.0/deviceanalytics/verify",
            consumes = MediaType.APPLICATION_JSON_UTF8_VALUE,
            produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<VerifyResponseVO> verifyDITToken(
            @Valid @RequestBody VerifyRequestVO verifyRequest,
            Errors errors,
            HttpServletRequest request) {
        if (errors.hasErrors()) {
            throw new ValidationFailureException(errors, RequestConstants.DEVICE_INFO_API);
        }


	    return  deviceIdentityService.verifyDITToken(verifyRequest.getDit());
    }
}
