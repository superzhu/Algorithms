package com.polycom.analytics.device.services.storage;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class UploadLogDto {
    private final static Logger logger = LoggerFactory.getLogger(UploadLogDto.class);
    @Getter
    private String fileID;

    @Getter
    private String fileType;

    @Getter
    private String deviceID;

    @Getter
    private String compress;

    @Getter
    private String compressionAlgorithm;

    @Getter
    private String trigger;

    @Getter
    @Setter
    private String ingestionTime;

    @Getter
    @Setter
    private String path;

    @Getter
    @Setter
    private String serialNumber;

    @Getter
    @Setter
    private String macAddress;

    @Getter
    @Setter
    private String tenantId;

    @Getter
    private String version = "1.0";

    public UploadLogDto(String fileID,String fileType,
                        String deviceID,String compress,
                        String compressionAlgorithm,
                        String trigger) {
        this.fileID = fileID;
        this.fileType = fileType;
        this.deviceID = deviceID;
        this.compress = compress;
        this.compressionAlgorithm = compressionAlgorithm;

        this.trigger = trigger;
    }

    public String convert() {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            String payload = objectMapper.writeValueAsString(this);
            return payload;
        } catch(Exception ex) {
            logger.error("UploadLogDto conversion get error {}",ex.getMessage());
        }

        return null;
    }
}
