package com.polycom.analytics.device.services.dm.message;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import lombok.Data;

import java.util.Map;

@Data
@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        include = JsonTypeInfo.As.PROPERTY,
        property = CommandTrigger.COMMAND_TYPE,
        visible = true)
@JsonSubTypes({
        @JsonSubTypes.Type(value = SendInfo.class, name = CommandTrigger.COMTYPE_SENDINFO)
})
public abstract class AbstractMessageToDevice {
    String commandType;

    abstract Map<String, Object> getMap();
}