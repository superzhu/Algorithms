package com.polycom.analytics.device.services.info;

import com.polycom.analytics.device.resources.ResponseVO;
import org.springframework.http.ResponseEntity;

import java.util.Optional;

public interface DeviceInfoCheckService {
    public Optional<ResponseEntity<ResponseVO>> verifyDateFormat(String datetime, String apiName);

    public String getCurrentISO8601Time();
}
