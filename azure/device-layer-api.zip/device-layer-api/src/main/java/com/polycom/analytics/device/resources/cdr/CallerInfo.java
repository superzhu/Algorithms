package com.polycom.analytics.device.resources.cdr;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CallerInfo {
    private String name;
    private String origEndpoint;
    private String startTime;
    private String endTime;
    private String callDuration;

    private String billingPhoneNumber;
    private String endpointTransportAddress;
}
