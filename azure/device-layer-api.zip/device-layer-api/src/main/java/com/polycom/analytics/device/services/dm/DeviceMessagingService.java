package com.polycom.analytics.device.services.dm;

import com.polycom.analytics.device.services.dm.message.CommandWrapper;
import org.springframework.http.ResponseEntity;

public interface DeviceMessagingService {
    /*
     * The method is for the purpose of sending a command to the Orion Device Proxy
     * interface in order to ask a device to upload configuration info. The URL
     * exposed by Orion is like below:
     * https://api-orion-dev3.plcm.cloud/api/v1.0/device-proxy-client/${deviceID}+'?
     * tid='+${tenantID}
     */
    public ResponseEntity sendDeviceInfo(CommandWrapper commandWrapper);
}
