package com.polycom.analytics.device.resources;

import lombok.Data;

import java.io.Serializable;

@Data
public class ResponseVO implements Serializable{
    private static final long serialVersionUID = -90881L;

    private String result;
    private String api;

    public ResponseVO(String result, String api) {
        this.result = result;
        this.api = api;
    }
}
