package com.polycom.analytics.device.resources.event;

public class UnknownDeviceEvent extends AbstractDeviceEvent{
    @Override
    public String convert(String header) {
        return null;
    }
}
