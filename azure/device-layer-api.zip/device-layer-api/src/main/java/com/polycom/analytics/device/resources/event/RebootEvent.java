package com.polycom.analytics.device.resources.event;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.polycom.analytics.device.utils.JsonConverter;
import com.polycom.analytics.device.utils.RequestConstants;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=true)
@JsonTypeName(RequestConstants.DEVICE_EVENT_REBOOT)
public class RebootEvent extends AbstractDeviceEvent{
    private String rebootType;
    @JsonProperty(value = "Description")
    private String description;
    private String username;
    private String version = "1.0";

    @Override
    public  String convert(String header) {
        StringBuilder builder = new StringBuilder(header);
        super.convertSubCommon(builder);

        JsonConverter.buildStrField(builder,"rebootType",rebootType);
        JsonConverter.buildStrField(builder,"Description",description);
        JsonConverter.buildStrField(builder,"username",username);
        JsonConverter.buildStrLast(builder,"version",version);

        return builder.toString();
    }
}
