package com.polycom.analytics.device.utils;

public class MessageKeys {
    public final static String UPLOADTIME_FORMAT_ERROR = "deviceinfo.header.uploadtime.format.error";
    public final static String UPLOADTIME_RANGE_ERROR = "deviceinfo.header.uploadtime.range.error";
    public final static String CLIENT_AUTH_ERROR = "analitics.client.auth.error";
}
