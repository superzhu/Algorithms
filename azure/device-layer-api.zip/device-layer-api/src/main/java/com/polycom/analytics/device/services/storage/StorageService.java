package com.polycom.analytics.device.services.storage;

import com.polycom.analytics.device.services.orion.message.DITTokenResponse;
import org.springframework.web.multipart.MultipartFile;

public interface StorageService {
    void store(MultipartFile file,UploadLogDto logDto);
}
