package com.polycom.analytics.device.services.geoip2;

import com.maxmind.geoip2.DatabaseReader;
import com.maxmind.geoip2.exception.GeoIp2Exception;
import com.maxmind.geoip2.model.CityResponse;
import com.polycom.analytics.device.resources.GeoIP2;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class GeoIPServiceImpl implements  GeoIPService{
    private DatabaseReader reader;

    public GeoIPServiceImpl(DatabaseReader geoIpDatabaseReader) {
        this.reader = geoIpDatabaseReader;
    }

    @Override
    public CityResponse cityResponse(InetAddress inetAddress) {
        try {
            return reader.city(inetAddress);
        } catch (IOException e) {

        } catch (GeoIp2Exception e) {
        }
        return null;
    }

    @Override
    public CityResponse cityResponse(String ipAddress) {
        InetAddress inetAddress;
        try {
            inetAddress = InetAddress.getByName(ipAddress);
            return cityResponse(inetAddress);
        } catch (UnknownHostException e) {
        }
        return null;
    }

    @Override
    public GeoIP2 getGeoLocatioin(String ipAddress) {
        GeoIP2 geo = new GeoIP2();

        if(ipAddress != null) {
            CityResponse response = cityResponse(ipAddress);
            geo.setRealIP(ipAddress);

            if(response != null) {
                if(response.getLocation() != null) {
                    if(response.getLocation().getLatitude() != null) {
                        geo.setLatitude(response.getLocation().getLatitude());
                    }
                    if(response.getLocation().getLongitude() != null) {
                        geo.setLongitude(response.getLocation().getLongitude());
                    }
                    if(response.getLocation().getMetroCode() != null) {
                        geo.setMetro(response.getLocation().getMetroCode());
                    }
                }

                if(response.getCity()!=null &&
                        response.getCity().getName() != null) {
                    geo.setCity(response.getCity().getName());
                }

                if(response.getPostal() != null &&
                        response.getPostal().getCode() != null) {
                    geo.setPostalCode(response.getPostal().getCode());
                }

                if(response.getCountry() != null &&
                        response.getCountry().getIsoCode()!=null) {
                    //response.getCountry().getName()
                    geo.setCountry(response.getCountry().getIsoCode());
                }
                if(response.getMostSpecificSubdivision() != null &&
                        response.getMostSpecificSubdivision().getIsoCode()!=null) {
                    geo.setRegion(response.getMostSpecificSubdivision().getIsoCode());
                }
            }
        }

        return geo;
    }
}
