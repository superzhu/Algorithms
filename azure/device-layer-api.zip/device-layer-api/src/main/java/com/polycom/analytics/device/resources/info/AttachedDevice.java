package com.polycom.analytics.device.resources.info;

import com.polycom.analytics.device.utils.JsonConverter;
import lombok.Data;
import org.hibernate.validator.constraints.NotBlank;

import java.util.Objects;

@Data
public class AttachedDevice {
    private String connectionType;
    @NotBlank(message = "{secondaryinfo.attached.serialNumber.blank}")
    private String serialNumber;
    private String macAddress;
    private String peripheralType;
    private String displayName;

    private String wifiAddress;
    private String bluetoothAddress;
    private String powerSource;
    private String deviceSignature;
    private int attachmentState;

    private String pcPortStatus;
    private String pcPortSpeed;
    private String pcPortMode;
    private String fingerprint;
    private String version = "1.0";

    public void convert(StringBuilder builder) {
        builder.append(JsonConverter.LEFT_BRACE).append(JsonConverter.DOUBLE_QUOT);

        if (Objects.nonNull(connectionType)) {
            JsonConverter.buildStrField(builder,"connectionType",connectionType);
        }
        if (Objects.nonNull(serialNumber)) {
            JsonConverter.buildStrField(builder,"serialNumber",serialNumber);
        }
        if (Objects.nonNull(macAddress)) {
            JsonConverter.buildStrField(builder,"macAddress",macAddress);
        }
        if (Objects.nonNull(peripheralType)) {
            JsonConverter.buildStrField(builder,"peripheralType",peripheralType);
        }
        if (Objects.nonNull(displayName)) {
            JsonConverter.buildStrField(builder,"displayName",displayName);
        }

        if (Objects.nonNull(wifiAddress)) {
            JsonConverter.buildStrField(builder,"wifiAddress",wifiAddress);
        }
        if (Objects.nonNull(bluetoothAddress)) {
            JsonConverter.buildStrField(builder,"bluetoothAddress",bluetoothAddress);
        }
        if (Objects.nonNull(powerSource)) {
            JsonConverter.buildStrField(builder,"powerSource",powerSource);
        }
        if (Objects.nonNull(deviceSignature)) {
            JsonConverter.buildStrField(builder,"deviceSignature",deviceSignature);
        }
        JsonConverter.buildIntField(builder,"attachmentState",attachmentState);

        if (Objects.nonNull(pcPortStatus)) {
            JsonConverter.buildStrField(builder,"pcPortStatus",pcPortStatus);
        }
        if (Objects.nonNull(pcPortSpeed)) {
            JsonConverter.buildStrField(builder,"pcPortSpeed",pcPortSpeed);
        }
        if (Objects.nonNull(pcPortMode)) {
            JsonConverter.buildStrField(builder,"pcPortMode",pcPortMode);
        }
        if (Objects.nonNull(fingerprint)) {
            JsonConverter.buildStrField(builder, "fingerprint", fingerprint);
        }
        JsonConverter.buildStrLast(builder, "version", version);
    }
}
