package com.polycom.analytics.device.resources.cdr;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CallExperienceSummary {
    private String audioProtocolTx;
    private String audioProtocolRx;
    private String videoProtocolTx;
    private String videoProtocolRx;
    private String videoFormatTx;

    private String videoFormatRx;
    private String precedenceLevel;
    private Integer peopleMins;
    private Integer peopleCountCallBegin;
    private Integer peopleCountPeakValue;

    private Integer peopleCountCallEnd;
    private Integer totalH320Errors;
    private Integer avgPercentPacketLossTx;
    private Integer avgPercentPacketLossRx;
    private Integer avgPacketsLostTx;

    private Integer avgPacketsLostRx;
    private Integer avgLatencyTx;
    private Integer avgLatencyRx;
    private Integer maxLatencyTx;
    private Integer maxLatencyRx;

    private Integer avgJitterTx;
    private Integer avgJitterRx;
    private Integer maxJitterTx;
    private Integer maxJitterRx;
}
