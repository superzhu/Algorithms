package com.polycom.analytics.device.resources.info;

import com.fasterxml.jackson.annotation.JsonTypeName;
import com.polycom.analytics.device.utils.JsonConverter;
import com.polycom.analytics.device.utils.RequestConstants;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper=true)
@JsonTypeName(RequestConstants.DEVICE_INFO_PRIMARY)
public class PrimaryDeviceInfo extends AbstractDeviceInfo {
    private String manufacturer;
    private String productFamily;
    private String hardwareModel;
    private String hardwareRevision;
    private String hardwarePN;

    private String softwareRelease;
    private String updaterVersion;
    private String powerSource;
    private String deviceSignature;
    private String offsetGMT;

    private String fingerprint;
    private String version = "1.0";

    @Override
    public List<String> convert(String header) {
        StringBuilder builder = new StringBuilder(header);
        super.convertSubCommon(builder);

        JsonConverter.buildStrField(builder,"manufacturer",manufacturer);
        JsonConverter.buildStrField(builder,"productFamily",productFamily);
        JsonConverter.buildStrField(builder,"hardwareModel",hardwareModel);
        JsonConverter.buildStrField(builder,"hardwareRevision",hardwareRevision);
        JsonConverter.buildStrField(builder,"hardwarePN",hardwarePN);

        JsonConverter.buildStrField(builder,"softwareRelease",softwareRelease);
        JsonConverter.buildStrField(builder,"updaterVersion",updaterVersion);
        JsonConverter.buildStrField(builder,"powerSource",powerSource);
        JsonConverter.buildStrField(builder,"deviceSignature",deviceSignature);
        JsonConverter.buildStrField(builder,"offsetGMT",offsetGMT);

        JsonConverter.buildStrField(builder,"fingerprint",fingerprint);
        JsonConverter.buildStrLast(builder,"version",version);

        ArrayList<String> list = new ArrayList<>();
        list.add( builder.toString() );
        return list;
    }
}
