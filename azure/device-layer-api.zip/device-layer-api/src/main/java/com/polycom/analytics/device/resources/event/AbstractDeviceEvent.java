package com.polycom.analytics.device.resources.event;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.polycom.analytics.device.utils.JsonConverter;
import com.polycom.analytics.device.utils.RequestConstants;
import lombok.Data;
import org.hibernate.validator.constraints.NotBlank;

@Data
@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        include = JsonTypeInfo.As.PROPERTY,
        property = RequestConstants.DEVICE_EVENT_TYPE,
        visible = true,
        defaultImpl=UnknownDeviceEvent.class)
@JsonSubTypes({
        @JsonSubTypes.Type(value = ServiceRegistration.class, name = RequestConstants.DEVICE_EVENT_REGISTRATION),
        @JsonSubTypes.Type(value = InCallError.class, name = RequestConstants.DEVICE_EVENT_INCALL_ERROR),
        @JsonSubTypes.Type(value = CallConnection.class, name = RequestConstants.DEVICE_EVENT_CALL_CONN),
        @JsonSubTypes.Type(value = RebootEvent.class, name = RequestConstants.DEVICE_EVENT_REBOOT),
        @JsonSubTypes.Type(value = ServiceIssue.class, name = RequestConstants.DEVICE_EVENT_SERVICE_ISSUE),
        @JsonSubTypes.Type(value = DeviceError.class, name = RequestConstants.DEVICE_EVENT_DEVICE_ERROR),
        @JsonSubTypes.Type(value = DeviceAttachment.class, name = RequestConstants.DEVICE_EVENT_ATTACHMENT),
        @JsonSubTypes.Type(value = UiNavigation.class, name = RequestConstants.DEVICE_EVENT_NAVIGATION),
        @JsonSubTypes.Type(value = ConfigRecord.class, name = RequestConstants.DEVICE_EVENT_DCR),
        @JsonSubTypes.Type(value = CallQuality.class, name = RequestConstants.DEVICE_EVENT_CALL_QUALITY)
} )
public abstract class AbstractDeviceEvent {
    @NotBlank(message = "{deviceevent.common.eventType.blank}")
    @JsonProperty(value = RequestConstants.DEVICE_EVENT_TYPE)
    String eventType;
    @NotBlank(message = "{deviceevent.common.eventTime.blank}")
    String eventTime;

    public abstract String convert(String header);

    public void convertSubCommon(StringBuilder builder) {
        JsonConverter.buildStrField(builder,RequestConstants.DEVICE_EVENT_TYPE,eventType);
        JsonConverter.buildStrField(builder,"eventTime",eventTime);
    }
}
