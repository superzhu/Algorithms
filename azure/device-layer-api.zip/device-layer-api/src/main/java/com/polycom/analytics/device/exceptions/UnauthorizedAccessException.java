package com.polycom.analytics.device.exceptions;


public class UnauthorizedAccessException extends RuntimeException {
    private static final long serialVersionUID = -9091L;

    public UnauthorizedAccessException() {
    }

    public UnauthorizedAccessException(String message, Throwable cause) {
        super(message, cause);
    }

    public UnauthorizedAccessException(String message) {
        super(message);
    }

    public UnauthorizedAccessException(Throwable cause) {
        super(cause);
    }
}
