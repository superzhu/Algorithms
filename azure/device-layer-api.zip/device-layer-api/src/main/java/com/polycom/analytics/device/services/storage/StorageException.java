package com.polycom.analytics.device.services.storage;

public class StorageException extends RuntimeException {
    private static final long serialVersionUID = -966771L;

    public StorageException(String message) {
        super(message);
    }

    public StorageException(String message, Throwable cause) {
        super(message, cause);
    }
}
