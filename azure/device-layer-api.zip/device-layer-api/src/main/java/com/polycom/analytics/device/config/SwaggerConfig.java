package com.polycom.analytics.device.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * @author Zhu Zhi
 * Date : 2018/01/16
 */
@Configuration
@Profile("dev")
@EnableSwagger2
public class SwaggerConfig {
    @Value("${ra.contact.name}")
    private String contactName;

    @Value("${ra.contact.url}")
    private String contactURL;

    @Value("${ra.contact.email}")
    private String contactEmail;

    @Bean
    public Docket api() {
        return new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(getApiInfo())
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.polycom.analytics.web.controllers"))
                .paths(PathSelectors.any())
                .build();
    }

    private ApiInfo getApiInfo() {
        Contact contact = new Contact(contactName, contactURL,contactEmail);
        return new ApiInfoBuilder()
                .title("Polycom RA Device API")
                .description("Polycom RA Device API")
                .version("1.0.0")
                .contact(contact)
                .build();
    }
}
