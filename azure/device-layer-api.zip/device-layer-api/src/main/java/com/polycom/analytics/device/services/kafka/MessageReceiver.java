package com.polycom.analytics.device.services.kafka;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.polycom.analytics.device.services.dm.DeviceMessagingService;
import com.polycom.analytics.device.services.dm.message.CommandWrapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MessageReceiver {
    private static final Logger logger = LoggerFactory.getLogger(MessageReceiver.class);

    @Autowired
    private DeviceMessagingService deviceMessagingService;

    @KafkaListener(topics = "${kafka.topic.MessageToDevice}", containerFactory = "kafkaListenerContainerFactory")
    public void listenMessages(@Payload List<String> messages,
                           @Header(KafkaHeaders.RECEIVED_PARTITION_ID) List<Integer> partitions,
                           @Header(KafkaHeaders.OFFSET) List<Long> offsets) {
        logger.info("MessageReceiver: start of batch receive");
        for(int i=0; i< messages.size(); i++) {
            String messageToDevice = messages.get(i);
            int partition = partitions.get(i);
            long offset = offsets.get(i);
            try {
                CommandWrapper commandWrapper = new ObjectMapper().readValue(messageToDevice,CommandWrapper.class);
                ResponseEntity response = deviceMessagingService.sendDeviceInfo(commandWrapper);
                logger.info("MessageReceiver: Kafka message: {}, Converted Java Object {}, response status code: {}",
                        messageToDevice,commandWrapper.toString(),response.getStatusCode());
            } catch(Exception ee) {
                logger.error("MessageReceiver: Message: {} from Partition: {} Offset: {} Cause exception: {}",
                        messageToDevice, partition, offset, ee.getMessage() );
            }
        }
        logger.info("MessageReceiver: end of batch receive");
    }
}
