package com.polycom.analytics.device.services.dm.message;

public class CommandTrigger {
    public static final String CT_SERVICE_REGISTRATION = "serviceRegistrationStatus";
    public static final String CT_REBOOT = "rebootEvent";
    public static final String CT_DEVICE_ERROR = "deviceError";
    public static final String CT_DEVICE_ATTACHMENT = "deviceAttachmentEvent";

    public static final String COMMAND_TYPE = "commandType";
    public static final String COMTYPE_SENDINFO = "sendInfo";
}
