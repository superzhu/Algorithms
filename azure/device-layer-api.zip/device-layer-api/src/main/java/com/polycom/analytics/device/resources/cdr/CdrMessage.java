package com.polycom.analytics.device.resources.cdr;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.polycom.analytics.device.resources.GeoIP2;
import lombok.Data;
import org.hibernate.validator.constraints.NotBlank;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.validation.constraints.NotNull;
import java.util.Optional;

/**
 * Call Detail Message (CDR)
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CdrMessage {
    private final static Logger logger = LoggerFactory.getLogger(CdrMessage.class);

    @NotBlank(message = "{deviceinfo.header.messageType.blank}")
    private String messageType;
    @NotBlank(message = "{deviceinfo.header.uploadTime.blank}")
    private String uploadTime;
    @NotBlank(message = "{deviceinfo.header.deviceID.blank}")
    private String deviceID;
    private String siteID;
    private String roomID;

    @NotBlank(message = "{deviceinfo.header.tenantID.blank}")
    private String tenantID;
    @NotBlank(message = "{deviceinfo.header.organizationID.blank}")
    private String organizationID;
    @NotBlank(message = "{deviceinfo.header.macAddress.blank}")
    private String macAddress;
    @NotBlank(message = "{deviceinfo.header.serialNumber.blank}")
    private String serialNumber;

    @NotNull(message = "{cdr.call.details.blank}")
    private CallDetails callDetails;
    @NotNull(message = "{cdr.caller.info.blank}")
    private CallerInfo CallerInfo;
    @NotNull(message = "{cdr.callee.info.blank}")
    private CalleeInfo calleeInfo;
    @NotNull(message = "{cdr.call.experience.summary.blank}")
    private CallExperienceSummary callExperienceSummary;

    private String ingestionTime;
    private String realIP;
    private String version = "1.0";

    public Optional<String> convert() {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            String json = objectMapper.writeValueAsString(this);
            return Optional.of(json);
        } catch (JsonProcessingException jpe) {
            logger.error("Object Serialization error: {}",jpe.getMessage());
            return Optional.empty();
        }
    }
}
