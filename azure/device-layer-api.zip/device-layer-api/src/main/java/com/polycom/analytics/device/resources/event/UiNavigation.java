package com.polycom.analytics.device.resources.event;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.polycom.analytics.device.utils.JsonConverter;
import com.polycom.analytics.device.utils.RequestConstants;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.validation.Valid;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper=true)
@JsonTypeName(RequestConstants.DEVICE_EVENT_NAVIGATION)
public class UiNavigation extends AbstractDeviceEvent{
    private final static Logger logger = LoggerFactory.getLogger(UiNavigation.class);
    @Valid
    private List<KeyPress> keyPresses;

    @Override
    public  String convert(String header) {
        StringBuilder builder = new StringBuilder(header);
        super.convertSubCommon(builder);
        if(keyPresses == null) {
            builder.deleteCharAt(builder.length() - 1);
            builder.deleteCharAt(builder.length() - 1);
        } else {
            builder.append("keyPresses").append(JsonConverter.DOUBLE_QUOT);
            builder.append(JsonConverter.COLON);

            ObjectMapper objectMapper = new ObjectMapper();
            //objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
            try {
                String arrayToJson = objectMapper.writeValueAsString(keyPresses);
                builder.append(arrayToJson);
            } catch(Exception ex) {
                logger.error("keyPresses conversion get error {}",ex.getMessage());
            }
        }

        builder.append(JsonConverter.RIGHT_BRACE);
        return builder.toString();
    }
}
