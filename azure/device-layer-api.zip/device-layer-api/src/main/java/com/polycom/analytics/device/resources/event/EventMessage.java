package com.polycom.analytics.device.resources.event;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.polycom.analytics.device.resources.GeoIP2;
import com.polycom.analytics.device.utils.JsonConverter;
import lombok.Data;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.Valid;
import java.util.List;

/**
 * Device Event Message
 */
@Data
public class EventMessage {
    @NotBlank(message = "{deviceinfo.header.messageType.blank}")
    private String messageType;
    @NotBlank(message = "{deviceinfo.header.uploadTime.blank}")
    private String uploadTime;
    @NotBlank(message = "{deviceinfo.header.deviceID.blank}")
    private String deviceID;
    private String siteID;
    private String roomID;

    @NotBlank(message = "{deviceinfo.header.tenantID.blank}")
    private String tenantID;
    @NotBlank(message = "{deviceinfo.header.organizationID.blank}")
    private String organizationID;
    @NotBlank(message = "{deviceinfo.header.macAddress.blank}")
    private String macAddress;
    @NotBlank(message = "{deviceinfo.header.serialNumber.blank}")
    private String serialNumber;

    private EventFingerPrints fingerprints;
    @NotEmpty(message = "failure - no device event records to process")
    @JsonProperty(value = "deviceEvents")
    @Valid
    private List<AbstractDeviceEvent> events;
    @JsonIgnore
    private String ingestionTime;
    @JsonIgnore
    private GeoIP2 geoLoc;

    public String convert() {
        StringBuilder builder = new StringBuilder();
        builder.append(JsonConverter.LEFT_BRACE).append(JsonConverter.DOUBLE_QUOT);

        JsonConverter.buildStrField(builder,"messageType",messageType);
        JsonConverter.buildStrField(builder,"uploadTime",uploadTime);
        JsonConverter.buildStrField(builder,"deviceID",deviceID);
        JsonConverter.buildStrField(builder,"siteID",siteID);
        JsonConverter.buildStrField(builder,"roomID",roomID);

        JsonConverter.buildStrField(builder,"tenantID",tenantID);
        JsonConverter.buildStrField(builder,"organizationID",organizationID);
        JsonConverter.buildStrField(builder,"macAddress",macAddress);
        JsonConverter.buildStrField(builder,"serialNumber",serialNumber);
        if(fingerprints != null) {
            fingerprints.convert(builder);
        }

        JsonConverter.buildStrField(builder,"ingestionTime",ingestionTime);
        //GeoIP2
        /*JsonConverter.buildIntField(builder,"rangeLower",geoLoc.getRangeLower());
        JsonConverter.buildIntField(builder,"rangeUpper",geoLoc.getRangeUpper());
        JsonConverter.buildDoubleField(builder,"longitude",geoLoc.getLongitude());
        JsonConverter.buildDoubleField(builder,"latitude",geoLoc.getLatitude());
        JsonConverter.buildIntField(builder,"metro",geoLoc.getMetro());

        JsonConverter.buildStrField(builder,"city",geoLoc.getCity());
        JsonConverter.buildStrField(builder,"postalCode",geoLoc.getPostalCode());
        JsonConverter.buildStrField(builder,"region",geoLoc.getRegion());
        JsonConverter.buildStrField(builder,"country",geoLoc.getCountry());*/
        JsonConverter.buildStrField(builder,"realIP",geoLoc.getRealIP());

        return builder.toString();
    }
}
