package com.polycom.analytics.device.utils;

import java.util.List;

public class JsonConverter {
    public static String LEFT_BRACE = "{";
    public static String RIGHT_BRACE = "}";
    public static String LEFT_SQUARE = "[";
    public static String RIGHT_SQUARE = "]";
    public static String DOUBLE_QUOT = "\""; //left double quotation mark
    public static String COLON = ":";
    public static String COMMA = ",";
    public static String DOUBLE_COLON = "\":\"";
    public static String DOUBLE_COMMA = "\",\"";
    public static String EMPTY = "";

    public static void buildStrField(StringBuilder builder,String fieldName,String fieldValue) {
        builder.append(fieldName).append(DOUBLE_COLON);
        if(fieldValue == null) {
            builder.append(EMPTY).append(DOUBLE_COMMA);
        } else {
            builder.append(fieldValue).append(DOUBLE_COMMA);
        }
    }

    public static void buildStrLast(StringBuilder builder,String fieldName,String fieldValue) {
        builder.append(fieldName).append(DOUBLE_COLON);
        if(fieldValue == null) {
            builder.append(EMPTY).append(DOUBLE_QUOT).append(RIGHT_BRACE);
        } else {
            builder.append(fieldValue).append(DOUBLE_QUOT).append(RIGHT_BRACE);
        }
    }

    public static void buildSListStrField(StringBuilder builder,String fieldName,
                                          List<String> fieldValue) {
        builder.append(fieldName).append(DOUBLE_QUOT).append(COLON).append(LEFT_SQUARE);
        if(fieldValue == null || fieldValue.isEmpty()) {
            //do nothing
        } else {
            for(String value : fieldValue) {
                builder.append(DOUBLE_QUOT).append(value);
                builder.append(DOUBLE_QUOT).append(COMMA);
            }

            builder.deleteCharAt(builder.length() - 1);
        }

        builder.append(RIGHT_SQUARE).append(COMMA).append(DOUBLE_QUOT);
    }

    public static void buildIntField(StringBuilder builder,String fieldName,int fieldValue) {
        builder.append(fieldName).append(DOUBLE_QUOT).append(COLON);
        builder.append(fieldValue).append(COMMA).append(DOUBLE_QUOT);
    }

    public static void buildIntLast(StringBuilder builder,String fieldName,int fieldValue) {
        builder.append(fieldName).append(DOUBLE_QUOT).append(COLON);
        builder.append(fieldValue).append(RIGHT_BRACE);
    }

    public static void buildDoubleField(StringBuilder builder,String fieldName,double fieldValue) {
        builder.append(fieldName).append(DOUBLE_QUOT).append(COLON);
        builder.append(fieldValue).append(COMMA).append(DOUBLE_QUOT);
    }
}
