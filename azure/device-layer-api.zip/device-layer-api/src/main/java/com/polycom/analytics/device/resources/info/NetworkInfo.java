package com.polycom.analytics.device.resources.info;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.polycom.analytics.device.utils.JsonConverter;
import com.polycom.analytics.device.utils.RequestConstants;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Data
@EqualsAndHashCode(callSuper=true)
@JsonTypeName(RequestConstants.DEVICE_INFO_NETWORK)
public class NetworkInfo extends AbstractDeviceInfo {
    private String connectionType;
    private String ipv4Address;
    private String ipv4Subnet;
    private String ipv4Gateway;
    private String ipv4VLAN;

    private String ipv4AddressSource;
    private String ipv6GlobalAddress;
    private String ipv6LinkLocalAddress;
    private String ipv6AddressSource;
    private String ipv6ULA;

    private String dnsPrimaryAddress;
    private String dnsAlternativeAddress;
    private String dnsDomain;
    private String connectionSpeed;
    private String pcPortStatus;

    private String lldpStatus;
    private String lldpNeighbors;
    private String lldpLocationInformation;
    private String cdpStatus;
    @JsonProperty(value = "802.1xStatus")
    private String x802Status;

    private String ntpServer;
    private String eapMethod;
    private String provisioningProtocol;
    private String connectionMode;
    private String fingerprint;

    private String version = "1.0";

    @Override
    public List<String> convert(String header) {
        StringBuilder builder = new StringBuilder(header);
        super.convertSubCommon(builder);

        JsonConverter.buildStrField(builder,"connectionType",connectionType);
        if (Objects.nonNull(ipv4Address)) {
            JsonConverter.buildStrField(builder,"ipv4Address",ipv4Address);
        }
        if (Objects.nonNull(ipv4Subnet)) {
            JsonConverter.buildStrField(builder,"ipv4Subnet",ipv4Subnet);
        }
        if (Objects.nonNull(ipv4Gateway)) {
            JsonConverter.buildStrField(builder,"ipv4Gateway",ipv4Gateway);
        }
        if (Objects.nonNull(ipv4VLAN)) {
            JsonConverter.buildStrField(builder,"ipv4VLAN",ipv4VLAN);
        }

        if (Objects.nonNull(ipv4AddressSource)) {
            JsonConverter.buildStrField(builder,"ipv4AddressSource",ipv4AddressSource);
        }
        if (Objects.nonNull(ipv6GlobalAddress)) {
            JsonConverter.buildStrField(builder,"ipv6GlobalAddress",ipv6GlobalAddress);
        }
        if (Objects.nonNull(ipv6LinkLocalAddress)) {
            JsonConverter.buildStrField(builder,"ipv6LinkLocalAddress",ipv6LinkLocalAddress);
        }
        if (Objects.nonNull(ipv6AddressSource)) {
            JsonConverter.buildStrField(builder,"ipv6AddressSource",ipv6AddressSource);
        }
        if (Objects.nonNull(ipv6ULA)) {
            JsonConverter.buildStrField(builder,"ipv6ULA",ipv6ULA);
        }

        if (Objects.nonNull(dnsPrimaryAddress)) {
            JsonConverter.buildStrField(builder,"dnsPrimaryAddress",dnsPrimaryAddress);
        }
        if (Objects.nonNull(dnsAlternativeAddress)) {
            JsonConverter.buildStrField(builder,"dnsAlternativeAddress",dnsAlternativeAddress);
        }
        if (Objects.nonNull(dnsDomain)) {
            JsonConverter.buildStrField(builder,"dnsDomain",dnsDomain);
        }
        if (Objects.nonNull(connectionSpeed)) {
            JsonConverter.buildStrField(builder,"connectionSpeed",connectionSpeed);
        }
        if (Objects.nonNull(pcPortStatus)) {
            JsonConverter.buildStrField(builder,"pcPortStatus",pcPortStatus);
        }

        if (Objects.nonNull(lldpStatus)) {
            JsonConverter.buildStrField(builder,"lldpStatus",lldpStatus);
        }
        if (Objects.nonNull(lldpNeighbors)) {
            JsonConverter.buildStrField(builder,"lldpNeighbors",lldpNeighbors);
        }
        if (Objects.nonNull(lldpLocationInformation)) {
            lldpLocationInformation = lldpLocationInformation.replace("\n", "").replace("\r", "");
            if (Objects.nonNull(lldpLocationInformation)) {
                lldpLocationInformation = lldpLocationInformation.trim();
            }

            if (Objects.nonNull(lldpLocationInformation)) {
                JsonConverter.buildStrField(builder,"lldpLocationInformation",lldpLocationInformation.trim());
            }
        }
        if (Objects.nonNull(cdpStatus)) {
            JsonConverter.buildStrField(builder,"cdpStatus",cdpStatus);
        }
        if (Objects.nonNull(x802Status)) {
            JsonConverter.buildStrField(builder,"802.1xStatus",x802Status);
        }

        if (Objects.nonNull(ntpServer)) {
            JsonConverter.buildStrField(builder,"ntpServer",ntpServer);
        }
        if (Objects.nonNull(eapMethod)) {
            JsonConverter.buildStrField(builder,"eapMethod",eapMethod);
        }
        if (Objects.nonNull(provisioningProtocol)) {
            JsonConverter.buildStrField(builder,"provisioningProtocol",provisioningProtocol);
        }
        if (Objects.nonNull(connectionMode)) {
            JsonConverter.buildStrField(builder,"connectionMode",connectionMode);
        }
        if (Objects.nonNull(fingerprint)) {
            JsonConverter.buildStrField(builder,"fingerprint",fingerprint);
        }

        JsonConverter.buildStrLast(builder,"version",version);

        ArrayList<String> list = new ArrayList<>();
        list.add( builder.toString() );
        return list;
    }
}
