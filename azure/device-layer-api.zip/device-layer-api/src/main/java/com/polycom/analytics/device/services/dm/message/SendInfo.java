package com.polycom.analytics.device.services.dm.message;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.HashMap;
import java.util.Map;

/**
 * Represent sendInfo command
 */
@Data
@EqualsAndHashCode(callSuper=true)
public class SendInfo extends AbstractMessageToDevice {
    private String infoType;
    private String trigger;
    private String serialNumber;
    private String deviceID;
    private String tenantID;

    public SendInfo() {
    }

    public SendInfo(String infoType, String trigger,
                    String serialNo,String deviceID, String tenantID) {
        super();
        this.commandType = CommandTrigger.COMTYPE_SENDINFO;
        this.infoType = infoType;
        this.serialNumber = serialNo;
        this.trigger = trigger;

        this.deviceID = deviceID;
        this.tenantID = tenantID;
    }

    @Override
    public Map<String, Object> getMap() {
        Map<String, Object> bodyVal = new HashMap<>();
        bodyVal.put("commandType", CommandTrigger.COMTYPE_SENDINFO);
        bodyVal.put("infoType", infoType);
        bodyVal.put("trigger", trigger);
        bodyVal.put("serialNumber", serialNumber);

        return bodyVal;
    }
}
