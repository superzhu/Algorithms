package com.polycom.analytics.device.services.kafka;

import lombok.Data;

@Data
public class Car {
    private String make;
    private String manufacturer;
    private int id;

    @Override
    public String toString() {
        return "Car [make=" + make + ", manufacturer=" + manufacturer + ", id=" + id + "]";
    }
}
