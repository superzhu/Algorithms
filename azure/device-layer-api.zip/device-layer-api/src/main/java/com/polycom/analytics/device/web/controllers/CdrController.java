package com.polycom.analytics.device.web.controllers;

import com.polycom.analytics.device.exceptions.ValidationFailureException;
import com.polycom.analytics.device.resources.ResponseVO;
import com.polycom.analytics.device.resources.cdr.CdrMessage;
import com.polycom.analytics.device.services.geoip2.GeoIPService;
import com.polycom.analytics.device.services.info.DeviceInfoCheckService;
import com.polycom.analytics.device.services.kafka.KafkaProducer;
import com.polycom.analytics.device.services.orion.DeviceIdentityService;
import com.polycom.analytics.device.utils.KafkaTopic;
import com.polycom.analytics.device.utils.RequestConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.Optional;

@RestController
@RequestMapping(value = "/v1.0/deviceanalytics",
        consumes = MediaType.APPLICATION_JSON_UTF8_VALUE,
        produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class CdrController {
    private final static Logger logger = LoggerFactory.getLogger(CdrController.class);

    @Autowired
    private DeviceIdentityService deviceIdentityService;
    @Autowired
    private DeviceInfoCheckService deviceInfoCheckService;
    @Autowired
    private GeoIPService geoIPService;
    @Autowired
    private KafkaProducer kafkaProducer;

    @PostMapping(value="/devicecdr")
    public ResponseEntity<ResponseVO> uploadCdrMessage(
            @Valid @RequestBody CdrMessage cdrMessage,
            Errors errors,
            HttpServletRequest request) {
        String realIP = request.getHeader(RequestConstants.REALIP_HEADER_NAME);
        logger.info("uploadCdrMessage-input json: {},real IP Address: {}", cdrMessage,realIP);

        if (errors.hasErrors()) {
            throw new ValidationFailureException(errors, RequestConstants.DEVICE_CDR_API);
        }
        Optional<ResponseEntity<ResponseVO>> verifyResponse = deviceIdentityService.verifyDAToken(request);
        if(verifyResponse.isPresent()) {
            return verifyResponse.get();
        }

        Optional<ResponseEntity<ResponseVO>> uploadTimeCheck =
                deviceInfoCheckService.verifyDateFormat(cdrMessage.getUploadTime(), RequestConstants.DEVICE_CDR_API);
        if(uploadTimeCheck.isPresent()) {
            return uploadTimeCheck.get();
        }

        cdrMessage.setIngestionTime(deviceInfoCheckService.getCurrentISO8601Time());
        cdrMessage.setRealIP(realIP);
        //cdrMessage.setGeoLoc(geoIPService.getGeoLocatioin(realIP));

        Optional<String> payload = cdrMessage.convert();
        if(payload.isPresent()) {
            kafkaProducer.send(KafkaTopic.DEVICE_CDR,payload.get());
        } else {
            logger.error("CdrMessage has serialization error, check log : {}",cdrMessage);
        }

        ResponseVO response = new ResponseVO(RequestConstants.RESPONSE_SUCCESS,
                RequestConstants.DEVICE_CDR_API);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
