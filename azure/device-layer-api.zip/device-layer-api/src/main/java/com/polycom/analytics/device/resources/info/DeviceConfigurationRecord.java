package com.polycom.analytics.device.resources.info;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.polycom.analytics.device.utils.JsonConverter;
import com.polycom.analytics.device.utils.RequestConstants;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Data
@EqualsAndHashCode(callSuper=true)
@JsonTypeName(RequestConstants.DEVICE_INFO_DCR)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DeviceConfigurationRecord extends AbstractDeviceInfo {
    private String fingerprint;
    private String version = "1.0";
    private Map<String,String> configs;

    @Override
    public List<String> convert(String header) {
        StringBuilder builder = new StringBuilder(header);
        super.convertSubCommon(builder);

        if(!CollectionUtils.isEmpty(configs)) {
            configs.forEach(
                    (key,value) -> {
                        JsonConverter.buildStrField(builder,key,value);
                    }
            );
        }

        JsonConverter.buildStrField(builder,"fingerprint",fingerprint);
        JsonConverter.buildStrLast(builder,"version",version);

        ArrayList<String> list = new ArrayList<>();
        list.add( builder.toString() );
        return list;
    }
}
