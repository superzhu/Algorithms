package com.polycom.analytics.device.config;

import java.io.IOException;

import org.apache.http.client.HttpClient;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.DefaultHttpRequestRetryHandler;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.ResponseErrorHandler;
import org.springframework.web.client.RestTemplate;

@Configuration
public class HttpClientConfiguration {
	@Value("${resttemplate.read_timeout}")
	private int readTimeout;
	@Value("${resttemplate.conn_timeout}")
	private int connTimeout; 

	@Bean
	public RestTemplate restTemplate() {
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.setErrorHandler( new ResponseErrorHandler() {

			@Override
			public boolean hasError(ClientHttpResponse response) throws IOException {
				if(!response.getStatusCode().is2xxSuccessful()) {
					return true;
				}
				return false;
			}

			@Override
			public void handleError(ClientHttpResponse response) throws IOException {
			}	
		}
	   );
		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
		restTemplate.setRequestFactory(clientHttpRequestFactory());
		return restTemplate;
	}
	
    private ClientHttpRequestFactory clientHttpRequestFactory() {
		//Orion Service Timeout value: 10 seconds
		RequestConfig config = RequestConfig.custom()
				.setCookieSpec(CookieSpecs.STANDARD)
				.setConnectionRequestTimeout(connTimeout)
				.setConnectTimeout(connTimeout)
				.setSocketTimeout(readTimeout)
				.build();

		HttpClientBuilder builder = HttpClientBuilder.create()
				.setDefaultRequestConfig(config)
				.setRetryHandler(new DefaultHttpRequestRetryHandler(2, false));
		HttpClient httpClient = builder.build();

        HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory(httpClient);
        return factory;
    }
}
