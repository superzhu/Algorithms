package com.polycom.analytics.device.resources.cdr;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CallDetails {
    private String dialString;
    private String callDirection;
    private String transportType;
    private Integer callRate;
    private String contentDuration;

    private String disconnectInfo;
    private Integer causeQ850;
    private String callUUID;
    private String conferenceUUID;
}
