package com.polycom.analytics.device.web.interceptors;

import com.polycom.analytics.device.exceptions.ValidationFailureException;
import com.polycom.analytics.device.resources.ResponseVO;
import com.polycom.analytics.device.services.storage.StorageException;
import com.polycom.analytics.device.utils.RequestConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.stream.Collectors;

@ControllerAdvice
public class ExceptionControllerAdvice {
    private final Logger logger = LoggerFactory.getLogger(getClass());

    @ExceptionHandler(ValidationFailureException.class)
    public ResponseEntity<ResponseVO> validationException(ValidationFailureException ve) {
        String errorMessage = ve.getErrors().getAllErrors()
                .stream()
                .map(x -> x.getDefaultMessage())
                .collect(Collectors.joining(",") );

        logger.error("Validation Exception occured: " + errorMessage );

        ResponseVO response = new ResponseVO(errorMessage,ve.getApiName());
        return new ResponseEntity<ResponseVO>(response, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(StorageException.class)
    public ResponseEntity<ResponseVO> validationException(StorageException ve) {
        String errorMessage = ve.getMessage();

        ResponseVO response = new ResponseVO(errorMessage, RequestConstants.FILE_UPLOAD_API);
        return new ResponseEntity<ResponseVO>(response, HttpStatus.BAD_REQUEST);
    }
}
