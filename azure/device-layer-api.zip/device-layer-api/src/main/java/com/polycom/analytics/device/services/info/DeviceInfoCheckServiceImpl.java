package com.polycom.analytics.device.services.info;

import com.polycom.analytics.device.services.messages.MessageByLocaleService;
import com.polycom.analytics.device.resources.ResponseVO;
import com.polycom.analytics.device.utils.MessageKeys;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoField;
import java.util.Date;
import java.util.Optional;

@Component
public class DeviceInfoCheckServiceImpl implements DeviceInfoCheckService{
    private static final long ONE_DAY = 86400;
    private static final long ONE_HOUR = 3600;

    private static final DateTimeFormatter offsetZFormatter;
    private static final DateTimeFormatter noSpaceFormatter;
    static {
        offsetZFormatter = new DateTimeFormatterBuilder()
                .append(DateTimeFormatter.ISO_LOCAL_DATE_TIME)
                .appendOffset("+HHMM", "Z")
                .parseCaseInsensitive()
                .toFormatter();

        noSpaceFormatter =  new DateTimeFormatterBuilder()
                .parseCaseInsensitive()
                .append(DateTimeFormatter.ISO_LOCAL_DATE)
                .appendLiteral('T')
                .appendValue(ChronoField.HOUR_OF_DAY, 2)
                .appendLiteral(':')
                .appendValue(ChronoField.MINUTE_OF_HOUR, 2)
                .optionalStart()
                .appendLiteral(':')
                .appendValue(ChronoField.SECOND_OF_MINUTE, 2)
                .appendOffset("+HHMM", "Z")
                .toFormatter();
    }

    @Autowired
    MessageByLocaleService messageByLocaleService;

    /**
     * @param datetime format : 2018-02-09T12:39:37+0530 (ISO 8601 format)
     */
    @Override
    public Optional<ResponseEntity<ResponseVO>> verifyDateFormat(String datetime, String apiName) {
        OffsetDateTime inputDateTime;

        try {
            inputDateTime = OffsetDateTime.parse(datetime,offsetZFormatter);
        } catch (DateTimeParseException pe) {
            Object[] args = new Object[]{datetime};
            return createEntity(MessageKeys.UPLOADTIME_FORMAT_ERROR,args,apiName);
        }

        OffsetDateTime current = OffsetDateTime.now();
        Duration duration = Duration.between(current,inputDateTime);
        long diff = duration.getSeconds();

        //Only allow timestamps that are within 1 hour ahead of server time
        // must be within 24 hours of the server time
        if((diff > 0 && diff > ONE_HOUR) ||
                (diff < 0 && Math.abs(diff) > ONE_DAY)) {
            Object[] args = new Object[]{Math.abs(diff)/ONE_HOUR};
            return createEntity(MessageKeys.UPLOADTIME_RANGE_ERROR,args,apiName);
        }
        return Optional.empty();
    }


    private Optional<ResponseEntity<ResponseVO>> createEntity (
            String messageKey,
            Object[] args,String apiName ) {
        String timeFormatError = messageByLocaleService.getMessage(messageKey,args);

        ResponseVO response = new ResponseVO(timeFormatError,apiName);
        ResponseEntity<ResponseVO> entity =
                new ResponseEntity<ResponseVO>(response, HttpStatus.BAD_REQUEST);
        return Optional.of(entity);
    }

    @Override
    public String getCurrentISO8601Time() {
       /* OffsetDateTime current = OffsetDateTime.now();
        return noSpaceFormatter.format(current);*/

        final Date now = new Date();
        final DateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
        final String nowString = format.format(now);
        return  nowString;
    }
}
