package com.polycom.analytics.device.resources.info;

import java.util.ArrayList;
import java.util.List;

public class UnknownDeviceInfo extends AbstractDeviceInfo {
    @Override
    public List<String> convert(String header) {
        ArrayList<String> list = new ArrayList<>();
        list.add( "" );
        return list;
    }
}
