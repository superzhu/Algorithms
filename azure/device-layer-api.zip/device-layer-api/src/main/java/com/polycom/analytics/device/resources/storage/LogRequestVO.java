package com.polycom.analytics.device.resources.storage;

import lombok.Data;
import org.hibernate.validator.constraints.NotBlank;

@Data
public class LogRequestVO {
    @NotBlank(message = "{file.upload.filetype.blank}")
    private String fileType;

    @NotBlank(message = "{deviceinfo.header.deviceID.blank}")
    private String deviceID;
}
