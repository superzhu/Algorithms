package com.polycom.analytics.device.resources.event;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.polycom.analytics.device.utils.JsonConverter;
import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EventFingerPrints {
    private final static Logger logger = LoggerFactory.getLogger(EventFingerPrints.class);

    private String primaryDeviceInfo;
    //@JsonIgnore
    private Map<String,String> secondaryDeviceInfo;
    private String networkInfo;
    private String deviceConfigRecord;
    private String version = "1.0";

    @SuppressWarnings("unchecked")
    @JsonProperty("secondaryDeviceInfo")
    private void unpackNested(List<Map<String,String>> secondarys) {
        if(!secondarys.isEmpty()) {
            secondaryDeviceInfo = new HashMap<String,String>();
            for(Map<String,String> entryMap : secondarys) {
                entryMap.forEach((key,value) -> secondaryDeviceInfo.put(key,value));
            }
        }
    }

    public void convert(StringBuilder builder) {
        ObjectMapper objectMapper = new ObjectMapper();
        builder.append("fingerprints").append(JsonConverter.DOUBLE_QUOT).append(JsonConverter.COLON);
        try {
            String arrayToJson = objectMapper.writeValueAsString(this);
            builder.append(arrayToJson);
        } catch(Exception ex) {
            logger.error("EventFingerPrints conversion get error {}",ex.getMessage());
        }

        builder.append(JsonConverter.COMMA);
        builder.append(JsonConverter.DOUBLE_QUOT);//used for next field
    }
}
