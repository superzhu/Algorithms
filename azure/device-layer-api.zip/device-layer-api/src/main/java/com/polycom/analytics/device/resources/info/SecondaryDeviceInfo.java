package com.polycom.analytics.device.resources.info;

import com.fasterxml.jackson.annotation.JsonTypeName;
import com.polycom.analytics.device.utils.JsonConverter;
import com.polycom.analytics.device.utils.RequestConstants;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper=true)
@JsonTypeName(RequestConstants.DEVICE_INFO_SECONDARY)
public class SecondaryDeviceInfo extends AbstractDeviceInfo {
    @NotEmpty(message = "failure - no attached device of Secondary Device Info to process")
    @Valid
    private List<AttachedDevice> attachedDevices;

    @Override
    public List<String> convert(String header) {
        //Each attached device generates a separate Kafka message
        ArrayList<String> list = new ArrayList<>();

        for(AttachedDevice attached : attachedDevices) {
            StringBuilder builder = new StringBuilder(header);
            super.convertSubCommon(builder);

            builder.append("attachedDevice");
            builder.append(JsonConverter.DOUBLE_QUOT).append(JsonConverter.COLON);
            attached.convert(builder);
            builder.append(JsonConverter.RIGHT_BRACE);
            list.add( builder.toString() );
        }

        return list;
    }
}
