package com.polycom.analytics.device.resources.token;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.hibernate.validator.constraints.NotBlank;

@Data
public class VerifyRequestVO {
    @NotBlank(message = "{analitics.client.dit.blank}")
    @JsonProperty(value = "DIT")
    private String dit;
}
