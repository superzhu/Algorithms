package com.polycom.analytics.device.resources.event;

import com.fasterxml.jackson.annotation.JsonTypeName;
import com.polycom.analytics.device.utils.JsonConverter;
import com.polycom.analytics.device.utils.RequestConstants;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=true)
@JsonTypeName(RequestConstants.DEVICE_EVENT_DEVICE_ERROR)
public class DeviceError extends AbstractDeviceEvent {
    private String message;
    private String severity;
    private String version = "1.0";

    @Override
    public  String convert(String header) {
        StringBuilder builder = new StringBuilder(header);
        super.convertSubCommon(builder);

        JsonConverter.buildStrField(builder,"message",message);
        JsonConverter.buildStrField(builder,"severity",severity);
        JsonConverter.buildStrLast(builder,"version",version);
        return builder.toString();
    }
}
