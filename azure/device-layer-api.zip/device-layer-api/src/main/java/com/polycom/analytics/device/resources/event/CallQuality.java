package com.polycom.analytics.device.resources.event;

import com.fasterxml.jackson.annotation.JsonTypeName;
import com.polycom.analytics.device.utils.JsonConverter;
import com.polycom.analytics.device.utils.RequestConstants;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=true)
@JsonTypeName(RequestConstants.DEVICE_EVENT_CALL_QUALITY)
public class CallQuality extends AbstractDeviceEvent {
    private String serviceName;
    private int serviceID;
    private String serverAddress;
    private String callID;
    private int lossRate;

    private int discardRate;
    private int rFactor;
    private String username;
    private String version = "1.0";

    @Override
    public  String convert(String header) {
        StringBuilder builder = new StringBuilder(header);
        super.convertSubCommon(builder);

        JsonConverter.buildStrField(builder,"serviceName",serviceName);
        JsonConverter.buildIntField(builder,"serviceID",serviceID);
        JsonConverter.buildStrField(builder,"serverAddress",serverAddress);
        JsonConverter.buildStrField(builder,"callID",callID);
        JsonConverter.buildIntField(builder,"lossRate",lossRate);

        JsonConverter.buildIntField(builder,"discardRate",discardRate);
        JsonConverter.buildIntField(builder,"rFactor",rFactor);
        JsonConverter.buildStrField(builder,"username",username);
        JsonConverter.buildStrLast(builder,"version",version);
        return builder.toString();
    }
}
