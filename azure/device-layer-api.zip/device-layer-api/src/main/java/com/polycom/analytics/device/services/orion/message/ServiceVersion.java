package com.polycom.analytics.device.services.orion.message;

import lombok.Data;

@Data
public class ServiceVersion {
    private String version;
    private String transport;
    private String url;
}
