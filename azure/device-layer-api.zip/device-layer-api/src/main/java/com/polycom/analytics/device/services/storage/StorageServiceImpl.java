package com.polycom.analytics.device.services.storage;

import com.polycom.analytics.device.services.kafka.KafkaProducer;
import com.polycom.analytics.device.services.orion.message.DITTokenResponse;
import com.polycom.analytics.device.utils.KafkaTopic;
import org.apache.commons.io.FilenameUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Date;
import java.util.Objects;

@Service
public class StorageServiceImpl implements StorageService {
    private static final Logger logger = LoggerFactory.getLogger(StorageServiceImpl.class);

    private static final String PARENT_FOLDER = "..";
    private static final String ROOT_PATH = "/";
    private static final String UNDERSCORE = "_";
    private static final String FIELD_SEPARATOR = ".";
    private final Path rootLocation;

    @Value("${hdfs.prefix}")
    private String hdfsPrefix;

    @Value("${hdfs.user}")
    private String hdfsUser;

    @Value("${hdfs.fs.defaultSchema}")
    private String hdfsDefaultSchema;

    @Value("${hdfs.dfs.nameservices}")
    private String dfsNameServices;

    @Value("${hdfs.dfs.ha.namenode1}")
    private String namenode1;

    @Value("${hdfs.dfs.ha.namenode2}")
    private String namenode2;

    @Value("${hdfs.dfs.namenode.rpc-address1}")
    private String rpcAddress1;

    @Value("${hdfs.dfs.namenode.rpc-address2}")
    private String rpcAddress2;

    private Configuration conf;

    @Autowired
    private KafkaProducer kafkaProducer;

    @Autowired
    public StorageServiceImpl() {
        rootLocation = Paths.get(System.getProperty("java.io.tmpdir"));
    }

    private Configuration configure() {
        //Set HADOOP user
        System.setProperty("HADOOP_USER_NAME", hdfsUser);
        //to avoid exception log
        System.setProperty("hadoop.home.dir", ROOT_PATH);

        if( Objects.isNull(conf)) {
            conf = new Configuration(true);
            conf.set("fs.defaultFS", hdfsDefaultSchema + dfsNameServices);
            conf.set("dfs.nameservices", dfsNameServices);
            conf.set("dfs.ha.namenodes."+ dfsNameServices, namenode1 + "," + namenode2);
            conf.set("dfs.namenode.rpc-address."+ dfsNameServices+ "." + namenode2, rpcAddress2);
            conf.set("dfs.namenode.rpc-address."+ dfsNameServices+ "." + namenode1, rpcAddress1);

            conf.set("dfs.client.failover.proxy.provider." + dfsNameServices,
                    "org.apache.hadoop.hdfs.server.namenode.ha.ConfiguredFailoverProxyProvider");
        }
        return conf;
    }

    @Override
    public void store(MultipartFile file,UploadLogDto logDto) {
        String filename = StringUtils.cleanPath(file.getOriginalFilename());
        if (file.isEmpty()) {
            throw new StorageException("Failed to store empty file:" + filename);
        }
        if (filename.contains(PARENT_FOLDER)) {
            String securityCheck = "Cannot store file with relative path outside current directory:" +filename;
            throw new StorageException(securityCheck);
        }

        File localTargetFile = new File(System.getProperty("java.io.tmpdir"), filename);
        try{
            file.transferTo(localTargetFile);
        } catch (IOException e) {
            logger.error("Locally storing file: {} gets exception: {}",filename,e.getMessage());
            throw new StorageException("Failed to store file:" + filename, e);
        }

        final float fileSize = localTargetFile.length()/65536;
        OffsetDateTime current = OffsetDateTime.now(ZoneOffset.UTC);
        String hdfsPath = formHDFSFilename(logDto,current,filename);
        try( FileSystem fs = FileSystem.get(configure());
             FileInputStream fis = new FileInputStream(localTargetFile);
             FSDataOutputStream out = fs.create(new org.apache.hadoop.fs.Path(hdfsPath),true)) {

            IOUtils.copyBytes(fis, out, 4096, true);
            logger.info("local file: {} is uploaded into HDFS: {}",
                    localTargetFile.getAbsolutePath(),hdfsPath);
        } catch (IOException e) {
            logger.error("Uploading file: {} gets exception: {}",filename,e.getMessage());
            throw new StorageException("Failed to store file:" + filename, e);
        }

        localTargetFile.delete();

        logDto.setIngestionTime(getDateString(current));
        logDto.setPath(hdfsPath);
        String payload = logDto.convert();
        if(Objects.nonNull(payload)) {
            kafkaProducer.send(KafkaTopic.DEVICE_LOG_UPLOAD,payload);
        }
    }

    private String formHDFSFilename(UploadLogDto logDto,OffsetDateTime current,String filename) {
        String extension = FilenameUtils.getExtension(filename);

        StringBuilder builder = new StringBuilder(hdfsPrefix);
        builder.append(ROOT_PATH);
        builder.append(hdfsUser);
        builder.append(ROOT_PATH);
        builder.append(logDto.getFileType());

        builder.append(ROOT_PATH);
        builder.append(current.getYear());
        builder.append(ROOT_PATH);
        int month = current.getMonth().getValue();
        if(month < 10) {
            builder.append("0");
        }
        builder.append(month);
        builder.append(ROOT_PATH);
        int dayOfMonth = current.getDayOfMonth();
        if(dayOfMonth < 10) {
            builder.append("0");
        }
        builder.append(dayOfMonth);

        builder.append(ROOT_PATH);
        builder.append(logDto.getFileID());
        builder.append(FIELD_SEPARATOR);

        if(Objects.nonNull(extension)) {
            builder.append(extension);
        } else {
            builder.append(logDto.getFileType());
        }

        return builder.toString();
    }

    private String getDateString(OffsetDateTime current) {
        long epochMilli = current.toInstant().toEpochMilli();
        Date date = new Date(epochMilli);

        final DateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
        final String nowString = format.format(date);
        return  nowString;
    }
}
