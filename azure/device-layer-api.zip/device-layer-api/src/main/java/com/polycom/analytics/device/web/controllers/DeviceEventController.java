package com.polycom.analytics.device.web.controllers;

import com.polycom.analytics.device.exceptions.ValidationFailureException;
import com.polycom.analytics.device.resources.ResponseVO;
import com.polycom.analytics.device.resources.event.AbstractDeviceEvent;
import com.polycom.analytics.device.resources.event.EventMessage;
import com.polycom.analytics.device.services.geoip2.GeoIPService;
import com.polycom.analytics.device.services.info.DeviceInfoCheckService;
import com.polycom.analytics.device.services.kafka.KafkaProducer;
import com.polycom.analytics.device.services.orion.DeviceIdentityService;
import com.polycom.analytics.device.utils.KafkaTopic;
import com.polycom.analytics.device.utils.RequestConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.Optional;

@RestController
@RequestMapping(consumes = MediaType.APPLICATION_JSON_UTF8_VALUE,produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class DeviceEventController {
    private final static Logger logger = LoggerFactory.getLogger(DeviceEventController.class);

    @Autowired
    private DeviceInfoCheckService deviceInfoCheckService;
    @Autowired
    private GeoIPService geoIPService;
    @Autowired
    private KafkaProducer kafkaProducer;

    @Autowired
    private DeviceIdentityService deviceIdentityService;

    @PostMapping(value="/v1.0/deviceanalytics/deviceevents")
    public ResponseEntity<ResponseVO> uploadDeviceEvents(
            @Valid @RequestBody EventMessage deviceEvent,
            Errors errors,
            HttpServletRequest request) {
        String realIP = request.getHeader(RequestConstants.REALIP_HEADER_NAME);
        logger.info("uploadDeviceEvents-input json: {},real IP Address: {}", deviceEvent,realIP);

        if (errors.hasErrors()) {
            throw new ValidationFailureException(errors, RequestConstants.DEVICE_EVENT_API);
        }

        Optional<ResponseEntity<ResponseVO>> uploadTimeCheck =
                deviceInfoCheckService.verifyDateFormat(deviceEvent.getUploadTime(), RequestConstants.DEVICE_EVENT_API);
        if(uploadTimeCheck.isPresent()) {
            logger.error("uploadTime validation error: {}",uploadTimeCheck.get());
            return uploadTimeCheck.get();
        }

        Optional<ResponseEntity<ResponseVO>> verifyResponse = deviceIdentityService.verifyDAToken(request);
        if(verifyResponse.isPresent()) {
            return verifyResponse.get();
        }

        deviceEvent.setIngestionTime(deviceInfoCheckService.getCurrentISO8601Time());
        deviceEvent.setGeoLoc(geoIPService.getGeoLocatioin(realIP));

        String header = deviceEvent.convert();
        String payload = "";
        for(AbstractDeviceEvent event : deviceEvent.getEvents()) {
            payload = event.convert(header);

            switch (event.getEventType()) {
                case RequestConstants.DEVICE_EVENT_REGISTRATION:
                    kafkaProducer.send(KafkaTopic.DE_REGISTRATION, payload);
                    break;
                case RequestConstants.DEVICE_EVENT_INCALL_ERROR:
                    kafkaProducer.send(KafkaTopic.DE_CALL_ERROR, payload);
                    break;
                case RequestConstants.DEVICE_EVENT_CALL_CONN:
                    kafkaProducer.send(KafkaTopic.DE_CALL_CONN, payload);
                    break;
                case RequestConstants.DEVICE_EVENT_REBOOT:
                    kafkaProducer.send(KafkaTopic.DE_REBOOT, payload);
                    break;
                case RequestConstants.DEVICE_EVENT_SERVICE_ISSUE:
                    //event type 5
                    kafkaProducer.send(KafkaTopic.DE_SERVICE_ISSUE, payload);
                    break;
                case RequestConstants.DEVICE_EVENT_DEVICE_ERROR:
                    kafkaProducer.send(KafkaTopic.DE_DEVICE_ERROR, payload);
                    break;
                case RequestConstants.DEVICE_EVENT_ATTACHMENT:
                    kafkaProducer.send(KafkaTopic.DE_DEVICE_ATTACHMENT, payload);
                    break;
                case RequestConstants.DEVICE_EVENT_NAVIGATION:
                    kafkaProducer.send(KafkaTopic.DE_NAVIGATION, payload);
                    break;
                case RequestConstants.DEVICE_EVENT_DCR:
                    kafkaProducer.send(KafkaTopic.DE_DCR, payload);
                    break;
                case RequestConstants.DEVICE_EVENT_CALL_QUALITY:
                    kafkaProducer.send(KafkaTopic.DE_CALL_QUALITY, payload);
                    break;
                default:
                    logger.error("Input contains unknown event type: {}", event.getEventType());
            }
        }

        ResponseVO response = new ResponseVO(RequestConstants.RESPONSE_SUCCESS,
                RequestConstants.DEVICE_EVENT_API);
        return new ResponseEntity<>(response,HttpStatus.OK);
    }
}
