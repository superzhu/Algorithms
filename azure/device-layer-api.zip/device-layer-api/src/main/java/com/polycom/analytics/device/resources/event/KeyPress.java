package com.polycom.analytics.device.resources.event;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class KeyPress {
    private String keyName;
    private String timestamp;
    private String version = "1.0";
}
