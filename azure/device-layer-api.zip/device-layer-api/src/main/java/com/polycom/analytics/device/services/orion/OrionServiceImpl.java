package com.polycom.analytics.device.services.orion;

import com.polycom.analytics.device.services.orion.message.DITTokenResponse;
import com.polycom.analytics.device.services.orion.message.OrionServiceVO;
import com.polycom.analytics.device.services.orion.message.OrionServicesVO;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.impl.TextCodec;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

@Service
public class OrionServiceImpl implements OrionService {
    private static final Logger logger = LoggerFactory.getLogger(OrionServiceImpl.class);
    private static final String APP_NAME = "Device Analytics";
    private static final String TOKEN_TYPE = "typ";
    private static final String TOKEN_ALG = "alg";

    private static final String SERIAL_NUMBER = "serialNumber";
    private static final String MAC_ADDRESS = "macAddress";
    private static final String DEVICE_ID = "deviceId";
    private static final String TENANT_ID = "tenantId";

    @Value("${deviceanalytics.appId}")
    private String appId;// appId for Device Analyrics Service

    @Value("${deviceanalytics.secret}")
    private  String secret;// secret for Device Analyrics Service

    @Value("${deviceanalytics.authHeaderPrefix}")
    private String authHeaderPrefix;

    @Value("${globaldirectory.base_url}")
    private String globalDirectoryURL;

    private volatile OrionServicesVO orionServicesVO;

    @Autowired
    private RestTemplate restTemplate;

    private String encodedSecret;

    private String getEncodedSecret() {
        if(Objects.isNull(encodedSecret)) {
            encodedSecret = TextCodec.BASE64.encode(secret);
        }
        return encodedSecret;
    }

    @Override
    public String generateToken(String queryString,String serviceName,
                                Map<String, Object> jsonBody,int expireTimeInSeconds,boolean addPrefix)
            throws UnsupportedEncodingException {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime expire = LocalDateTime.now();
        expire = expire.plusSeconds(expireTimeInSeconds);

        Instant instant = now.atZone(ZoneId.systemDefault()).toInstant();
        Date dateFromOld = Date.from(instant);

        Instant instantexpire = expire.atZone(ZoneId.systemDefault()).toInstant();
        Date dateFromExpire = Date.from(instantexpire);

        String sortedQs = getSortedQuery(queryString);
        String token = authHeaderPrefix + " ";

        //String encodedSecret = TextCodec.BASE64.encode(secret);
        String compactJws = Jwts.builder()
                .setHeaderParam(TOKEN_TYPE, "JWT")
                .setHeaderParam(TOKEN_ALG, SignatureAlgorithm.HS256.getValue())
                .setIssuer(appId)
                .setSubject(serviceName)
                .setAudience(APP_NAME)
                .claim("qs", sortedQs)
                .claim("jb",jsonBody)
                .setIssuedAt(dateFromOld)
                .setExpiration(dateFromExpire)
                .setId(APP_NAME)
                .signWith(SignatureAlgorithm.HS256, getEncodedSecret() )
                .compact();

        if(addPrefix) {
            return token + compactJws;
        } else {
            return compactJws;
        }

    }

    @Override
    public String generateToken(String serviceId, int expireTimeInSeconds,
                         DITTokenResponse verifyTokenResponse) throws UnsupportedEncodingException {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime expire = LocalDateTime.now();
        expire = expire.plusSeconds(expireTimeInSeconds);

        Instant instant = now.atZone(ZoneId.systemDefault()).toInstant();
        Date dateFromOld = Date.from(instant);

        Instant instantexpire = expire.atZone(ZoneId.systemDefault()).toInstant();
        Date dateFromExpire = Date.from(instantexpire);

        String compactJws = Jwts.builder()
                .setHeaderParam(TOKEN_TYPE, "JWT")
                .setHeaderParam(TOKEN_ALG, SignatureAlgorithm.HS256.getValue())
                .setIssuer(appId)
                .setSubject(serviceId)
                .setAudience(APP_NAME)
                .claim(SERIAL_NUMBER, verifyTokenResponse.getSerialNumber())
                .claim(MAC_ADDRESS, verifyTokenResponse.getMacAddress())
                .claim(DEVICE_ID, verifyTokenResponse.getDeviceId())
                .claim(TENANT_ID, verifyTokenResponse.getTid())
                .setIssuedAt(dateFromOld)
                .setExpiration(dateFromExpire)
                .setId(APP_NAME)
                .signWith(SignatureAlgorithm.HS256, getEncodedSecret() )
                .compact();

        return compactJws;
    }

    private String getSortedQuery(String queryString)throws UnsupportedEncodingException {
        if(queryString == null || queryString.isEmpty()) {
            return null;
        }
        Map<String , String> sortedMap = new TreeMap<>();
        String []keValuePairs = queryString.split("&");
        String []keyValuePair;
        for(String pair : keValuePairs) {
            keyValuePair = pair.split("=");
            if(keyValuePair.length==2)
                sortedMap.put(keyValuePair[0], keyValuePair[1]);
        }
        StringBuilder stringBuilder = new StringBuilder();
        for(Map.Entry<String , String> entry: sortedMap.entrySet()) {
            logger.info("query string -- key : {}, value {}",entry.getKey(),entry.getValue());
            stringBuilder.append(entry.getKey())
                    .append("=")
                    .append((URLEncoder.encode(entry.getValue(), "UTF-8"))
                            .replaceAll("\\+", "%20"))
                    .append("&");
        }

        stringBuilder.deleteCharAt(stringBuilder.length()-1);

        return stringBuilder.toString();

    }

    @Override
    public Optional<String> getServiceUrl(String serviceName) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        HttpEntity<String> entity = new HttpEntity<>(headers);

        if(Objects.isNull(orionServicesVO) ) {
            synchronized(this){
                if(Objects.isNull(orionServicesVO) ) {
                    try {
                        ResponseEntity<OrionServicesVO> result = restTemplate.exchange(globalDirectoryURL,
                                HttpMethod.GET, entity, OrionServicesVO.class);
                        orionServicesVO = result.getBody();
                        logger.info("Response status code : {},body : {}",
                                result.getStatusCodeValue(),result.getBody());
                    }catch (RestClientException rce) {
                        logger.error("getOrionServices got exception : {}",rce.getMessage());
                    }
                }
            }
        }

        String url = null;
        if(Objects.nonNull(orionServicesVO) ) {
            List<OrionServiceVO> services = orionServicesVO.getServices();
            for(OrionServiceVO gdService : services) {
                if(serviceName.equalsIgnoreCase(gdService.getName())) {
                    if(!CollectionUtils.isEmpty(gdService.getVersions()) ) {
                        url = gdService.getVersions().get(0).getUrl();
                    }
                    break;
                }
            }
        }

        if(Objects.nonNull(url)) {
            return Optional.of(url);
        } else {
            return Optional.empty();
        }
    }

    @Override
    public boolean isDeviceAnalyticsTokenValid(String daToken) {
        boolean valid = false;
        if(Objects.nonNull(daToken)) {
            try {
                Claims claims = Jwts.parser().setSigningKey(getEncodedSecret())
                        .parseClaimsJws(daToken).getBody();
                String issuer = claims.getIssuer();
                String subject = claims.getSubject();
                boolean expired = isExpired(claims.getExpiration());

                if(appId.equals(issuer)
                        && APP_NAME.equals(subject)
                        && !expired) {
                    valid = true;
                }
            } catch (Exception ee) {
                logger.error("isDeviceAnalyticsTokenValid -- errors while paring device analytics token: {}",daToken);
            }
        }

        return valid;
    }

    @Override
    public DITTokenResponse getDITTokenResponse(String daToken) {
        if(Objects.nonNull(daToken)) {
            try {
                Claims claims = Jwts.parser().setSigningKey(getEncodedSecret())
                        .parseClaimsJws(daToken).getBody();

                String serialNumber = claims.get(SERIAL_NUMBER,String.class);
                String macAddress = claims.get(MAC_ADDRESS,String.class);
                String deviceId = claims.get(DEVICE_ID,String.class);
                String tenantId = claims.get(TENANT_ID,String.class);

                DITTokenResponse response = new DITTokenResponse();
                response.setSerialNumber(serialNumber);
                response.setMacAddress(macAddress);
                response.setDeviceId(deviceId);
                response.setTid(tenantId);

                return response;
            } catch (Exception ee) {
                logger.error("getDITTokenResponse -- errors while paring device analytics token: {}",daToken);
            }
        }

        return null;
    }

    private boolean isExpired(Date expiration) {
        boolean expired = true;

        if( Objects.nonNull(expiration)) {
            long expireTime = expiration.getTime();
            long now = System.currentTimeMillis();
            long diff = (now-expireTime)/1000;

            if(diff < 0) {
                expired = false;
            }
        }

        return expired;
    }
}
