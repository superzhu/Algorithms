package com.polycom.analytics.device.services.orion;

import com.polycom.analytics.device.resources.ResponseVO;
import com.polycom.analytics.device.resources.token.VerifyResponseVO;
import com.polycom.analytics.device.services.orion.message.DITTokenResponse;
import org.springframework.http.ResponseEntity;

import javax.servlet.http.HttpServletRequest;
import java.util.Optional;

public interface DeviceIdentityService {
    /**
     * Remotely Verify whether Device Identity Token is valid or not
     */
    DITTokenResponse verifyToken(String token);

    ResponseEntity<VerifyResponseVO> verifyDITToken(String ditToken);

    /**
     * 1 Verify Session first, if Session is valid, return Optional.empty()
     * 2 If session fails, will validate input token remotely.
     */
    Optional<ResponseEntity<ResponseVO>> verifyDAToken(HttpServletRequest request);

    DITTokenResponse getTokenResponseFromDATToken(HttpServletRequest request);
}
