package com.polycom.analytics.device.exceptions;

import org.springframework.validation.Errors;

public class ValidationFailureException extends RuntimeException {
    private static final long serialVersionUID = -909671L;

    private Errors errors;
    private String apiName;
    public ValidationFailureException(Errors errors,String apiName) {
        this.errors = errors;
        this.apiName = apiName;
    }

    public Errors getErrors() {
        return errors;
    }

    public String getApiName() {
        return apiName;
    }
}
