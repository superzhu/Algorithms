package com.polycom.analytics.device.resources.cdr;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CalleeInfo {
    private String remoteSystemName;
    private String callNumber1;
    private String systemManufacturer;
    private String systemModel;
    private String systemSoftwareRelease;
}
