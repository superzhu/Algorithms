package com.polycom.analytics.device.services.geoip2;

import com.maxmind.geoip2.model.CityResponse;
import com.polycom.analytics.device.resources.GeoIP2;

import java.net.InetAddress;

public interface GeoIPService {
    public CityResponse cityResponse(InetAddress inetAddress);
    public CityResponse cityResponse(String ipAddress);
    public GeoIP2 getGeoLocatioin(String ipAddress);
}
