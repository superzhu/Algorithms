package com.polycom.analytics.device.resources.storage;

import lombok.Data;

import java.io.Serializable;

@Data
public class LogResponseVO implements Serializable {
    private static final long serialVersionUID = -90881656L;

    private String fileType;
    private String fileID;
    private String uploadLogRequest;
    private String deviceID;
    private String compress;

    private String compressionAlgorithm;
}
