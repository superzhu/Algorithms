package com.polycom.analytics.device.services.orion;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.polycom.analytics.device.resources.ResponseVO;
import com.polycom.analytics.device.resources.token.VerifyResponseVO;
import com.polycom.analytics.device.services.messages.MessageByLocaleService;
import com.polycom.analytics.device.services.orion.message.DITTokenResponse;
import com.polycom.analytics.device.utils.MessageKeys;
import com.polycom.analytics.device.utils.RequestConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.*;

@Service
public class DeviceIdentityServiceImpl implements DeviceIdentityService{
    private static final Logger logger = LoggerFactory.getLogger(DeviceIdentityServiceImpl.class);
    private static final String errorIndicator = "Analytics Device API Authentication Error";
    private static final String APP_NAME = "Device Analytics";

    @Value("${jwt.token.timeout}")
    private Integer tokenTimeoutInSeconds;

    @Value("${globaldirectory.identity.token.serviceName}")
    private String ditServiceName;

    @Value("${deviceanalytics.request.authHeader}")
    private String authHeaderKey;

    @Value("${deviceanalytics.request.authTokenPrefix}")
    private String authTokenPrefix;

    private Optional<String> identitySvrUrl;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private OrionService orionService;

    @Autowired
    MessageByLocaleService messageByLocaleService;

    @Override
    public DITTokenResponse verifyToken(String ditToken) {
        if(Objects.isNull(identitySvrUrl)) {
            identitySvrUrl = orionService.getServiceUrl(ditServiceName);
        }

        DITTokenResponse commandWrapper = new DITTokenResponse();
        if(Objects.nonNull(identitySvrUrl)
                && identitySvrUrl.isPresent()) {
            String url = identitySvrUrl.get() +"/"+"verify";
            ResponseEntity<String> responseEntity = null;

            try {
                Map<String, Object> body = new HashMap<>();
                body.put("token", ditToken);
                String requestBody = new ObjectMapper().writeValueAsString(body);

                String token = orionService.generateToken("", ditServiceName,body,30,true);
                HttpHeaders httpHeaders = new HttpHeaders();
                httpHeaders.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
                httpHeaders.set("authorization", token);

                logger.info("verifyToken: link:{}, request body : {}",url,requestBody);

                HttpEntity<String> httpEntity = new HttpEntity<>(requestBody, httpHeaders);
                responseEntity = restTemplate.postForEntity(url, httpEntity, String.class);
                logger.info("verifyToken: response status code : {},body : {}",
                        responseEntity.getStatusCodeValue(),responseEntity.getBody());

                try {
                    commandWrapper = new ObjectMapper().readValue(responseEntity.getBody(),DITTokenResponse.class);
                    commandWrapper.setValid(HttpStatus.OK == responseEntity.getStatusCode());
                } catch (IOException ioe) {
                    logger.error("verifyToken: get encoding exception during deserializing dit token response body : {}",
                            ioe.getMessage());
                    commandWrapper.setValid(HttpStatus.OK == responseEntity.getStatusCode());
                }


                return commandWrapper;
            } catch (UnsupportedEncodingException ue) {
                logger.error("verifyToken: get encoding exception during token generation:{}",ue.getMessage());
            } catch (JsonProcessingException rce) {
                logger.error("verifyToken: got exception : {}",rce.getMessage());
            }

        } else {
            logger.error("verifyToken: cannot get url for device identity service : {}", ditServiceName);
        }
        return commandWrapper;
    }

    @Override
    public ResponseEntity<VerifyResponseVO> verifyDITToken(String ditToken){
        DITTokenResponse verifyTokenResponse = verifyToken(ditToken);
        boolean validToken = verifyTokenResponse.isValid();

        VerifyResponseVO responseVO = new VerifyResponseVO();
        ResponseEntity<VerifyResponseVO> response = null;
        if(validToken) {
            try {
                //Generate new Device Analytics Token for future request
                String newToken = orionService.generateToken(APP_NAME,
                        tokenTimeoutInSeconds,verifyTokenResponse);
                responseVO.setDaToken(newToken);

                response = new ResponseEntity<VerifyResponseVO>(responseVO, HttpStatus.OK);
            } catch (Exception ue) {
                logger.error("verifyDATokenOrDITToken -- error from generating JWT token : {}",ue.getMessage());
                validToken = false;
            }
        }

        if(!validToken) {
            String authError = messageByLocaleService.getMessage(MessageKeys.CLIENT_AUTH_ERROR);
            responseVO.setDaToken(authError);
            response = new ResponseEntity<VerifyResponseVO>(responseVO, HttpStatus.UNAUTHORIZED);
        }
        return response;
    }

    @Override
    public Optional<ResponseEntity<ResponseVO>> verifyDAToken(HttpServletRequest request) {
        String token = request.getHeader(RequestConstants.DA_TOKEN_HEADER);
        logger.debug("verifyDAToken request parameters -- Device Analytics Client Token: {}",token);

        String daToken = getDatToken(token);
        boolean isDaTokenValid = orionService.isDeviceAnalyticsTokenValid(daToken);
        Optional<ResponseEntity<ResponseVO>> response = Optional.empty();

        if(!isDaTokenValid) {
            logger.error("verifyDAToken verification fails -- DAToken: {}",daToken);
            String authError = messageByLocaleService.getMessage(MessageKeys.CLIENT_AUTH_ERROR);
            ResponseVO responseVO = new ResponseVO(authError,errorIndicator);
            ResponseEntity<ResponseVO> entity =
                    new ResponseEntity<ResponseVO>(responseVO, HttpStatus.UNAUTHORIZED);
            response =  Optional.of(entity);
        }

        return response;
    }

    @Override
    public DITTokenResponse getTokenResponseFromDATToken(HttpServletRequest request) {
        String token = request.getHeader(RequestConstants.DA_TOKEN_HEADER);
        logger.debug("getTokenResponseFromDATToken request parameters -- Device Analytics Client Token: {}",token);
        String daToken = getDatToken(token);
        DITTokenResponse tokenResponse = orionService.getDITTokenResponse(daToken);

        return tokenResponse;
    }

    private String getDatToken(String authToken) {
        String token = null;
        if(Objects.nonNull(authToken)) {
            authToken = authToken.trim();

            if(Objects.nonNull(authToken))  {
                token = authToken.startsWith(authTokenPrefix) ? authToken.substring(authTokenPrefix.length()) : null;
            }
        }

        if(Objects.nonNull(token)) {
            token = token.trim();
        }

        return token;
    }
}
