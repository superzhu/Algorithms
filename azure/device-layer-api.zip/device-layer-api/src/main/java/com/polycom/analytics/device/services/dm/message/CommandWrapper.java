package com.polycom.analytics.device.services.dm.message;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

@Data
public class CommandWrapper {
    private final static Logger logger = LoggerFactory.getLogger(CommandWrapper.class);

    String category = "C2DP";
    String attr = "DeviceAnalyticsCommandPOC";
    //String attr = "DeviceAnalyticsCommand";
    String version = "0.0.1";

    AbstractMessageToDevice value;

    public CommandWrapper() {
        super();
    }

    public CommandWrapper(AbstractMessageToDevice value) {
        super();
        this.value = value;
    }

    @JsonIgnore
    public Map<String, Object> createMap() {
        Map<String, Object> body = new HashMap<>();
        body.put("attr", attr);
        body.put("category", category);
        body.put("version", version);
        body.put("value", value.getMap());

        return body;
    }
}
