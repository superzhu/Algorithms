package com.polycom.analytics.device.web.controllers;

import com.polycom.analytics.device.exceptions.ValidationFailureException;
import com.polycom.analytics.device.resources.ResponseVO;
import com.polycom.analytics.device.resources.storage.LogRequestVO;
import com.polycom.analytics.device.resources.storage.LogResponseVO;
import com.polycom.analytics.device.services.orion.DeviceIdentityService;
import com.polycom.analytics.device.services.orion.message.DITTokenResponse;
import com.polycom.analytics.device.services.storage.StorageService;
import com.polycom.analytics.device.services.storage.UploadLogDto;
import com.polycom.analytics.device.utils.RequestConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.Optional;
import java.util.UUID;


@RestController
@RequestMapping(produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class FileuploadController {
    private final static Logger logger = LoggerFactory.getLogger(FileuploadController.class);

    @Autowired
    private DeviceIdentityService deviceIdentityService;

    @Autowired
    private StorageService storageService;

    @PutMapping(value="/v1.0/deviceanalytics/devicelogs/file",headers=("content-type=multipart/*"))
    public ResponseEntity<ResponseVO> uploadFile(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value="fileID",required=true) String fileID,
            @RequestParam(value="fileType",required=true) String fileType,
            @RequestParam(value="deviceID",required=true) String deviceID,
            @RequestParam(value="compress",required=false) String compress,
            @RequestParam(value="compressionAlgorithm",required=false) String compressionAlgorithm,
            @RequestParam(value="trigger",required=true) String trigger,
            HttpServletRequest request) {
        Optional<ResponseEntity<ResponseVO>> verifyResponse = deviceIdentityService.verifyDAToken(request);
        if(verifyResponse.isPresent()) {
            return verifyResponse.get();
        }
        DITTokenResponse tokenResponse = deviceIdentityService.getTokenResponseFromDATToken(request);

        UploadLogDto logDto = new UploadLogDto(fileID,
                fileType,deviceID,compress,
                compressionAlgorithm,trigger);
        logDto.setSerialNumber(tokenResponse.getSerialNumber());
        logDto.setMacAddress(tokenResponse.getMacAddress());
        logDto.setTenantId(tokenResponse.getTid());

        storageService.store(file,logDto);

        ResponseVO response = new ResponseVO(RequestConstants.RESPONSE_SUCCESS,
                RequestConstants.FILE_UPLOAD_API);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    /**
     * This is mainly for testing purposes, when the device decides it
     * wants to upload a log on its own. Most of the time, the device
     * will be told to upload a log, it won't decide to upload file on
     * its own.
     */
    @PostMapping(value="/v1.0/deviceanalytics/devicelogs/uploadLogRequest",
            consumes = MediaType.APPLICATION_JSON_UTF8_VALUE,
            produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<LogResponseVO> uploadLogRequest(
            @Valid @RequestBody LogRequestVO logRequestVO,
            Errors errors,
            HttpServletRequest request
    ) {
        if (errors.hasErrors()) {
            throw new ValidationFailureException(errors, RequestConstants.FILE_UPLOAD_REQUEST_API);
        }

        UUID uuid = UUID.randomUUID();
        String randomUUIDString = uuid.toString();

        LogResponseVO responseVO = new LogResponseVO();
        responseVO.setFileType(logRequestVO.getFileType());
        responseVO.setDeviceID(logRequestVO.getDeviceID());
        responseVO.setFileID(randomUUIDString);
        responseVO.setUploadLogRequest("approved");

        responseVO.setCompress("yes");
        responseVO.setCompressionAlgorithm("snappy");

        return new ResponseEntity<>(responseVO, HttpStatus.OK);
    }
}
