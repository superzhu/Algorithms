package com.polycom.analytics.device.services.orion.message;

import lombok.Data;

import java.util.List;

@Data
public class OrionServiceVO {
    private String name;
    private String app;
    private List<ServiceVersion> versions;
}
