package com.polycom.analytics.device.services.kafka;

public interface KafkaProducer {
    public void send(String topic, String payload);
}
