package com.polycom.analytics.device.resources.info;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.polycom.analytics.device.utils.JsonConverter;
import com.polycom.analytics.device.utils.RequestConstants;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Data
@EqualsAndHashCode(callSuper=true)
@JsonTypeName(RequestConstants.DEVICE_INFO_HEALTH)
public class DeviceHealthInfo extends AbstractDeviceInfo {
    private String uptime;
    private int cpuLevel;
    private int cpuLevelAvg;
    private int memoryUtilization;
    private int memoryUtilizationAvg;

    private int memoryUtilizationPct;
    private int memoryUtilizationAvgPct;
    private double networkLoad;
    private int txErrors;
    private int rxErrors;

    private String version = "1.0";

    @SuppressWarnings("unchecked")
    @JsonProperty("ethernetErrors")
    private void unpackNested(Map<String,Object> errors) {
        this.txErrors = (Integer) errors.get("tx_errors");
        this.rxErrors = (Integer) errors.get("rx_errors");
    }

    @Override
    public List<String> convert(String header) {
        StringBuilder builder = new StringBuilder(header);
        super.convertSubCommon(builder);

        JsonConverter.buildStrField(builder,"uptime",uptime);
        JsonConverter.buildIntField(builder,"cpuLevel",cpuLevel);
        JsonConverter.buildIntField(builder,"cpuLevelAvg",cpuLevelAvg);
        JsonConverter.buildIntField(builder,"memoryUtilization",memoryUtilization);
        JsonConverter.buildIntField(builder,"memoryUtilizationAvg",memoryUtilizationAvg);

        JsonConverter.buildIntField(builder,"memoryUtilizationPct",memoryUtilizationPct);
        JsonConverter.buildIntField(builder,"memoryUtilizationAvgPct",memoryUtilizationAvgPct);
        JsonConverter.buildDoubleField(builder,"networkLoad",networkLoad);
        JsonConverter.buildIntField(builder,"txErrors",txErrors);
        JsonConverter.buildIntField(builder,"rxErrors",rxErrors);

        JsonConverter.buildStrLast(builder,"version",version);

        ArrayList<String> list = new ArrayList<>();
        list.add( builder.toString() );
        return list;
    }
}
