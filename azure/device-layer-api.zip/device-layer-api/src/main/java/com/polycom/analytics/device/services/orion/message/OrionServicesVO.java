package com.polycom.analytics.device.services.orion.message;

import lombok.Data;

import java.util.List;

@Data
public class OrionServicesVO {
    private List<OrionServiceVO> services;
}
