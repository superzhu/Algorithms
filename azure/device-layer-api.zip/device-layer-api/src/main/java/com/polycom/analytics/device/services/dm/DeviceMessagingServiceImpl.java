package com.polycom.analytics.device.services.dm;

import java.io.UnsupportedEncodingException;
import java.util.*;

import com.polycom.analytics.device.services.dm.message.CommandWrapper;
import com.polycom.analytics.device.services.dm.message.SendInfo;
import com.polycom.analytics.device.services.orion.OrionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Service
public class DeviceMessagingServiceImpl implements DeviceMessagingService {
	private static final Logger logger = LoggerFactory.getLogger(DeviceMessagingServiceImpl.class);

    @Value("${globaldirectory.messaging.client.serviceName}")
    private String mesClientServiceName;
    private Optional<String> mesClientSvrUrl;

	@Autowired
	private RestTemplate restTemplate;

    @Autowired
	private OrionService orionService;

	@Override
	public ResponseEntity sendDeviceInfo(CommandWrapper commandWrapper) {
        if(Objects.isNull(mesClientSvrUrl)) {
            mesClientSvrUrl = orionService.getServiceUrl(mesClientServiceName);
        }

        ResponseEntity<String> responseEntity = null;
        if(Objects.isNull(mesClientSvrUrl) ||
                !mesClientSvrUrl.isPresent()) {
            String errorMessage = "sendDeviceInfo cannot get url of device-messaing-client from global directory.";
            responseEntity = new ResponseEntity<String>(errorMessage, HttpStatus.NOT_FOUND);
            return responseEntity;
        }

        Map<String, Object> requestMap = commandWrapper.createMap();
        SendInfo sendInfo = (SendInfo) commandWrapper.getValue();
        logger.info("sendDeviceInfo: deviceID:{},teneantID:{},serial number:{},infoType:{},trigger:{}",
                sendInfo.getDeviceID(),sendInfo.getTenantID(),sendInfo.getSerialNumber(),
                sendInfo.getInfoType(),sendInfo.getTrigger());

        try {
            String qs = "tid=" + sendInfo.getTenantID();
            String url = new StringBuilder()
                    .append(mesClientSvrUrl.get())
                    .append("/").append("send")
                    .append("/").append(sendInfo.getDeviceID())
                    .append("?").append(qs).toString();

            String token = orionService.generateToken(qs,mesClientServiceName,requestMap,30,true);
            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
            //Attach JWT token to the header
            httpHeaders.set("authorization", token);

            logger.info("sendDeviceInfo: link:{},request body : {}",
                    url,requestMap);

            HttpEntity<Map<String, Object>> httpEntity = new HttpEntity<>(requestMap, httpHeaders);
            responseEntity = restTemplate.postForEntity(url, httpEntity, String.class);

            logger.info("sendInfo Command: response status code : {},response body : {}",
                    responseEntity.getStatusCodeValue(),responseEntity.getBody());
        } catch (UnsupportedEncodingException ue) {
            logger.error("sendDeviceInfo: get encoding exception during token generation:{}",ue.getMessage());
        } catch (RestClientException rce) {
            logger.error("sendDeviceInfo: get exception : {}",rce.getMessage());
        }

        return responseEntity;
	}
}
