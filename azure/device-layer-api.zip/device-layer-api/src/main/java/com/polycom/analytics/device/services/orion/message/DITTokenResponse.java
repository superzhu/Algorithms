package com.polycom.analytics.device.services.orion.message;

import lombok.Data;

@Data
public class DITTokenResponse {
    private String type; //type of device
    private String serialNumber;//optional. provided by device
    private String macAddress;//optional. only for devices that have MAC
    private String deviceId; //optional. deviceID of the device, if its onboarded
    private String tid;  //optional. tenantID if onboarded

    private boolean valid;
}
