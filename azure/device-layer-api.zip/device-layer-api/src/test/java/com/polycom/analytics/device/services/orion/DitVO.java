package com.polycom.analytics.device.services.orion;

import lombok.Data;

@Data
public class DitVO {
    private String deviceanalytics;
}
