package com.polycom.analytics.device.services.orion;

import lombok.Data;

@Data
public class IdentityTokenVO {
    private String deviceType;
    private DitVO dit;
}
