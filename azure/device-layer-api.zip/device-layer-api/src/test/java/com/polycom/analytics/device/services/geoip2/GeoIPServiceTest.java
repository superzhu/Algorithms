package com.polycom.analytics.device.services.geoip2;

import com.polycom.analytics.device.resources.GeoIP2;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.assertThat;

//@RunWith(SpringRunner.class)
//@SpringBootTest
public class GeoIPServiceTest {
    private final static Logger logger = LoggerFactory.getLogger(GeoIPServiceTest.class);

    @Autowired
    private GeoIPService geoIPService;

    //@Test
    public void cityResponse() throws Exception{
        //140.242.214.5/172.0.0.1/207.97.227.239
        GeoIP2 geoip2 = geoIPService.getGeoLocatioin("207.97.227.239");

        logger.info("testing assertion: ");
        assertThat( geoip2.getCity()).isEqualTo("San Antonio");
        assertThat( geoip2.getPostalCode()).isEqualTo("78218");
        assertThat( geoip2.getRegion()).isEqualTo("TX");
        assertThat( geoip2.getCountry()).isEqualTo("US");
        assertThat( geoip2.getMetro()).isEqualTo(641);
    }
}
