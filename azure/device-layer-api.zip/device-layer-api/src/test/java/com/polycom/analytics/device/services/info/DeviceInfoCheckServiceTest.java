package com.polycom.analytics.device.services.info;

import com.polycom.analytics.device.resources.ResponseVO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Optional;
import java.util.TimeZone;

import static org.assertj.core.api.Assertions.assertThat;

//@RunWith(SpringRunner.class)
//@SpringBootTest
public class DeviceInfoCheckServiceTest {
    private final static Logger logger = LoggerFactory.getLogger(DeviceInfoCheckServiceTest.class);

    @Autowired
    DeviceInfoCheckService dateUtil;

    //@Test
    public void checkUploadTimeFormatError() throws Exception{
        //Current UTC
        Date time = Calendar.getInstance().getTime();
        SimpleDateFormat outputFmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        outputFmt.setTimeZone(TimeZone.getTimeZone("UTC"));
        logger.info("Current system time converted to UTC time: {}",outputFmt.format(time));

        //String dateTime = "2018-02-06T12:49:37+0530";
        String dateTime = "2018-03-16T03:58:31-0500";
        Optional<ResponseEntity<ResponseVO>> response =
                dateUtil.verifyDateFormat(dateTime,"DeviceInfoCheckServiceTest");

        assertThat( response.isPresent() ).isEqualTo(true);
        response.ifPresent(
                entity -> assertThat(entity.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST));
    }

    //@Test
    public void checkUploadTimeAheadError() throws Exception{
        //Only allow timestamps that are within 1 hour ahead of server
        Optional<ResponseEntity<ResponseVO>> response =
                dateUtil.verifyDateFormat("2028-02-09T12:49:37+0530","DeviceInfoCheckServiceTest");

        assertThat( response.isPresent() ).isEqualTo(true);
        response.ifPresent(
                entity -> assertThat(entity.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST));
    }

    //@Test
    public void checkUploadTimeLaterError() throws Exception{
        //must be within 24 hours of the server time
        Optional<ResponseEntity<ResponseVO>> response =
                dateUtil.verifyDateFormat("2008-02-09T12:49:37+0530","DeviceInfoCheckServiceTest");

        assertThat( response.isPresent() ).isEqualTo(true);
        response.ifPresent(
                entity -> assertThat(entity.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST));
    }

    //@Test
    public void getCurrentTime() throws Exception{
        String current = dateUtil.getCurrentISO8601Time();
        logger.info("Current time : {}",current);
    }
}
