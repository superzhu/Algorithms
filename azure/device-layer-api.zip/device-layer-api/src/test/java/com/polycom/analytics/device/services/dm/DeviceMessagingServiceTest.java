package com.polycom.analytics.device.services.dm;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.polycom.analytics.device.services.dm.message.CommandTrigger;
import com.polycom.analytics.device.services.dm.message.CommandWrapper;
import com.polycom.analytics.device.services.dm.message.SendInfo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import static com.polycom.analytics.device.utils.RequestConstants.DEVICE_INFO_PRIMARY;

//@RunWith(SpringRunner.class)
//@SpringBootTest
public class DeviceMessagingServiceTest {
    private final static Logger logger = LoggerFactory.getLogger(DeviceMessagingServiceTest.class);

    @Autowired
    DeviceMessagingService deviceMessagingService;

    private static final String SENDINFO_JSON =
            "{ \"category\": \"C2DP\","
               + " \"attr\": \"DeviceAnalyticsCommandPOC\", "
               + " \"version\": \"0.0.1\", "
               + " \"value\": { "
               + " \"commandType\": \"sendInfo\","
               + " \"infoType\": \"primaryDeviceInfo\", "
               + " \"trigger\": \"rebootEvent\", "
               + " \"serialNumber\": \"0004f284e259\", "
               + " \"deviceID\": \"e0082588-c296-4185-a36a-da4a6fca7b71\", "
               + " \"tenantID\": \"a1428bf5-a7c9-45e0-9bbf-b92baee0f282\" "
               + "} "
           + "} ";

    //@Test
    public void sendDeviceInfo() throws Exception{
       /* String deviceID = "a56765a8-711d-4579-aa74-6d8ea63b6719";
        String tenantID = "a1428bf5-a7c9-45e0-9bbf-b92baee0f282";
        String serialNo = "AR0216190E47";*/

        CommandWrapper convertedWrapper = new ObjectMapper().readValue(SENDINFO_JSON,CommandWrapper.class);

        String deviceID = "e0082588-c296-4185-a36a-da4a6fca7b71";
        String tenantID = "a1428bf5-a7c9-45e0-9bbf-b92baee0f282";
        String serialNo = "0004f284e259";

        SendInfo command = new SendInfo(DEVICE_INFO_PRIMARY,
                CommandTrigger.CT_REBOOT,serialNo,
                deviceID,tenantID);
        CommandWrapper wrapper = new CommandWrapper(command);

        long startTime = System.currentTimeMillis();
        ResponseEntity response = deviceMessagingService.sendDeviceInfo(convertedWrapper);
        long endTime = System.currentTimeMillis();
        logger.info("response status: {}, running duration : {}",
                response.getStatusCode(),endTime-startTime);
    }
}
