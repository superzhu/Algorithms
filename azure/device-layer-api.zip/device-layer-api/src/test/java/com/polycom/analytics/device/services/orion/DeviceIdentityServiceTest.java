package com.polycom.analytics.device.services.orion;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.polycom.analytics.device.resources.token.VerifyResponseVO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.*;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static org.assertj.core.api.Assertions.assertThat;

//@RunWith(SpringRunner.class)
//@SpringBootTest
public class DeviceIdentityServiceTest {
    private final static Logger logger = LoggerFactory.getLogger(DeviceIdentityServiceTest.class);

    @Autowired
    private DeviceIdentityService deviceIdentityService;

    @Autowired
    private RestTemplate restTemplate;

    //@Test
    public void verifyTokenTest() throws Exception{
        String tenantDiscoveryUrl = "https://api-global-mtls-dev3.plcm.cloud/api/v1.0/device-tenant-discovery/mtls?apps=deviceanalytics";
        String token = null;

        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
       // headers.set("POLYCOM-DEVICE-MAC", "100000000001");
        headers.set("POLYCOM-DEVICE-MAC", "10ddb19c5e22");
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);


        Map<String, Object> body = new HashMap<>();
        body.put("serialNumber", "123456789");
        body.put("type", "PANO");
        String requestBody = new ObjectMapper().writeValueAsString(body);

        //HttpEntity<String> entity = new HttpEntity<>(headers);
        HttpEntity<String> entity = new HttpEntity<>(requestBody, headers);

        try {
            ResponseEntity<IdentityTokenVO> result = restTemplate.exchange(tenantDiscoveryUrl,
                    HttpMethod.POST, entity, IdentityTokenVO.class);

            if(Objects.nonNull(result) &&
                    Objects.nonNull(result.getBody())) {
                IdentityTokenVO vo = result.getBody();
                token = vo.getDit().getDeviceanalytics();
            }
            logger.info("Response status code : {},body : {}",
                    result.getStatusCodeValue(),result.getBody());
            logger.info("token: {}",token);
        }catch (RestClientException rce) {
            logger.error("getOrionServices got exception : {}",rce.getMessage());
        }

       if(Objects.nonNull(token)) {
            long startTime = System.currentTimeMillis();
            boolean valid = deviceIdentityService.verifyToken(token).isValid();
            long endTime = System.currentTimeMillis();
            logger.info("token is valid or not : {}, running duration : {}",
                    valid,endTime-startTime);
            assertThat( valid ).isEqualTo(true);
        }
    }
}
