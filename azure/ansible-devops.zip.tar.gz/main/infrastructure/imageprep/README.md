*************Download dcos_generate_config.sh*************
  dcos_generate_config.sh is around 923M, cannot push to git repository.

  1 Download it using command: 
      curl -fsSL -O  https://downloads.dcos.io/dcos/stable/1.12.0/dcos_generate_config.sh

   2 Put it under folder: ./files

   3 Run below to generate its sha1sum, and compare with file: dcos_generate_config.sh.sha1sum
      sha1sum -b dcos_generate_config.sh 
*************Download dcos_generate_config.sh*************

 Create custom image for West Europe
 ansible-playbook -e AZURE_PROFILE="default" --extra-vars "cluster=eu" createVM.yml

 Create custom image for US
 ansible-playbook -e AZURE_PROFILE="default" --extra-vars "cluster=us" createVM.yml


Create custom image for China Cloud:
 ansible-playbook -e AZURE_PROFILE="china" --extra-vars "cluster=cn" createVM.yml

 ***************************************************************

 Provision above Vms to produce customer images
    ansible-playbook  provisioning.yml

 **************************************************************

 For Debugging Purpose:
    ansible-playbook -e AZURE_PROFILE="default" --extra-vars "cluster=us" test.yml