#!/bin/bash

sed -i s/^UMASK.*/UMASK\ 027/g /etc/login.defs
sed -i s/^umask.*/umask\ 027/g /etc/init.d/rc

chmod -R 600 /etc/ssh/*
chmod 640 /etc/fuse.conf

exit 0
