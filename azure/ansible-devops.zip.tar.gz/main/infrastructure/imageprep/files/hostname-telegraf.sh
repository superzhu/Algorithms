#!/bin/bash -e
sed -i 's/^hostname = ""/  hostname = '\""$(hostname)"\"/ /etc/telegraf/telegraf.conf