File README.md configures default inventory.

1 Run with defaulut inventory
  For West Europse Cluster:
     ansible-playbook -e AZURE_PROFILE="default" --extra-vars "cluster=eu env=dev" setup.yml

  For South Central US Cluster:
     ansible-playbook -e AZURE_PROFILE="default" --extra-vars "cluster= env=dev" setup.yml

  For Azure China Cluster:
     ansible-playbook -e AZURE_PROFILE="china" --extra-vars "cluster=cn env=dev" setup.yml

 2 Run with specific inventory
   For West Europse Cluster:
      ansible-playbook -i ./inventories/production/ -e AZURE_PROFILE="default" --extra-vars "cluster=eu env=production" setup.yml

   For South Central US Cluster:
      ansible-playbook -i ./inventories/production/ -e AZURE_PROFILE="default" --extra-vars "cluster= env=production" setup.yml

   For Azure China Cluster:
     ansible-playbook -i ./inventories/production/ -e AZURE_PROFILE="china" --extra-vars "cluster=cn env=production" setup.yml


3 Traffic Manager
   ansible-playbook --extra-vars "env=dev" setupTM.yml

4 Docker version upgrade:
  Prerequisite: install Azure cli on running machine

  
  ansible-playbook -i ./inventories/dev/ -e AZURE_PROFILE="default" --extra-vars "cluster= env=dev" dockerupgrade.yml