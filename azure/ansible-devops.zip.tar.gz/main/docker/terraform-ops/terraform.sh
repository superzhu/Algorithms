#!/usr/bin/env bash

if [ $# -eq 0 ]; then
    echo "Usage: $0 apply -var-file ../../../../EnvParams/terraform/ops/conf/pdmsjhtest.tfvars -state pdmsjhtest.tfstate"
    exit 1
fi

set -x

terraform $@

