#!/bin/bash

echo "STRATUS starting cloud-init deployment"

export STRATUS_MACHINE_ID=`cat /etc/machine-id`
export STRATUS_HOSTNAME=`hostname`
export STRATUS_IPADDRESS=`ip-detect`
export STRATUS_VM_UNIQUE_NAME=${STRATUS_RG_NAME}_${STRATUS_HOSTNAME}

echo "STRATUS Installing Filebeat"

#download files
wget --no-check-certificate https://plcmstratusfilestorage.blob.core.windows.net/publicblobstorage/filebeat-5.0.0-amd64.deb
wget --no-check-certificate https://plcmstratusfilestorage.blob.core.windows.net/publicblobstorage/filebeat-$STRATUS_VM_TYPE.0.1.yml

#install filebeat
dpkg -i filebeat-5.0.0-amd64.deb

#compile the template for filebeat config
TEMPLATE=filebeat-$STRATUS_VM_TYPE.0.1.yml
OUTPUT=/etc/filebeat/filebeat.yml
perl -pe 's;(\\*)(\$([a-zA-Z_][a-zA-Z_0-9]*)|\$\{([a-zA-Z_][a-zA-Z_0-9]*)\})?;substr($1,0,int(length($1)/2)).($2&&length($1)%2?$2:$ENV{$3||$4});eg' $TEMPLATE > $OUTPUT

#add the hosts names for kafka clusters
echo "192.168.50.8 analytics-kafka-scus-1
192.168.50.7 analytics-kafka-scus-2
192.168.50.9 analytics-kafka-scus-3" >> /etc/hosts

#start filebeat
systemctl enable filebeat
systemctl start filebeat

echo "STRATUS Installing Telegraf"

#download files
wget --no-check-certificate https://plcmstratusfilestorage.blob.core.windows.net/publicblobstorage/telegraf_1.1.2_amd64.deb
wget --no-check-certificate https://plcmstratusfilestorage.blob.core.windows.net/publicblobstorage/telegraf.0.1.yml
wget --no-check-certificate https://plcmstratusfilestorage.blob.core.windows.net/publicblobstorage/telegraf-mesos-$STRATUS_VM_TYPE.0.1.yml

#install
dpkg -i telegraf_1.1.2_amd64.deb

if [ "$STRATUS_VM_TYPE" == "agent" ]
then
  # patch it if its agents
  echo "STRATUS patching the telegraf binary"
  wget --no-check-certificate https://plcmstratusfilestorage.blob.core.windows.net/publicblobstorage/telegraf-1.1.2.patched.tgz
  tar -xvf telegraf-1.1.2.patched.tgz
  cp -f telegraf /usr/bin
fi

#compile the template for telegraf config
TEMPLATE=telegraf.0.1.yml
OUTPUT=/etc/telegraf/telegraf.conf
perl -pe 's;(\\*)(\$([a-zA-Z_][a-zA-Z_0-9]*)|\$\{([a-zA-Z_][a-zA-Z_0-9]*)\})?;substr($1,0,int(length($1)/2)).($2&&length($1)%2?$2:$ENV{$3||$4});eg' $TEMPLATE > $OUTPUT

#compile the template for telegraf mesos config
TEMPLATE=telegraf-mesos-$STRATUS_VM_TYPE.0.1.yml
OUTPUT=/etc/telegraf/telegraf.d/mesos.conf
perl -pe 's;(\\*)(\$([a-zA-Z_][a-zA-Z_0-9]*)|\$\{([a-zA-Z_][a-zA-Z_0-9]*)\})?;substr($1,0,int(length($1)/2)).($2&&length($1)%2?$2:$ENV{$3||$4});eg' $TEMPLATE > $OUTPUT

#start
systemctl enable telegraf
systemctl restart telegraf

echo "STRATUS Installing Consul"

# donwload files
wget --no-check-certificate https://plcmstratusfilestorage.blob.core.windows.net/publicblobstorage/consul_0.7.4_linux_amd64.zip

# install consul
unzip consul_0.7.4_linux_amd64.zip
mv consul /usr/bin

# start consul
systemctl enable consul
systemctl start consul

echo "STRATUS done all tasks"
