#!/bin/bash

# change id_rsa mode to 600
chmod 600 ./config-pdms/id_rsa

echo "prepare jumohost and add ops vm's ip and hostname to jumphost's /etc/hosts"
result_fix=$(ANSIBLE_SSH_PIPELINING=false ansible-playbook prepare-jumphost.yml --private-key=./config-pdms/id_rsa --user=plcm -e "jumphost=CUR_JUMPHOST_NAME" -e "ip=CUR_OPS_VM_PRIIP" -e "host=CUR_OPS_VM_HOSTNAME")
echo "$result_fix"
if [[ $result_fix =~ "unreachable=0" && $result_fix =~ "failed=0" ]]
then
    echo "fix and add /etc/hosts successful"
else
    echo "fix and add /etc/hosts failed"
    exit 1
fi

echo "prepare ops vm"
result=$(ansible-playbook prepare-ops-vm.yml --private-key=./config-pdms/id_rsa --user=plcm -e "host=CUR_OPS_VM_HOSTNAME")
echo "$result"
if [[ $result =~ "unreachable=0" && $result =~ "failed=0" ]]
then
    echo "prepare ops vm successful"
else
    echo "prepare ops vm failed"
    exit 2
fi

exit 0
