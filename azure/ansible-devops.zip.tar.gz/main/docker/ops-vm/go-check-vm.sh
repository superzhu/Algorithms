#!/bin/bash

# change id_rsa mode to 600
chmod 600 ./config-pdms/id_rsa
echo "check vm"
result=$(ansible-playbook ./check-vm.yml --private-key=./config-pdms/id_rsa --user=plcm -e "host=CUR_OPS_VM_HOSTNAME")
echo "$result"

echo 'execute go-prepare-swarm-portainer.sh'
./go-prepare-swarm-portainer.sh
if [ $? != 0 ]; then
    echo "go-prepare-swarm-portainer.sh failed"
    exit 1
fi

exit 0

