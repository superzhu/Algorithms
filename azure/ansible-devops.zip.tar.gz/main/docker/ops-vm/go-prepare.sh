#!/bin/bash

./go-prepare-vm.sh
if [ $? != 0 ]; then
    echo "go-prepare-vm.sh failed"
    exit 1
fi

./go-prepare-swarm-portainer.sh
if [ $? != 0 ]; then
    echo "go-prepare-swarm-portainer.sh failed"
    exit 1
fi

./go-prepare-ntp.sh
if [ $? != 0 ]; then
    echo "go-prepare-ntp.sh failed"
    exit 2
fi

./go-prepare-log-rollover.sh
if [ $? != 0 ]; then
    echo "go-prepare-log-rollover.sh failed"
    exit 3
fi

./go-prepare-filebeat.sh
if [ $? != 0 ]; then
    echo "go-prepare-filebeat.sh failed"
    exit 4
fi

./go-prepare-telegraf.sh
if [ $? != 0 ]; then
    echo "go-prepare-telegraf.sh failed"
    exit 5
fi

./go-prepare-linux-harden.sh
if [ $? != 0 ]; then
    echo "go-prepare-linux-harden.sh failed"
    exit 6
fi


./go-prepare-redis-config.sh
if [ $? != 0 ]; then
    echo "go-prepare-redis-config.sh failed"
    exit 8
fi

echo "go-prepare.sh executed successfully"
exit 0
