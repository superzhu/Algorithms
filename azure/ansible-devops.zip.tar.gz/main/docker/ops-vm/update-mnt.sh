#!/bin/bash

sg=$1

# delete #sg on host
echo "begin to delete /mnt/pdms/conf/$sg on host"
result_mnt=$(ansible-playbook ./delete-mnt.yml --private-key=./config-pdms/id_rsa --user=plcm -e "host=CUR_OPS_VM_HOSTNAME" -e sgid=$sg)
echo "$result_mnt"
if [[ $result_mnt =~ "unreachable=0" && $result_mnt =~ "failed=0" ]]
then
    echo "delete directory: /mnt/pdms/conf/"$sg" successfully"
else
    echo "delete directory: /mnt/pdms/conf/"$sg" failed"
    exit 1
fi
# delete directory /mnt/pdms/conf/$sg on local installer
echo "delete directory /mnt/pdms/conf/"$sg" on local installer"
rm -rf ./mnt/pdms/conf/$sg


echo "begin to modify mnt for service group:"$sg
# if $sg is new, create $sg and copy files to it
if [ ! -d "./mnt/pdms/conf/$sg" ]
then
    echo "create new service group: /mnt/pdms/conf/"$sg
    mkdir -p ./mnt/pdms/conf/$sg
    \cp -rf ./config-pdms/sg/* ./mnt/pdms/conf/$sg/
fi
# modify ./mnt/pdms/conf/$sg/db.json 
# get server from ./config-pdms/dbserver.json
file="./config-pdms/dbserver.json"
if [ -f "$file" ]
then
  echo "$file found."
  newserver=$(jq -r '."db-server"' ./config-pdms/dbserver.json)
  if [[ $newserver == null ]]; then
    echo "db-server is null"
    exit 3
  fi
else
  echo "$file not found."
  exit 2
fi
curserver=$(jq -r '.[].address' ./mnt/pdms/conf/$sg/db.json)
sed -i "s%$curserver%$newserver%g" ./mnt/pdms/conf/$sg/db.json
echo "modify mnt successfully"


# copy new /mnt/pdms/conf/$sg to agent
result_copy=$(ansible-playbook ./copy-mnt.yml --private-key=./config-pdms/id_rsa --user=plcm -e "host=CUR_OPS_VM_HOSTNAME" -e sgid=$sg)
echo "$result_copy"
if [[ $result_copy =~ "unreachable=0" && $result_copy =~ "failed=0" ]]
then
    echo "copy ./mnt/pdms/conf/$sg successful"
else
    echo "copy ./mnt/pdms/conf/$sg failed"
    exit 4
fi


echo "clean up agent, including delete images, containers, volumes"
result_delete=$(ansible-playbook ./delete-images.yml --private-key=./config-pdms/id_rsa --user=plcm -e "host=CUR_OPS_VM_HOSTNAME")
echo "clean up done"

exit 0

