#!/bin/bash
# change id_rsa mode to 600
chmod 600 ./config-pdms/id_rsa

echo "linux harden"
result=$(ansible-playbook ./linux-harden.yml --private-key=./config-pdms/id_rsa --user=plcm -e "host=CUR_OPS_VM_HOSTNAME" -e "jumphost=CUR_JUMPHOST_NAME")
echo "$result"
if [[ $result =~ "unreachable=0" && $result =~ "failed=0" ]]
then
    echo "linux harden successful"
else
    echo "linux harden failed"
    exit 1
fi

exit 0
