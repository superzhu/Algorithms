#!/bin/bash

sg=$1

if [ "$sg"x == ""x ]; then
    echo "please add service group name"
    echo "use like this: ./go-rollback.sh CUR_OPSSG_NAME"
    exit 1
fi

# change id_rsa mode to 600
chmod 600 ./config-pdms/id_rsa

echo 'begin to update db.json under /mnt/pdms/conf/'
if [ ! -d "./mnt/pdms/conf/$sg" ]
then
    echo "create new service group: /mnt/pdms/conf/"$sg
    mkdir -p ./mnt/pdms/conf/$sg
    \cp -rf ./config-pdms/sg/* ./mnt/pdms/conf/$sg/
fi

file="./config-pdms/dbserver-backup.json"
if [ -f "$file" ]
then
  echo "$file found."
  newserver=$(jq -r '."db-server"' ./config-pdms/dbserver.json)
  if [[ $newserver == null ]]; then
    echo "db-server is null"
    exit 1
  fi
else
  echo "$file not found."
  exit 1
fi
curserver=$(jq -r '.[].address' ./mnt/pdms/conf/$sg/db.json)
sed -i "s%$curserver%$newserver%g" ./mnt/pdms/conf/$sg/db.json
echo "modify mnt successfully"

echo "copy ./mnt/pdms/conf/$sg to host"
result_copy=$(ansible-playbook ./copy-mnt.yml --private-key=./config-pdms/id_rsa --user=plcm -e "host=CUR_OPS_VM_HOSTNAME" -e sgid=$sg)
echo "$result_copy"
if [[ $result_copy =~ "unreachable=0" && $result_copy =~ "failed=0" ]]
then
    echo "copy ./mnt/pdms/conf/$sg successful"
else
    echo "copy ./mnt/pdms/conf/$sg failed"
    exit 1
fi

echo "begin to rollback swarm"
result=$(ansible-playbook -c paramiko rollback-swarm.yml --private-key=./config-pdms/id_rsa --user=plcm -e "host=CUR_OPS_VM_HOSTNAME")
echo "$result"
if [[ $result =~ "unreachable=0" && $result =~ "failed=0" ]]
then
    echo "execute rollback successfully"
else
    echo "execute rollback failed"
    exit 2
fi
echo 'sleep 180s waiting for swarm deploying'
sleep 180

exit 0
