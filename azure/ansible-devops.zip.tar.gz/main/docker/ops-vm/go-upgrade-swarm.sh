#!/bin/bash
chmod 600 ./config-pdms/id_rsa

sg=$1

# update mnt
echo "begin to exec update-mnt.sh"
./update-mnt.sh $sg
if [ $? != 0 ]; then
    echo "update-mnt.sh failed"
    exit 1
fi

echo "copy swarm to ops vm, and execute upgrade swarm"
result=$(ansible-playbook upgrade-swarm.yml --private-key=./config-pdms/id_rsa --user=plcm -e "host=CUR_OPS_VM_HOSTNAME")
echo "$result"
if [[ $result =~ "unreachable=0" && $result =~ "failed=0" ]]
then
    echo "execute ansible successful"
else
    echo "execute ansible failed"
    exit 1
fi

