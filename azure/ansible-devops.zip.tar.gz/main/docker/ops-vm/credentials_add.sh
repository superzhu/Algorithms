#!/bin/bash
alltitle=`sed -n 1p ./config-pdms/credentials`
echo $alltitle
title=`echo $alltitle | awk -F'[][]' '{print $2}'`
echo $title

if [ ! -f ~/.azure/credentials ]; then
  echo "~/.azure/credentials dose not exist, create one"
  mkdir -p ~/.azure
  \cp -rf ./config-pdms/credentials ~/.azure/
else
  grep -q $title ~/.azure/credentials
  if [ $? -eq 0 ]; then
    echo "credentials already existing"
  else
    echo "add new credentials"
    cat ./config-pdms/credentials >> ~/.azure/credentials
  fi

fi

