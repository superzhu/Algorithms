#!/usr/bin/python
# -*- coding: utf-8 -*-

import time
import datetime
import sys, getopt
import subprocess
import json
import os, stat
import os.path
import shutil
from configobj import ConfigObj
from collections import OrderedDict

# sys.path.append('./python')
from installer import *
from logging import exception

goBackupDbServer = './go-backupdbserver.sh {0}'
goServiceDown='./go-service-down.sh {0}'
goParseDockerCompose='./go-parse-docker-compose.sh {0}'
goServiceUp='./go-service-up.sh {0}'
goCheckVM='./go-check-vm.sh'
goDestroyServer='./go-destroy-server.sh {0}'
upgradeSwarm = './go-upgrade-swarm.sh {0}'
        
log = Log('installer')

opts, args = getopt.getopt(sys.argv[1:], 'h', ["address="])
# address = '172.21.120.233:11100'
# address = '13.85.27.5:80'
# address = '{0}:80'
address = ''
opsip = ''

def usage():
    print('go.py --address=<ip:port>')

if len(sys.argv) <= 1:
    usage()
    sys.exit()
    
for op, value in opts:
    if op == "--address":
        address = value
        log.info('address {0}'.format(address))
        opsip = address.split(":")[0]
        log.info('ip {0}'.format(opsip))
    else:
        usage()
        sys.exit()

if not address:
    usage()
    sys.exit() 


def checkJson(str):
    try:
        json.loads(str)
        return True
    except:
        return False


def mySwitch(var):
    return {
            'redis-master': 'REDIS',
            'redis': 'REDIS',
            'sentinel': 'SENTINEL',
            'rabbitmq': 'RABBITMQ',
            'nginx': 'NGINX',
            'filebeat-service': 'FILEBEAT',
            'telegraf-service': 'TELEGRAF',
            'house-keeping-service': 'HOUSE',
            'data-recovery-service': 'DATA',
            'image-service': 'IMAGE',
            'operation-management-service': 'OMS',
            'operation-service': 'OS',
            'operation-node-ui-service': 'UI',
            'upload-download-service': 'UPLOAD',
            'user-connector-service': 'USER',
    }.get(var,'ERROR') 
    
def parseConfig(newsg, configfilename, variablesname):
    try:
        with open(os.path.join('./config-pdms/', configfilename), 'r') as f:
            configdata = json.load(f)
        data = configdata['service-group-resource']
        with open('./config-pdms/servicedatabase.json', 'r') as f:
            dbdata = json.load(f)
        cf = ConfigObj(os.path.join('./roles/upgradeswarm/files/', variablesname))
        
        cf['LOCAL_SERVER_IP'] = 'CUR_OPS_VM_PRIIP'
        cf['OP_SG'] = 'CUR_OPSSG_NAME'
        cf['DATA_VERSION'] = dbdata['plcm-sg-service-database'][0]['data-version']
        cf['SCHEMA_VERSION'] = dbdata['plcm-sg-service-database'][0]['schema-version']
        
        for serviceinfo in data:
            service = serviceinfo['release-service-version']['micro-service-name']
            prefix = mySwitch(service)
            if prefix == 'ERROR':
                log.error('can not recognize this service: {0}'.format(service))
                return False
            log.info('service: {0}, prefix: {1}'.format(service, prefix))
            
            cf[prefix + '_IMAGE'] = serviceinfo['release-service-version']['build-image']
            cf[prefix + '_PORT'] = serviceinfo['service-port']
            attr = serviceinfo['container-servers-attribute']
            
            if attr != 'None' and attr != None:
                for index in range(len(attr)):
                    if attr[index]['name'] == 'Instance_Number' and attr[index]['value'] != None:
                        if not checkJson(attr[index]['value']):
                            log.info("parseConfig--Instance_Number of {0} is not a json format".format(service))
                            continue
                        cf[prefix + '_REP'] = json.loads(attr[index]['value'])
                    elif attr[index]['name'] == 'cpus' and attr[index]['value'] != None:
                        if not checkJson(attr[index]['value']):
                            log.info("parseConfig--cpus of {0} is not a json format".format(service))
                            continue
                        cf[prefix + '_CPUS'] = json.loads(attr[index]['value'])
                    elif attr[index]['name'] == 'mem' and attr[index]['value'] != None:
                        if not checkJson(attr[index]['value']):
                            log.info("parseConfig--mem of {0} is not a json format".format(service))
                            continue
                        cf[prefix + '_MEM'] = json.loads(attr[index]['value'])
                    else:
                        continue
            
            log.info('parse service: {0} done'.format(service))        
        cf.write()
            
            
    except BaseException as e:
        log.error(e)
        return False
    else:
        log.info('end of parseConfig')
        return True


def checkClusterid(appclusterid):
    try:  
        clusteridfile = os.path.join('./config-pdms/clusterid', appclusterid)
        if os.path.isfile(clusteridfile):
            log.info('cluster {0} is already running'.format(appclusterid))
            return True
        else:
            return False
    except BaseException as e:
        log.error(e)
        return False
    else:
        log.info('end of checkClusterid')
        return True

def generateAPP(appclusterid, clusterType):
    
    try:      
        mainPath = os.getcwd()
        log.info('working path: {0}'.format(mainPath))
        
        log.info('copy installer-app, app-pdms.json, app-idrsa, chmod 600 id_rsa, copy inventory/group_vars/dcos-prototype to {0}'.format(appclusterid))
        if os.path.exists(os.path.join('../', appclusterid)):
            log.info('ERROR -- ../{0} is already exists'.format(appclusterid))
            return False
        shutil.copytree('../../installer-app', os.path.join('../', appclusterid))
        shutil.copy('../../EnvParams/CUR_APP_ENV/app-pdms.json', os.path.join('../', appclusterid, 'config-pdms/sg/pdms.json'))
        shutil.copy('../../EnvParams/CUR_APP_ENV/app-idrsa', os.path.join('../', appclusterid, 'config-pdms/id_rsa'))
        os.chmod(os.path.join('../', appclusterid, 'config-pdms/id_rsa'), stat.S_IREAD|stat.S_IWRITE)
        
        log.info('replace all capital parameters of app script')
        # python has no better method to replace, so use shell
        with open(os.path.join('./config-pdms', appclusterid + '.json'), 'r') as f:
            appdata = json.load(f)
        filename = os.path.join('../', appclusterid)   
        shutil.copy(os.path.join('../', appclusterid, 'inventory/group_vars/dcos-prototype'), os.path.join('../', appclusterid, 'inventory/group_vars', appdata['app_resourcegroup_dcos']))
        
        paramdict = {
            'CURAPP_APP_LOCATION': 'app_location',
            'CURAPP_CREDENTIALS_ID': 'app_credentials_id',
            'CURAPP_SUBSCRIPTION_ID': 'app_subscription_id',
            'CURAPP_CLIENT_ID': 'app_client_id',
            'CURAPP_CLIENT_SECRET': 'app_client_secret',
            'CURAPP_TENANT_ID': 'app_tenant_id',
            'CURAPP_RESOURCEGROUP_INFRA': 'app_resourcegroup_infra',
            'CURAPP_RESOURCEGROUP_DCOS': 'app_resourcegroup_dcos',
            'CURAPP_JUMPHOST_NAME': 'app_jumphost',
            'CURAPP_JUMPHOST_IP': 'app_jumphost_ip',
            'CURAPP_DEPLOYMENT_NAME': 'app_deployment',
            'CURAPP_MASTER_LB': 'app_master_lb',
            'CURAPP_CLUSTER_ID': 'app_cluster_id',
            'CURAPP_OPS_CLUSTER_ID': 'ops_cluster_id',
            'CURAPP_OP_PUBIP': 'ops_pubip',
            'CURAPP_OP_SERVER': 'ops_server',
            'CURAPP_CERT_MODE': 'ops_cert_mode'
            }
        
            
        for key, value in paramdict.items():
            log.info('key: {0}, value: {1}, appdata_value: {2}'.format(key, value, appdata[value]))
            replacecmd = 'sed -i "s%' + key + '%' + appdata[value] + '%g" `grep -rl "' + key + '" ' + filename + '/`'
            log.info('execute command: {0}'.format(replacecmd))
            ( n, output ) = subprocess.getstatusoutput(replacecmd)
            if n != 0 :
                log.info('ERROR -- replace parameters failed, {0}'.format(output))
                return False
        
        replacecmd = 'sed -i "s%' + 'CURAPP_APPENV' + '%' + 'CUR_APP_ENV' + '%g" `grep -rl "' + 'CURAPP_APPENV' + '" ' + filename + '`'
        log.info('execute command: {0}'.format(replacecmd))
        ( n, output ) = subprocess.getstatusoutput(replacecmd)
        if n != 0 :
            log.info('ERROR -- replace parameters failed, {0}'.format(output))
            return False
        log.info('generate app script successfully')
        
        os.chdir(os.path.join('../', appclusterid))
        log.info('working path: {0}'.format(os.getcwd()))
        listcmd = ['./credentials_add.sh']
        if clusterType == "":
            listcmd.append('./go-prepare-existing-mnt.sh')
        for index in range(len(listcmd)):
            preparecmd = listcmd[index]
            log.info("execute: {0}".format(preparecmd))
            ( n, output ) = subprocess.getstatusoutput(preparecmd)
            if n != 0 :
                log.info('ERROR -- execute failed: {0}'.format(output))
                return False
        
        log.info('end of generateAPP')
        return True
    
    except BaseException as e:
        log.error(e)
        return False
    else:
        log.info('end of generateAPP')
        return True
    finally:
        log.info('return to main path: {0}'.format(mainPath))
        os.chdir(mainPath)        
        
    
def parseCluster(installer, appclusterid, clusterType=''):
    
    try:  
        # read config-pdms/app-cluster-config.json to get info
        with open('./config-pdms/app-cluster-config.json', 'r') as f:
            clusterdetaildata = json.load(f)
            
        if not checkJson(clusterdetaildata['extend-attribute']):
            log.info("extend-attribute in app-cluster-config.json is not a json format")
            return False
        clusterExtend = json.loads(clusterdetaildata['extend-attribute'])
        
        
        # read /opt/installer/EnvParams/CUR_APP_ENV/ops.json to get info
        with open('../../EnvParams/CUR_APP_ENV/ops.json', 'r') as f:
            opsjsondata = json.load(f)
        
        log.info('get ops sql server address to generate app script')
        dbServerJson = installer.loop(3, installer.getDbServer, opsjsondata['ops_sg'], '')
        if not dbServerJson:
            log.info("get db server failed.")
            return False
        log.info("ops sql server address is {0}".format(dbServerJson['db-server']))
        
        # copy config-pdms/app.json to appclusterid.json
        shutil.copy('./config-pdms/app.json', os.path.join('./config-pdms', appclusterid + '.json'))
         
        # update appclusterid.json content
        with open(os.path.join('./config-pdms', appclusterid + '.json'), 'r') as f:
            appclusterdata = json.load(f)
        # need to use below after app detail is complete in database
        #appclusterdata = json.loads('{}')    
        
        
        for key,value in clusterExtend.items():
            if key == 'jumphost-vm-name': 
                appclusterdata['app_jumphost'] = value
            elif key == 'jumphost-public-ip': 
                appclusterdata['app_jumphost_ip'] = value 
            elif key == 'jumphost-resource-group-name': 
                appclusterdata['app_resourcegroup_infra'] = value 
            elif key == 'load-balance-private-ip': 
                appclusterdata['app_master_lb'] = value   
            elif key == 'subscription.subscription name': 
                appclusterdata['app_credentials_id'] = value   
            elif key == 'subscription.subscription id': 
                appclusterdata['app_subscription_id'] = value   
            elif key == 'subscription.client-id': 
                appclusterdata['app_client_id'] = value   
            elif key == 'subscription.client-secret': 
                appclusterdata['app_client_secret'] = value   
            elif key == 'subscription.tenant-id': 
                appclusterdata['app_tenant_id'] = value   
            else:
                continue  
        
        appclusterdata['ops_cluster_id'] = 'CUR_CLUSTER_ID'
        appclusterdata['app_cluster_id'] = appclusterid
        appclusterdata['app_deployment'] = clusterdetaildata['cluster-name'][:-5]
        appclusterdata['app_resourcegroup_dcos'] = clusterdetaildata['cluster-name']
        appclusterdata['app_location'] = clusterdetaildata['location']
        
        appclusterdata['ops_pubip'] = opsjsondata['ops_vm_pubip']
        appclusterdata['ops_cert_mode'] = opsjsondata['cert_mode']
        appclusterdata['ops_server'] = dbServerJson['db-server']
        
        with open(os.path.join('./config-pdms', appclusterid + '.json'), 'w') as f:
            json.dump(appclusterdata, f, indent=2)
        
        
        log.info('generate app script of cluster: {0}'.format(appclusterid)) 
        if not generateAPP(appclusterid, clusterType):
            log.info('generateAPP failed') 
            return False
        
    except BaseException as e:
        log.error(e)
        return False
    else:
        log.info('end of parseCluster')
        return True

def prepareCluster(appclusterid):
    try:  
        mainPath = os.getcwd()
        log.info('working path: {0}'.format(mainPath))
        log.info("change pwd to ../{0} ".format(appclusterid))
        os.chdir("../" + appclusterid)
        log.info("current pwd is {0} ".format(os.getcwd()))
        #preparecom = ['./go-prepare-existing-mnt.sh', './go-prepare.sh']
        preparecom = ['./go-prepare.sh']
        for index in range(len(preparecom)):
            pcmd = preparecom[index]
            log.info('execute: {0} under: {1}'.format(pcmd, appclusterid))
            ( n, output ) = subprocess.getstatusoutput(pcmd)
            if n == 0 :
                log.info("successfully")
            else:
                log.info("failed with: {0}".format(output))
                return False
        
    except BaseException as e:
        log.error(e)
        return False
    else:
        log.info('end of prepareCluster')
        return True
    finally:
        log.info('return to main path: {0}'.format(mainPath))
        os.chdir(mainPath)        

def deployClusterBaseService(appclusterid):
    try:  
        mainPath = os.getcwd()
        log.info('working path: {0}'.format(mainPath))
        log.info("change pwd to ../{0} ".format(appclusterid))
        os.chdir("../" + appclusterid)
        log.info("current pwd is {0} ".format(os.getcwd()))
        preparecom = './go-deploy-marathonlb-filetele.sh'
        ( n, output ) = subprocess.getstatusoutput(preparecom)
        if n == 0 :
            log.info("deploy cluster {0} base service marathon-lb-pdms, filebeat, telegraf successfully".format(appclusterid))
            log.info("output {0}".format(output))
        else:
            log.info("deploy cluster {0} base service marathon-lb-pdms, filebeat, telegraf failed with error code {1}".format(appclusterid, n))
            log.info("error output {0}".format(output))
            return False
        return True
    except BaseException as e:
        log.error(e)
        return False
    else:
        log.info('end of deployClusterBaseService')
        return True
    finally:
        log.info('return to main path: {0}'.format(mainPath))
        os.chdir(mainPath)        

def runCluster(appclusterid):
    try:  
        mainPath = os.getcwd()
        log.info('working path: {0}'.format(mainPath))
        # check 
        clusteridfile = os.path.join('./config-pdms/clusterid', appclusterid)
        if os.path.isfile(clusteridfile):
            log.info('cluster {0} is already running'.format(appclusterid))
            return False
        
        # create ./config-pdms/clusterid/appclusterid file
        log.info('create clusterid file under ./config-pdms/clusterid for cluster {0}'.format(appclusterid))
        with open(clusteridfile, 'w') as f:
            f.write(appclusterid)
        
        log.info('run python process of cluster {0}'.format(appclusterid))
        with open('../../EnvParams/CUR_APP_ENV/ops.json', 'r') as f:
            opsjsondata = json.load(f)
        
        log.info("change pwd to ../{0} ".format(appclusterid))
        os.chdir("../" + appclusterid)
        log.info("current pwd is {0}".format(os.getcwd()))
            
        runcom = 'nohup python ' + os.getcwd() + '/go.py --address=' + opsjsondata['ops_vm_pubip'] + ':443 > /dev/null 2>&1 &'
        log.info("run app python: {0}".format(runcom))
        ( n, output ) = subprocess.getstatusoutput(runcom)
        if n == 0 :
            log.info("run cluster {0} python process successfully".format(appclusterid))
            log.info("run cluster {0} python process output: {1}".format(appclusterid, output))
        else:
            log.info("run cluster {0} python process failed {1}".format(appclusterid, output))
            return False
        return True
        
    except BaseException as e:
        log.error(e)
        return False
    else:
        log.info('end of runCluster')
        return True
    finally:
        log.info('return to main path: {0}'.format(mainPath))
        os.chdir(mainPath)  

def parseOPSCluster():
    try:  
        with open('./config-pdms/ops-cluster-config.json', 'r') as f:
            clusterdetaildata = json.load(f)
            
        if not checkJson(clusterdetaildata['extend-attribute']):
            log.info("extend-attribute in ops-cluster-config.json is not a json format")
            return False
        clusterExtend = json.loads(clusterdetaildata['extend-attribute'], object_pairs_hook=OrderedDict) 
        with open('./config-pdms/ops-cluster-extend.json', 'w') as f:
            json.dump(clusterExtend, f, indent=2, sort_keys=True)
        
# 2019.1.10 change to open a null json, this will clear old file and fill with all new key and value    
#         with open('./config-pdms/sg/orion.json', 'r') as f:
#             oriondata = json.load(f)
#         with open('./config-pdms/sg/azure.json', 'r') as f:
#             azuredata = json.load(f)
        oriondata = json.loads('{}')
        azuredata = json.loads('{}')
            
        for key,value in clusterExtend.items():
            if key == 'azure.azureStorage-account':
                azuredata['azureStorageAccount'] = value
            elif key == 'orion.cloudRelayApiAddress':
                azuredata['cloudRelayApiAddress'] = value
            elif key == 'orion.cloudRelayApiNamespace':
                azuredata['cloudRelayApiNamespace'] = value
            elif key == 'orion.cloudRelayApiEnv':
                azuredata['cloudRelayApiEnv'] = value
            elif key == 'orion.cloudRelayApiCode':
                azuredata['cloudRelayApiCode'] = value
            elif key == 'orion.cloudRelayApiCodeForCRList':
                azuredata['cloudRelayApiCodeForCRList'] = value
            elif key == 'orion.maUrl':
                azuredata['maUrl'] = value
            elif key == 'orion.aquaApiCode':
                azuredata['aquaApiCode'] = value
            elif key == 'orion.aquaNamespace':
                azuredata['aquaNamespace'] = value
            elif key.startswith('azure.'):
                azuredata[key[6:]] = value
            elif key == 'orion.tenantSubject':
                oriondata['subject'] = value
            elif key == 'orion.Service-Tenant-ID':
                oriondata['tid'] = value
            elif key == 'orion.appendix':
                oriondata['appendix'] = value
            elif key == 'orion.opssystemConfigurationDomainName':
                oriondata['clusterDomainName'] = value
            elif key == 'orion.Orion-tenantUrl':
                oriondata['url'] = value
            elif key == 'orion.pholioserviceDirectoryUrl':
                oriondata['pholioServiceDirectoryUrl'] = value
            elif key == 'orion.Orion-userAuthServiceName':
                oriondata['userAuthServiceName'] = value
            elif key == 'orion.pholioUserProfileUrl':
                oriondata['pholioUserProfileUrl'] = value
            elif key == 'orion.licensingApiUrl':
                oriondata['licensingApiUrl'] = value
            elif key == 'orion.userAuthApiVersion':
                oriondata['userAuthApiVersion'] = value
            elif key == 'orion.userAuthLoginApiMethod':
                oriondata['userAuthLoginApiMethod'] = value
            elif key == 'orion.userAuthLogoutApiMethod':
                oriondata['userAuthLogoutApiMethod'] = value
            elif key == 'orion.pdmsLoginRedirectUrl':
                oriondata['pdmsLoginRedirectUrl'] = value
            elif key == 'orion.opsLogoutRedirectUrl':
                oriondata['pdmsLogoutRedirectUrl'] = value
            elif key == 'orion.opsSSOJWT.appId':
                oriondata['appId'] = value
            elif key == 'orion.appJWT.appId':
                oriondata['tenantAppId'] = value
            elif key == 'orion.opsSSOJWT.secret':
                oriondata['secrets'] = value
            elif key == 'orion.appJWT.secret':
                oriondata['tenantSecret'] = value
            elif key == 'orion.tenantSubscribeUrl':
                oriondata['tenantSubscribeUrl'] = value
            elif key == 'orion.appsystemConfigurationDomainName' or key == 'orion.pdmsLogoutRedirectUrl':
                pass
            elif key.startswith('orion.'):
                oriondata[key[6:]] = value
            else:
                continue
        
        log.info('save new orion.json and azure.json to config-pdms/sg/ to update template')
        with open('./config-pdms/sg/orion.json', 'w') as f:
            json.dump(oriondata, f, indent=2, sort_keys=True)
        with open('./config-pdms/sg/azure.json', 'w') as f:
            json.dump(azuredata, f, indent=2, sort_keys=True)
            
    except BaseException as e:
        log.error(e)
        return False
    else:
        log.info('end of parseOPSCluster')
        return True
                    
        
def updateServiceGroupState(installer, serviceGroupId, state):
    r = installer.loop(3, installer.updateServiceGroupState, serviceGroupId, state)
    if not r:
        log.info("update service group state to {0} failed.".format(state))
        return
    return True

def fetchDbServerJson(installer, serviceGroupId, jsonFileName, serverType=''):
    dbServerJson = installer.loop(3, installer.getDbServer, serviceGroupId, serverType)
    if not dbServerJson:
        log.info("get db server {0} failed.".format(jsonFileName))
        return
    log.info('write db server json to config-pdms/{0}'.format(jsonFileName))
    installer.writeJson(dbServerJson, 'config-pdms/', jsonFileName) 
    return dbServerJson   

def fetchServiceDatabaseJson(installer, serviceGroupId, dbserver, jsonFileName):
    serviceDatabaseJson = installer.loop(3, installer.searchServiceDatabases, serviceGroupId, dbserver)
    if not serviceDatabaseJson:
        log.info("get service databases failed.")
        return
    log.info('write service databases json to config-pdms/servicedatabase.json')
    installer.writeJson(serviceDatabaseJson, 'config-pdms/', jsonFileName)
    return serviceDatabaseJson
        
def fetchServiceGroupDetail(installer, serviceGroupId, fileName, detailType=''):
    serviceGroupDetail = installer.loop(3, installer.readServiceGroupDetail, serviceGroupId, detailType)
    if  not serviceGroupDetail:
        log.info('get service group detail failed.')
        return
    log.info('save service config detail')
    installer.writeJson(serviceGroupDetail, 'config-pdms/', fileName)
    return serviceGroupDetail  
        

'''
upgrade service group
'''
def upgrade(installer, serviceGroup, clusterId):
    
    log.info('============= begin to upgrade {0}'.format(serviceGroup.serviceGroupId))
    
    log.info('check vm')
    ( r, output ) = installer.execCommand(goCheckVM)
    
    log.info('get current db server')
    dbServerJson = fetchDbServerJson(installer, serviceGroup.serviceGroupId, 'dbserver.json')
    if not dbServerJson:
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'ops_upgrade_ready', 'installer_error_ops_0001', 'get current db server failed.')
        log.info('get current db server failed')
        return
    
    log.info('get service databases of current db server')
    if not fetchServiceDatabaseJson( installer, serviceGroup.serviceGroupId, dbServerJson['db-server'], 'servicedatabase.json'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'ops_upgrade_ready', 'installer_error_ops_0002', 'get service databases of current db server failed.')
        log.info('get service databases of current db server failed')
        return
    
    log.info('get backup db server')
    dbServerBackupJson = fetchDbServerJson(installer, serviceGroup.serviceGroupId, 'dbserver-backup.json', 'backuped')
    if not dbServerBackupJson:
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'ops_upgrade_ready', 'installer_error_ops_0003', 'get backup db server failed.')
        log.info('get backup db server failed')
        return
    
    log.info('fetch current/backuped service group detail')
    if not fetchServiceGroupDetail( installer, serviceGroup.serviceGroupId, 'service-config-backuped.json', 'backuped'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'ops_upgrade_ready', 'installer_error_ops_0004', 'fetch current/backuped service group detail failed.')
        log.info('fetch current/backuped service group detail failed')
        return  
    
    log.info('fetch new service group detail')
    if not fetchServiceGroupDetail( installer, serviceGroup.serviceGroupId, 'service-config.json'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'ops_upgrade_ready', 'installer_error_ops_0005', 'fetch new service group detail failed.')
        log.info('fetch new service group detail failed')
        return  
    
    log.info('backup db server')
    ( r, output ) = installer.execCommand(goBackupDbServer.format(dbServerBackupJson['db-server-short-name']))
    if not r:
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'ops_upgrade_ready', 'installer_error_ops_0006', 'backup db server failed.')
        log.info('backup db server failed')
        return
    
    log.info('update service group state to ops_upgrade_start') 
    if not updateServiceGroupState(installer, serviceGroup.serviceGroupId, 'ops_upgrade_start'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'ops_upgrade_ready', 'installer_error_ops_0007', 'update service group state to ops_upgrade_start failed.')
        log.info('update service group state to ops_upgrade_start failed') 
        return
    
    log.info('parse config-pdms/service-config.json to generate docker-swarm.yml')
    if not parseConfig(serviceGroup.serviceGroupId, 'service-config.json', 'variables.env'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'ops_upgrade_start', 'installer_error_ops_0010', 'parse service-config.json failed.')
        log.info('parse service-config.json failed')
        return
    
    log.info('parse config-pdms/service-config-backuped.json to generate docker-swarm-backuped.yml')
    if not parseConfig(serviceGroup.serviceGroupId, 'service-config-backuped.json', 'variables-backuped.env'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'ops_upgrade_start', 'installer_error_ops_0010', 'parse service-config.json failed.')
        log.info('parse service-config.json failed')
        return
    
    
    
    
    
    log.info('fetch operation cluster detail to get orion.json and azure.json from extent-attribute')
    clusterDetail = installer.loop(3, installer.readAPPCluster, clusterId)
    if not clusterDetail:
        log.info('fetch ops cluster detail failed')
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'ops_upgrade_start', 'installer_error_ops_00012', 'fetch ops cluster detail failed.')
        return
    
    log.info('save ops cluster detail to config-pdms/ops-cluster-config.json')
    installer.writeJson(clusterDetail, 'config-pdms/', 'ops-cluster-config.json') 
    
    log.info('parse ops-cluster-config.json to generate orion.json and azure.json') 
    if not parseOPSCluster():
        log.info('parseOPSCluster failed')
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'ops_upgrade_start', 'installer_error_ops_00013', 'parseOPSCluster failed.')
        return
    
    log.info('upgrade swarm')
    ( r, output ) = installer.execCommand(upgradeSwarm.format(serviceGroup.serviceGroupId))
    if not r:
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'ops_upgrade_start', 'installer_error_ops_0011', 'upgrade swarm failed.')
        log.info('upgrade swarm failed')
        return
    
    log.info('end-of-ops-upgrade')
        
'''
'''
def destroy(installer, serviceGroup):
        
    log.info('============= begin to destroy {0}'.format(serviceGroup.serviceGroupId))
    
    log.info('update service state to sg_delete_start') 
    if not updateServiceGroupState(installer, serviceGroup.serviceGroupId, 'sg_delete_start'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_delete_ready', 'installer_error_ops_0011', 'update status failed.')
        log.info('update service state to sg_delete_start failed') 
        return
    
    log.info('get db server')
    dbServerJson = fetchDbServerJson(installer, serviceGroup.serviceGroupId, 'dbserver.json')
    if not dbServerJson:
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_delete_start', 'installer_error_ops_0012', 'get db server failed.')
        log.info('get db server failed')
        return
    
    log.info('destroy service group and server')
    ( r, output ) = installer.execCommand(goDestroyServer.format(dbServerJson['db-server-short-name']))
    if not r:
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_delete_start', 'installer_error_ops_0013', 'destroy service group failed.')
        log.info('destroy service group and server failed')
        return
    
    log.info('update service group state to sg_delete_end') 
    r = installer.loop(3, installer.updateServiceGroupState, serviceGroup.serviceGroupId, 'sg_delete_end')
    if not r:
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_delete_start', 'installer_error_ops_0014', 'update status failed.')
        log.info("update service group state failed.")
        return
    
    log.info('end-of-destroy')

'''
add new APP Cluster
'''
def addAPPCluster(installer, appclusterid):
    
    log.info('============= begin to add new APP Cluster {0}'.format(appclusterid))
    
    # get cluster detail, write to config-pdms/app-cluster-config.json
    log.info('fetch app cluster detail') 
    clusterDetail = installer.loop(3, installer.readAPPCluster, appclusterid)
    if not clusterDetail:
        log.info('fetch app cluster detail failed')
        if not installer.loop(3, installer.updateAPPClusterState, appclusterid, 'DISCONNECTED', 'fetch app cluster detail failed'):
            log.info('update status of cluster failed')
        return
    
    log.info('save app cluster detail config-pdms/app-cluster-config.json')
    installer.writeJson(clusterDetail, 'config-pdms/', 'app-cluster-config.json') 
    
    # parse config-pdms/app-cluster-config.json, generate appclusterid app script 
    log.info('parse app-cluster-config.json, generate {0}.json, generate {0} script'.format(appclusterid)) 
    if not parseCluster(installer, appclusterid, "new"):
        log.info('parseCluster failed')
        if not installer.loop(3, installer.updateAPPClusterState, appclusterid, 'DISCONNECTED', 'parseCluster failed'):
            log.info('update status of cluster failed')
        return
        
    # execute go-prepare.sh to prepare new env for new cluster
    log.info('execute go-prepare.sh to prepare env for new cluster {0}, this will take a while.'.format(appclusterid))
    if not prepareCluster(appclusterid):
        log.info('prepareCluster failed')
        if not installer.loop(3, installer.updateAPPClusterState, appclusterid, 'DISCONNECTED', 'prepareCluster failed'):
            log.info('update status of cluster failed')
        return
    
    log.info('execute go-deploy-marathonlb-filetele.sh to deploy marathon-lb-pdms, filebeat, telegraf fo cluster {0}'.format(appclusterid))
    if not deployClusterBaseService(appclusterid):
        log.info('deployClusterBaseService failed')
        if not installer.loop(3, installer.updateAPPClusterState, appclusterid, 'DISCONNECTED', 'deployClusterBaseService failed'):
            log.info('update status of cluster failed')
        return
    
    # run python process
    log.info('start python process of cluster {0}'.format(appclusterid))
    if not runCluster(appclusterid):
        log.info('runCluster failed')
        if not installer.loop(3, installer.updateAPPClusterState, appclusterid, 'DISCONNECTED', 'runCluster failed'):
            log.info('update status of cluster failed')
        return
    
    # update cluster status
    log.info('update app cluster state to CONNECTED') 
    r = installer.loop(3, installer.updateAPPClusterState, appclusterid, 'CONNECTED', 'add app cluster successfully')
    if not r:
        installer.loop(3, installer.updateAPPClusterState, appclusterid, 'DISCONNECTED', 'update app cluster status failed')
        log.info("update app cluster state failed.")
        return
    
    log.info('end-of-add-new-APP-Cluster')

'''
run existing APP Cluster
'''
def runAPPCluster(installer, appclusterid):
    
    log.info('============= begin to run existing APP Cluster {0}'.format(appclusterid))
    
    # get cluster detail, write to config-pdms/app-cluster-config.json
    log.info('fetch app cluster detail') 
    clusterDetail = installer.loop(3, installer.readAPPCluster, appclusterid)
    if  not clusterDetail:
        log.info('fetch app cluster detail failed')
        if not installer.loop(3, installer.updateAPPClusterState, appclusterid, 'DISCONNECTED', 'fetch app cluster detail failed'):
            log.info('update status of cluster failed')
        return
    
    log.info('save app cluster detail config-pdms/app-cluster-config.json')
    installer.writeJson(clusterDetail, 'config-pdms/', 'app-cluster-config.json') 
    
    # parse config-pdms/app-cluster-config.json, generate appclusterid app script 
    log.info('parse app-cluster-config.json, generate {0}.json, generate {0} script'.format(appclusterid)) 
    if not parseCluster(installer, appclusterid):
        log.info('parseCluster failed')
        if not installer.loop(3, installer.updateAPPClusterState, appclusterid, 'DISCONNECTED', 'parseCluster failed'):
            log.info('update status of cluster failed')
        return
    
    # run python process
    log.info('run python process of cluster {0}'.format(appclusterid))
    if not runCluster(appclusterid):
        log.info('runCluster failed')
        if not installer.loop(3, installer.updateAPPClusterState, appclusterid, 'DISCONNECTED', 'runCluster failed'):
            log.info('update status of cluster failed')
        return
    
    log.info('end-of-run-existing-APP-Cluster')
            
def upgradeAll(clusterId):
    installer = Installer(address)
    serviceGroupList = installer.loop(3, installer.searchServiceGroups, clusterId, 'Operation', 'ops_upgrade_ready')
    if( (not serviceGroupList) or ( len(serviceGroupList) == 0 ) ): 
        log.info('no ops_upgrade_ready service group found.') 
    else:
        for serviceGroup in serviceGroupList:    
            log.info(serviceGroup.toString())
            if serviceGroup.state == 'ops_upgrade_ready':
                upgrade(installer, serviceGroup, clusterId)

def destroyAll(clusterId):
    log.info('search service group with state=sg_delete_ready, they are to be destroyed')
    installer = Installer(address)
    serviceGroupList = installer.loop(3, installer.searchServiceGroups, clusterId, 'Operation', 'sg_delete_ready')
    if( (not serviceGroupList) or ( len(serviceGroupList) == 0 ) ): 
        log.info('no sg_delete_ready service group found.')
    else:
        for serviceGroup in serviceGroupList:
            log.info(serviceGroup.toString())
            if serviceGroup.state == 'sg_delete_ready':
                destroy(installer, serviceGroup)

def addNewAPPCluster(clusterId):
    installer = Installer(address)
    clusterList = installer.loop(3, installer.searchAPPCluster, 'INITIAL')
    if( (not clusterList) or ( len(clusterList) == 0 ) ): 
        log.info('no INITIAL app cluster found.') 
    else:
        for appclusterid in clusterList:    
            log.info('new app cluster id:{0}'.format(appclusterid))
            addAPPCluster(installer, appclusterid)

def runExistingAPPCluster(clusterId):
    installer = Installer(address)
    clusterList = installer.loop(3, installer.searchAPPCluster, 'CONNECTED')
    if( (not clusterList) or ( len(clusterList) == 0 ) ): 
        log.info('no CONNECTED app cluster found.') 
    else:
        for appclusterid in clusterList:  
            # check if this appclusterid python process already exists
            log.info('check if this cluster {0} of status with CONNECTED is already running'.format(appclusterid))
            if not checkClusterid(appclusterid):
                log.info('cluster {0} is not running, will start to run it'.format(appclusterid))
                runAPPCluster(installer, appclusterid)

                
while(True):
    
        upgradeAll('CUR_CLUSTER_ID')
        
        destroyAll('CUR_CLUSTER_ID')
        
        addNewAPPCluster('CUR_CLUSTER_ID')
        
        runExistingAPPCluster('CUR_CLUSTER_ID')
            
        log.info('wait next loop, sleep 10s.')
        time.sleep(10)        
    
log.info('end of loop')









