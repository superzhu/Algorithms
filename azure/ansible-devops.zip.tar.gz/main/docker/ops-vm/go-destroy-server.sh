#!/bin/bash

servername=$1
echo "begin to destroy sql server: "$servername

# get token
echo "get token"
curl -X "POST" "https://login.microsoftonline.com/CUR_TENANT_ID/oauth2/token" \
-H "Cookie: flight-uxoptin=true; stsservicecookie=ests; x-ms-gateway-slice=productionb; stsservicecookie=ests" \
-H "Content-Type: application/x-www-form-urlencoded" \
--data-urlencode "client_id=CUR_CLIENT_ID" \
--data-urlencode "grant_type=client_credentials" \
--data-urlencode "client_secret=CUR_CLIENT_SECRET" \
--data-urlencode "resource=https://management.azure.com/" > ./config-pdms/server/token.json
token=$(jq -r '.access_token' ./config-pdms/server/token.json)
echo $token
if [ $token == null ];then
    echo "get token failed"
    exit 1
fi


# delete database
#for dbname in $db
#do
#    echo "delete database: "$dbname
#    \cp -rf ./config-pdms/server/destroydb.sh ./
#    sed -i "s/TOKEN/$token/g" ./destroydb.sh
#    sed -i "s/SERVERNAME/$servername/g" ./destroydb.sh
#    sed -i "s/DBNAME/$dbname/g" ./destroydb.sh
#    ./destroydb.sh
#done

# destroy sql server
echo "destroy sql server: "$servername
\cp -rf ./config-pdms/server/destroydbserver.sh ./
sed -i "s/TOKEN/$token/g" ./destroydbserver.sh
sed -i "s/SERVERNAME/$servername/g" ./destroydbserver.sh
./destroydbserver.sh


exit 0
