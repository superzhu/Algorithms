#!/bin/bash

# change id_rsa mode to 600
chmod 600 ./config-pdms/id_rsa

echo "config redis, execute redis-config.sh"
result=$(ansible-playbook ./redis-config.yml --private-key=./config-pdms/id_rsa --user=plcm -e "host=CUR_OPS_VM_HOSTNAME")
echo "$result"
if [[ $result =~ "unreachable=0" && $result =~ "failed=0" ]]
then
    echo "redis config successful"
else
    echo "redis config failed"
    exit 1
fi

exit 0
