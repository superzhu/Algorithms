#!/bin/bash

# change id_rsa mode to 600
chmod 600 ./config-pdms/id_rsa


echo "log config"
result=$(ansible-playbook ./log-config.yml --private-key=./config-pdms/id_rsa --user=plcm  -e "host=CUR_OPS_VM_HOSTNAME")
echo "$result"
if [[ $result =~ "unreachable=0" && $result =~ "failed=0" ]]
then
    echo "add log rollover successful"
else
    echo "add log rollover failed"
    exit 1
fi

echo "syslog config, execute change_log_rotate.sh"
result=$(ansible-playbook ./syslog-config.yml --private-key=./config-pdms/id_rsa --user=plcm  -e "host=CUR_OPS_VM_HOSTNAME")
echo "$result"
if [[ $result =~ "unreachable=0" && $result =~ "failed=0" ]]
then
    echo "syslog config successful"
else
    echo "syslog config failed"
    exit 2
fi

exit 0
