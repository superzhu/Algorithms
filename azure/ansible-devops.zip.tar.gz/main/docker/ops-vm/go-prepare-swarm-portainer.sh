#!/bin/bash

# change id_rsa mode to 600
chmod 600 ./config-pdms/id_rsa

echo "prepare swarm and portainer on ops vm"
result=$(ansible-playbook prepare-swarm-portainer.yml --private-key=./config-pdms/id_rsa --user=plcm -e "host=CUR_OPS_VM_HOSTNAME")
echo "$result"
exit 0
