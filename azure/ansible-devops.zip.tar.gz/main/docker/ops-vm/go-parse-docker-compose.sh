#!/bin/bash

sg=$1

# change id_ras mode to 600
chmod 600 ./config-pdms/id_rsa
chmod +x ./docker-compose/parser.sh

# parse
echo "parser.sh"
cd docker-compose
./parser.sh $sg
if [ $? != 0 ]; then
    echo "parser.sh failed"
    exit 1
fi

exit 0
