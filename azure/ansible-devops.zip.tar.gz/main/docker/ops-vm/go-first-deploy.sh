#!/bin/bash

# change id_rsa mode to 600
chmod 600 ./config-pdms/id_rsa

sg=$1

if [ "$sg"x == ""x ]; then
    echo "please add service group name"
    echo "use like this: ./go-first-deploy.sh CUR_OPSSG_NAME"
    exit 1
fi

if [ ! -d "./mnt/pdms/conf/$sg" ]
then
    echo "create new service group: /mnt/pdms/conf/"$sg
    mkdir -p ./mnt/pdms/conf/$sg
    \cp -rf ./config-pdms/sg/* ./mnt/pdms/conf/$sg/
fi

echo "copy ./mnt/pdms/conf/$sg to host"
result_copy=$(ansible-playbook ./copy-mnt.yml --private-key=./config-pdms/id_rsa --user=plcm -e "host=CUR_OPS_VM_HOSTNAME" -e sgid=$sg)
echo "$result_copy"
if [[ $result_copy =~ "unreachable=0" && $result_copy =~ "failed=0" ]]
then
    echo "copy ./mnt/pdms/conf/$sg successful"
else
    echo "copy ./mnt/pdms/conf/$sg failed"
    exit 2
fi

# service up
echo "copy service-up to ops-vm and execute shell command"
result=$(ansible-playbook -c paramiko ./service-up.yml --private-key=./config-pdms/id_rsa --user=plcm -e "host=CUR_OPS_VM_HOSTNAME" -e "deploy=deploy")
echo "$result"
if [[ $result =~ "unreachable=0" && $result =~ "failed=0" ]]
then
    echo "execute service-up.yml successfully"
else
    echo "execute service-up.yml failed"
    exit 3
fi

exit 0
