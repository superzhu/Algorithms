#!/bin/bash

#sed 's/ //g' variables-backuped.env > .env
#docker-compose config > docker-swarm-backuped.yml

#if [[ ! -s 'docker-swarm-backuped.yml' ]]; then
#  echo 'something wrong with generage docker-swarm-backuped.yml'
#  exit 1
#fi


echo 'rm stack'
docker stack rm CUR_OPSSG_NAMEswarm
echo 'sleep 60'
sleep 60
echo 'rollback swarm'
docker stack deploy -c docker-swarm-backuped.yml CUR_OPSSG_NAMEswarm --with-registry-auth

exit 0
