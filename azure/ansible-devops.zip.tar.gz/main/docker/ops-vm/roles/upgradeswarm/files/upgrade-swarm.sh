#!/bin/bash


echo 'support forward compatbility with docker-compose, execute stop.sh to docker-compose'
nohup /home/plcm/ops-vm/docker-compose/service-down/stop.sh > /dev/null 2>&1 &

echo 'sleep 60s'
sleep 60

swarm_name=CUR_OPSSG_NAMEswarm
echo $swarm_name

echo 'generate docker-swarm-backuped.yml'
sed 's/ //g' variables-backuped.env > .env
docker-compose config > docker-swarm-backuped.yml

if [[ ! -s 'docker-swarm-backuped.yml' ]]; then
  echo 'something wrong with generage docker-swarm-backuped.yml'
  exit 1
fi

echo 'generate docker-swarm.yml'
sed 's/ //g' variables.env > .env
docker-compose config > docker-swarm.yml

if [[ ! -s 'docker-swarm.yml' ]]; then
  echo 'something wrong with generage docker-swarm.yml'
  exit 2
fi

echo 'rm stack'
docker stack rm $swarm_name
echo 'sleep 60'
sleep 60

echo 'deploy swarm'
docker stack deploy -c docker-swarm.yml $swarm_name --with-registry-auth
echo 'sleep 120'
sleep 120

echo 'force update service except redis, sentinel and rabbitmq for depending requirement'
service_list=`docker stack services $swarm_name | awk '{print $2}'`
for service in $service_list
do
  echo $service
  if [[ $service =~ 'NAME' ]]; then
    continue
  elif [[ $service =~ 'redis' || $service =~ 'sentinel' || $service =~ 'rabbitmq' ]]; then
    echo "is redis, sentinel, rabbitmq"
  else
    echo "force update $service"
    docker service update $service
  fi
done


exit 0
