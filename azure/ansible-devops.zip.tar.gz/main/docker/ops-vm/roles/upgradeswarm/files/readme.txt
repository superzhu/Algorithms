# first deploy:
docker stack deploy [options] stackname

# upgrade any parameters of service:
docker service update --image imagename servicename
		      --limit-cpu 0.3 servicename
		      -- ...

# rollback/revert a specified service to its previous version from swarm
docker service rollback servicename

# scale one or more service to specified numbers: (can not scale global mode service)
docker service scale servicename=3

# just restart service with no parameter changes:
docker service update --force servicename

# list info:
docker stack ls
docker stack ps
docker stack services
docker service ls
docker service ps
docker service inspect

# delete/remove stack(all service):
docker stack rm stackname 

# delete/remove some service:
docker service rm servicename 
