#!/bin/bash

echo 'generate portainer password'
echo -n Polycom123 | docker secret create portainer-pass -

echo 'create network portainer_agent_network'
docker network create --driver overlay --attachable portainer_agent_network

echo 'create service portainer_agent'
docker service create \
    --name portainer_agent \
    --network portainer_agent_network \
    -e AGENT_CLUSTER_ADDR=tasks.portainer_agent \
    --mode global \
    --constraint 'node.platform.os == linux' \
    --mount type=bind,src=//var/run/docker.sock,dst=/var/run/docker.sock \
    --mount type=bind,src=//var/lib/docker/volumes,dst=/var/lib/docker/volumes \
    portainer/agent

echo 'create service portainer'
docker service create \
    --name portainer \
    --network portainer_agent_network \
    --secret portainer-pass \
    --publish 9000:9000 \
    --replicas=1 \
    --constraint 'node.role == manager' \
    --mount type=bind,src=/var/run/docker.sock,dst=/var/run/docker.sock \
    --mount type=bind,src=/var/lib/docker/volumes,dst=/var/lib/docker/volumes \
    --mount type=bind,src=/home/plcm/portainer/data,dst=/data \
    portainer/portainer \
    --admin-password-file '/run/secrets/portainer-pass' \
    -H unix:///var/run/docker.sock

