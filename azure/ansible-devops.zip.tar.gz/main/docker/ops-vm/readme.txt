# prepare env
./go-prepare.sh

# first deploy on ops vm
./go-first-deploy.sh

# run:
python go.py --address=CUR_OPS_VM_PUBIP:443

# run in background:
nohup python go.py --address=CUR_OPS_VM_PUBIP:443 > /dev/null 2>&1 &

# check:
ps -ef | grep python

# kill:
kill pid

