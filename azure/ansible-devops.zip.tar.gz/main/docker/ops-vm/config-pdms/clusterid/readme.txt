save running clusterid
