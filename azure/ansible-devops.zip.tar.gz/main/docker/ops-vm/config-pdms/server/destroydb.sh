#!/bin/bash

curl -X "DELETE" "https://management.azure.com/subscriptions/CUR_SUBSCRIPTION_ID/resourceGroups/CUR_RESOURCEGROUP_INFRA/providers/Microsoft.Sql/servers/SERVERNAME/databases/DBNAME?api-version=2014-04-01" \
-H "Authorization: Bearer TOKEN"
