#!/bin/bash

sg=$1
### fqdn can be combined by redis and sg
#fqdn = "redis."$sg"marathon.mesos"
redis_num=3
sentinel_insnum=3

redis_port=$(jq .container.docker.portMappings[0].containerPort ./json-ma-lb/redis.json)
sentinel_port=$(jq .container.docker.portMappings[0].containerPort ./json-ma-lb/sentinel.json)

echo "update args of redis.json and sentinel.json"
cur_redis_sg='"'$(echo $(jq .args ./json-ma-lb/redis.json) | awk -F\" '{print $2}')'"'
cur_redis_port='"'$(echo $(jq .args ./json-ma-lb/redis.json) | awk -F\" '{print $4}')'"'
new_redis_sg='"'$sg'"'
new_redis_port='"'$redis_port'"'
sed -i "s%$cur_redis_sg%$new_redis_sg%g" ./json-ma-lb/redis.json
sed -i "s%$cur_redis_port%$new_redis_port%g" ./json-ma-lb/redis.json

cur_sentinel_sg='"'$(echo $(jq .args ./json-ma-lb/sentinel.json) | awk -F\" '{print $2}')'"'
cur_redis_port='"'$(echo $(jq .args ./json-ma-lb/sentinel.json) | awk -F\" '{print $4}')'"'
cur_sentinel_port='"'$(echo $(jq .args ./json-ma-lb/sentinel.json) | awk -F\" '{print $6}')'"'
new_sentinel_port='"'$sentinel_port'"'
sed -i "s%$cur_sentinel_sg%$new_redis_sg%g" ./json-ma-lb/sentinel.json
sed -i "s%$cur_redis_port%$new_redis_port%g" ./json-ma-lb/sentinel.json
sed -i "s%$cur_sentinel_port%$new_sentinel_port%g" ./json-ma-lb/sentinel.json

echo "copy redis.json and update sentinel.json instance num"
i=1
while [[ $i -le $redis_num ]]; do
  \cp ./json-ma-lb/redis.json ./json-ma-lb/redis${i}.json
  i=$[$i+1]
done
cur_sen_insnum='"instances": '$(jq .instances ./json-ma-lb/sentinel.json)
new_sen_insnum='"instances": '$sentinel_insnum
sed -i "s%$cur_sen_insnum%$new_sen_insnum%g" ./json-ma-lb/sentinel.json

echo "deploy redis1"
sed -i '/^      - sentinel/d' ./marathon.yml.redis-sentinel-rabbitmq
sed -i '/^      - redis/d' ./marathon.yml.redis-sentinel-rabbitmq
sed -i '/^      - rabbitmq/d' ./marathon.yml.redis-sentinel-rabbitmq
echo "      - redis1" >> ./marathon.yml.redis-sentinel-rabbitmq
result=$(ansible-playbook ./marathon.yml.redis-sentinel-rabbitmq --private-key=./config-pdms/id_rsa --user=plcm -e "jumphost=CURAPP_JUMPHOST_NAME" -e "state=deployed" -e "sgid=$sg")
echo "$result"
if [[ $result =~ "unreachable=0" && $result =~ "failed=0" ]]; then
    echo "deploy redis1 successfully"
else
    echo "deploy redis1 failed"
    exit 1
fi

echo "check if redis1 is running normally"
echo "sleep 60"
sleep 60
timesnum=1
while [[ $timesnum -le 9 ]]; do
    echo "$timesnum times check"
    result=$(ansible-playbook ./check-service.yml --private-key=./config-pdms/id_rsa --user=plcm -e "jumphost=CURAPP_JUMPHOST_NAME" -e "state=deployed" -e "service=$sg/redis1")
    echo "$result"   
    if grep -q 'does not exist' ./config-pdms/check-service-result.json; then
        echo "not running yet"
        timesnum=$[$timesnum+1]
        echo "sleep 60"
        sleep 60
        continue
    else
        echo "redis1 is running normally"
        break
    fi
done
if [[ $timesnum -gt 9 ]]; then
    echo "timeout for checking redis1, failed"
    exit 1
fi



echo "deploy rest redis and sentinel and rabbitmq"
sed -i '/^      - sentinel/d' ./marathon.yml.redis-sentinel-rabbitmq
sed -i '/^      - redis/d' ./marathon.yml.redis-sentinel-rabbitmq
sed -i '/^      - rabbitmq/d' ./marathon.yml.redis-sentinel-rabbitmq
echo "      - rabbitmq" >> ./marathon.yml.redis-sentinel-rabbitmq
echo "      - sentinel" >> ./marathon.yml.redis-sentinel-rabbitmq
i=2
while [[ $i -le $redis_num ]]; do
  echo "      - redis$i" >> ./marathon.yml.redis-sentinel-rabbitmq
  i=$[$i+1]
done
result=$(ansible-playbook ./marathon.yml.redis-sentinel-rabbitmq --private-key=./config-pdms/id_rsa --user=plcm -e "jumphost=CURAPP_JUMPHOST_NAME" -e "state=deployed" -e "sgid=$sg")
echo "$result"
if [[ $result =~ "unreachable=0" && $result =~ "failed=0" ]]; then
    echo "deploy rest redis and sentinel and rabbitmq successfully"
else
    echo "deploy rest redis and sentinel and rabbitmq failed"
    exit 2
fi

echo "modify ./mnt/pdms/conf/$sg/redis.json and copy to host"
curaddr=$(jq -r '.sentinelAddress' ./mnt/pdms/conf/$sg/redis.json)
newaddr="sentinel."$sg".marathon.mesos:"$sentinel_port
sed -i "s/$curaddr/$newaddr/g" ./mnt/pdms/conf/$sg/redis.json
result_copy=$(ansible-playbook ./copy-mnt.yml -e deployment=CURAPP_DEPLOYMENT_NAME -e sgid=$sg)
echo "$result_copy"
if [[ $result_copy =~ "unreachable=0" && $result_copy =~ "failed=0" ]]
then
    echo "copy ./mnt/pdms/conf/$sg successful"
else
    echo "copy ./mnt/pdms/conf/$sg failed"
    exit 3
fi

echo "deploy redis sentinel and rabbitmq successfully"
exit 0

