#!/bin/bash

chmod 600 ./config-pdms/id_rsa
echo "check vm"
result=$(ansible-playbook ./check-vm.yml -e "deployment=CURAPP_DEPLOYMENT_NAME")
echo "$result"
exit 0
