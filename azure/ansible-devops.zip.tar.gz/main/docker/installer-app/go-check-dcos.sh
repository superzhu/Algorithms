#!/bin/bash

chmod 600 ./config-pdms/id_rsa

rm -rf ./config-pdms/imageFlags.conf

echo "check dcos"
result=$(ansible-playbook check-dcos.yml --private-key=./config-pdms/id_rsa --user=plcm -e "hosts=CURAPP_JUMPHOST_NAME")
echo "$result"
if [[ $result =~ "unreachable=0" && $result =~ "failed=0" ]]
then
    echo "check ansible successful"
else
    echo "check ansible failed"
    exit 3
fi

if [ ! -f ./config-pdms/imageFlags.conf ]; then
  echo "/etc/imageFlags.conf not exists, it's old dcos"
  exit 1
else
  echo "/etc/imageFlags.conf exists, it's new dcos" 
  exit 2
fi
exit 3
