#!/bin/bash

# change id_rsa mode to 600
chmod 600 ./config-pdms/id_rsa


echo "copy ./config-pdms/telegraf.conf to /etc/telegraf/ of all agent, add hostname to it."
result=$(ansible-playbook ./telegraf-config.yml -e "deployment=CURAPP_DEPLOYMENT_NAME")
echo "$result"
if [[ $result =~ "unreachable=0" && $result =~ "failed=0" ]]
then
    echo "prepare telegraf successful"
else
    echo "prepare telegraf failed"
    exit 1
fi

exit 0
