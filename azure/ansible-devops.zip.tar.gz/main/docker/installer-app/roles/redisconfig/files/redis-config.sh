#!/bin/bash
# WARNING: this operation will result in system reboot
if [ ! -f /etc/redis-tune ];then
    sed -i "s|exit 0||g" /etc/rc.local
    echo "vm.overcommit_memory = 1" >> /etc/sysctl.conf
    echo "echo never > /sys/kernel/mm/transparent_hugepage/enabled" >>/etc/rc.local
    echo "exit 0">>/etc/rc.local
    touch /etc/redis-tune
    echo "WARNING: the system will be reboot..."
#    reboot
fi
