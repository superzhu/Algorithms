#!/bin/bash

content=`cat /home/plcm/.ssh/authorized_keys | grep  -nf /home/plcm/.ssh/append_keys`

echo $content

if [ "$content"x == ""x ]; then
        echo "append keys"
        cat /home/plcm/.ssh/append_keys >> /home/plcm/.ssh/authorized_keys
fi

exit 0

