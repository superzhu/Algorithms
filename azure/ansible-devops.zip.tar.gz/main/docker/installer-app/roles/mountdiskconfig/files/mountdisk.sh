
if [ ! -f /etc/systemd/system/var-lib-mesos.mount ]; then
        mkfs.ext4 /dev/sdb
        uuid=`blkid /dev/sdb|grep UUID|awk '{print $2}'|awk -F= '{print $2}'`
        echo [Unit] >>/etc/systemd/system/var-lib-mesos.mount
        echo "Description=Mount NDB Volume at boot" >>/etc/systemd/system/var-lib-mesos.mount
        echo [Mount] >>/etc/systemd/system/var-lib-mesos.mount
        echo What=UUID="${uuid}" >>/etc/systemd/system/var-lib-mesos.mount
        echo Where=/var/lib/mesos >>/etc/systemd/system/var-lib-mesos.mount
        echo Type=ext4 >>/etc/systemd/system/var-lib-mesos.mount
        echo Options=defaults >>/etc/systemd/system/var-lib-mesos.mount
        echo [Install] >>/etc/systemd/system/var-lib-mesos.mount
        echo WantedBy=multi-user.target >>/etc/systemd/system/var-lib-mesos.mount
        systemctl daemon-reload
        systemctl start var-lib-mesos.mount
        systemctl enable var-lib-mesos.mount
fi
