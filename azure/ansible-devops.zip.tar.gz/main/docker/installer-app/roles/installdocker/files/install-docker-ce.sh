#!/bin/bash

function roll_log
{
    if [ ! -f /root/install-docker-ce.log ]; then
        return
    fi

    local FILE_SIZE=`ls -l /root/install-docker-ce.log | awk '{print $5}'`
    if [ $FILE_SIZE -gt 100000 ]; then
        cat /root/install-docker-ce.log > /root/install-docker-ce.log.bak
        echo "" > /root/install-docker-ce.log
        return
    fi
}

function log
{
    echo "[`date`] $@"
}

set -x

if [ "$1"x == ""x ]; then

    echo ""

    BASENAME=`basename $0`
    DIRNAME=`dirname $0`

    roll_log

    $DIRNAME/$BASENAME --with-logs 2>&1 | tee -a /root/install-docker-ce.log

    RESULT=$?

    exit $RESULT

else

    log "executing $0 $@ ... "

fi

docker version

docker version | grep Version | grep 18.03.1-ce

INSTALLED=$?

if [ $INSTALLED -eq 0 ]; then

    set +x

    log "latest docker installed already. ignore. "
    echo ""
    echo ""
    echo ""
    echo ""

    exit 0

fi

apt-get remove docker docker-engine docker.io -y

apt-get update

apt-get install \
    apt-transport-https \
    ca-certificates \
    curl \
    software-properties-common -y

curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -

apt-key fingerprint 0EBFCD88

add-apt-repository \
   "deb [arch=amd64] https://download.docker.com/linux/ubuntu \
   $(lsb_release -cs) \
   stable"

apt-get update

# current version: 18.03.1~ce-0~ubuntu
# command to search the repo:
#   apt search docker-ce
#

# install by specified version.
apt-get install docker-ce=18.03.1~ce-0~ubuntu -y

#
# apt-get install docker-ce

rm -rf /etc/systemd/system/docker.service.d

systemctl daemon-reload

systemctl restart docker

# install by version
# apt-get install docker-ce=<VERSION>

# systemctl status docker

systemctl status docker --no-page -l

RESULT=$?

docker version

set +x

if [ $RESULT -eq 0 ]; then

	log "seems good. "
    echo ""
    echo ""
    echo ""
    echo ""

else

    echo ""
    echo ""
    echo ""
    echo ""
	log "bad status: $RESULT !!!!!!!!!!! "
    echo ""
    echo ""
    echo ""
    echo ""

	exit $RESULT


fi



