#!/bin/bash
#author: steven
#date: 2018-7-4
#function: mount sdb partition into /uploadimage and /backup

function initSDB()
{
    number=`df -kh|grep mesos|grep sdb|awk '{print $1}'|cut -d "b" -f 2`
    number_docker=`df -kh|grep docker|grep sdb|awk '{print $1}'|cut -d "b" -f 2`
    # if mesos dir has been linked
    if [ ${number}x != x ]; then
        if [ ${number} -eq 1 ]; then
           echo yes|mkfs.ext4 /dev/sdb2
           echo yes|mkfs.ext4 /dev/sdb3
           upNumber=2
           backNumber=3
        elif [ ${number} -eq 2 ]; then
           echo yes|mkfs.ext4 /dev/sdb1
           echo yes|mkfs.ext4 /dev/sdb3
           upNumber=1
           backNumber=3
        elif [ ${number} -eq 3 ]; then
           echo yes|mkfs.ext4 /dev/sdb1
           echo yes|mkfs.ext4 /dev/sdb2
           upNumber=1
           backNumber=2
        fi
    
    else
        # if docker dir has been linked
        if [ ${number_docker}x != x ]; then
            if [ ${number_docker} -eq 1 ]; then
               echo yes|mkfs.ext4 /dev/sdb2
               echo yes|mkfs.ext4 /dev/sdb3
               upNumber=2
               mesosNumber=3
            elif [ ${number_docker} -eq 2 ]; then
               echo yes|mkfs.ext4 /dev/sdb1
               echo yes|mkfs.ext4 /dev/sdb3
               upNumber=1
               mesosNumber=3
       
            elif [ ${number_docker} -eq 3 ]; then
               echo yes|mkfs.ext4 /dev/sdb1
               echo yes|mkfs.ext4 /dev/sdb2
               upNumber=1
               mesosNumber=2
            fi
       else
           echo yes|mkfs.ext4 /dev/sdb1
           echo yes|mkfs.ext4 /dev/sdb2
           echo yes|mkfs.ext4 /dev/sdb3
           upNumber=1
           mesosNumber=2
           backNumber=3
       fi
    fi
}

function mount_partition()
{
    partition=$1
    partition_file=/etc/fstab
    
    if [ ${partition}x != x ]; then
        if [ ${partition} == "uploadimage" -a ${upNumber}x != x ]; then
            uuid=`blkid /dev/sdb${upNumber}|grep UUID|awk '{print $2}'|awk -F= '{print $2}'`
        elif [ ${partition} == "backup" -a ${backNumber}x != x ]; then
            uuid=`blkid /dev/sdb${backNumber}|grep UUID|awk '{print $2}'|awk -F= '{print $2}'`
        #elif [ ${partition} == "var/lib/mesos" -a ${mesosNumber}x != x ]; then
        #    uuid=`blkid /dev/sdb${mesosNumber}|grep UUID|awk '{print $2}'|awk -F= '{print $2}'`
        #    mesosline=`grep -n mesos ${partition_file}|awk -F: '{print $1}'`
        #    if [ ${mesosline}x != x ]; then
        #        sed -i "${mesosline}d" ${partition_file}
        #    fi
        fi

        if [ ${uuid}x != x ]; then
            echo "UUID=${uuid}      /${partition}        ext4   defaults,discard        0 0">>${partition_file}
        fi
    fi
}

function make_run()
{
    #make it available right now
    mount -a

    #mark it completed
    touch /home/plcm/.partition
}
#check if the shell has been executed
#if did, return
if [ -f /home/plcm/.partition ]; then
    echo "this script has been executed, will exit!"
    exit 1
fi
upNumber=1
backNumber=2
mesosNumber=0

#initialized /dev/sdb
parted -l>output
sed -n -e '/gpt/,$p' output>output1
sum=`sed -n -e '/Number/,$p' output1|awk '{print $1}'|wc -l`
if [ ${sum}x != x -a ${sum} -gt 4 ]; then
    initSDB   
fi
rm -f output
rm -f output1

if [ ! -d /uploadimage ]; then
    mkdir /uploadimage
fi

if [ ! -d /backup ]; then
    mkdir /backup
fi

#add /uploadimage directory into /dev/sdbxx
mount_partition uploadimage
ret_u=$?
#add /backup direcory into /dev/sdbxy
mount_partition backup
ret_b=$?
#if [ ${mesosNumber} -ne 0 ]; then
#    mount_partition "var/lib/mesos"
#    ret_m=$?
    
#    if [ ${ret_u} == 0 -a ${ret_b} == 0 -a ${ret_m} == 0 ]; then
#        make_run
#    fi
#else
    if [ ${ret_u} == 0 -a ${ret_b} == 0 ]; then
        make_run
    fi
#fi
exit 0

