### preparation
go-prepare.sh

run:
python go.py --address=CURAPP_OP_PUBIP:443

run in background:
nohup python go.py --address=CURAPP_OP_PUBIP:443 > /dev/null 2>&1 &

check:
ps -ef | grep python

kill:
kill pid

