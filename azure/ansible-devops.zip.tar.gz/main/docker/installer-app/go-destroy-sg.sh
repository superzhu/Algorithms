#!/bin/bash

sg=$1

# change id_ras mode to 600
chmod 600 ./config-pdms/id_rsa

# destroy service group $sg on dcos
echo "begin to destroy service group: "$sg

result_destroy=$(ansible-playbook ./destroy-service-group.yml --private-key=./config-pdms/id_rsa --user=plcm -e "jumphost=CURAPP_JUMPHOST_NAME" -e "sgid=$sg")
echo "$result_destroy"
if [[ $result_destroy =~ "unreachable=0" && $result_destroy =~ "failed=0" ]]
then
    echo "execute destroy script successfully"
else
    echo "execute destroy script failed"
    exit 2
fi

# parse result
if [[ ! -f  "./config-pdms/server/destroy-service-group.json" ]]; then
    echo "there is no ./config-pdms/server/destroy-service-group.json"
    exit 3
else
    result=$(jq -r '.version' ./config-pdms/server/destroy-service-group.json)
    if [[ $result == "null" ]]; then
        result=$(jq -r '.message' ./config-pdms/server/destroy-service-group.json)
        if [[ $result != "Group '/"$sg"' does not exist" ]]; then
            echo "destroy failed:"
            echo "$result"
            exit 4
        else
            echo "$result"
        fi    
    fi
fi
echo "destroy service group successfully: "$sg

# delete directory /mnt/pdms/conf/$sg on agent
echo "begin to delete directory /mnt/pdms/conf/"$sg" on all agent"
result_mnt=$(ansible-playbook ./delete-mnt.yml -e deployment=CURAPP_DEPLOYMENT_NAME -e sgid=$sg)
echo "$result_mnt"
if [[ $result_mnt =~ "unreachable=0" && $result_mnt =~ "failed=0" ]]
then
    echo "delete directory: /mnt/pdms/conf/"$sg" successfully"
else
    echo "delete directory: /mnt/pdms/conf/"$sg" failed"
    exit 5
fi

# delete directory /mnt/pdms/conf/$sg on local installer
echo "delete directory /mnt/pdms/conf/"$sg" on local installer"
rm -rf ./mnt/pdms/conf/$sg

exit 0
