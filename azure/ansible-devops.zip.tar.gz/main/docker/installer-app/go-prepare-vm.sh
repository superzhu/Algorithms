#!/bin/bash

# change id_rsa mode to 600
chmod 600 ./config-pdms/id_rsa


echo "after scaling, we need to prepare the env"

result_fix=$(ANSIBLE_SSH_PIPELINING=false ansible-playbook fix-requiretty-sudoers.yml --private-key=./config-pdms/id_rsa --user=plcm -e "hosts=CURAPP_JUMPHOST_NAME")
echo "$result_fix"
if [[ $result_fix =~ "unreachable=0" && $result_fix =~ "failed=0" ]]
then
    echo "fix successful"
else
    echo "fix failed"
    exit 1
fi

result_pop=$(ansible-playbook ./pdms_jumphost_pophost.yml --private-key=./config-pdms/id_rsa --user=plcm -e "jumphost=CURAPP_JUMPHOST_NAME" -e "deployment=CURAPP_DEPLOYMENT_NAME")
echo "$result_pop"
if [[ $result_pop =~ "unreachable=0" && $result_pop =~ "failed=0" ]]
then
    echo "pop successful"
else
    echo "pop failed"
    exit 2
fi

result_dcos=$(ansible-playbook ./dcos-config.yml --private-key=./config-pdms/id_rsa --user=plcm -e deployment=CURAPP_DEPLOYMENT_NAME -e "jumphost=CURAPP_JUMPHOST_NAME")
echo "$result_dcos"
if [[ $result_dcos =~ "unreachable=0" && $result_dcos =~ "failed=0" ]]
then
    echo "dcos successful"
else
    echo "dcos failed"
    exit 3
fi

echo "prepare successfully"
exit 0
