#!/bin/bash

### add check if this dcos is using our custom-build image
echo "check /etc/imageFlags.conf on jumphost to decide what environment need to be prepared"
./go-check-dcos.sh
result=$?
echo $result
if [[ $result -eq 1 ]]; then
    echo "it's old dcos"
elif [[ $result -eq 2 ]]; then
    echo "it's new dcos"
else
    echo "go-check-dcos failed"
    exit 1
fi

./go-prepare-vm.sh
if [ $? != 0 ]; then
    echo "go-prepare-vm.sh failed"
    exit 1
fi

./go-prepare-ssh-auth.sh
if [ $? != 0 ]; then
    echo "go-prepare-ssh-auth.sh failed"
    exit 10
fi

if [[ $result -eq 2 ]]; then
    echo "prepare new dcos successfully, will exit"
    exit 0
fi


./go-prepare-ntp.sh
if [ $? != 0 ]; then
    echo "go-prepare-ntp.sh failed"
    exit 2
fi

./go-prepare-linux-harden.sh
if [ $? != 0 ]; then
    echo "go-prepare-linux-harden.sh failed"
    exit 3
fi

./go-prepare-install-docker.sh
if [ $? != 0 ]; then
    echo "go-prepare-install-docker.sh failed"
    exit 4
fi

./go-prepare-log-config.sh
if [ $? != 0 ]; then
    echo "go-prepare-log-config.sh failed"
    exit 5
fi

./go-prepare-filebeat.sh
if [ $? != 0 ]; then
    echo "go-prepare-filebeat.sh failed"
    exit 6
fi

./go-prepare-telegraf.sh
if [ $? != 0 ]; then
    echo "go-prepare-telegraf.sh failed"
    exit 7
fi

./go-prepare-mount-disk.sh
if [ $? != 0 ]; then
    echo "go-prepare-mount-disk.sh failed"
    exit 8
fi

## deploy/upgrade filebeat, telegraf
#./go-upgrade-filebeat-telegraf.sh
#if [ $? != 0 ]; then
#    echo "go-upgrade-filebeat-telegraf failed"
#    exit 8
#fi

./go-prepare-ssh-auth.sh
if [ $? != 0 ]; then
    echo "go-prepare-ssh-auth.sh failed"
    exit 10
fi

## allocate uploadimage dedicated to upload/download service
#./go-prepare-update-partition.sh
#if [ $? != 0 ]; then
#    echo "go-prepare-update-partition.sh failed"
#    exit 11
#fi

./go-prepare-redis-config.sh
if [ $? != 0 ]; then
    echo "go-prepare-redis-config.sh failed"
    exit 12
fi

#./go-prepare-reboot-agent.sh
#if [ $? != 0 ]; then
#    echo "go-prepare-reboot-agent.sh failed"
#    exit 12
#fi

echo "go-prepare.sh executed successfully"
exit 0
