#!/usr/bin/python
# -*- coding: utf-8 -*-

import time
import datetime
import sys, getopt
import json
import os, stat
import os.path
import shutil
from collections import OrderedDict
# import jpype
# from jpype import *
import threading

# sys.path.append('./python')
from installer import *
from logging import exception

goDbServer='./go-dbserver.sh'
goBaseSga='./go-base-sga.sh {0}'
goService='./go-service.sh {0}'
goBackupDbServer = './go-backupdbserver.sh {0}'
goDestroySg='./go-destroy-sg.sh {0}'
goDestroyServer='./go-destroy-server.sh {0}'
goDestroyAll='./go-destroy-all.sh {0} {1}'
goScaleInstance='./go-scale-instance.sh {0} {1} {2}'
goUpgradeSGW='./go-upgrade-sgw.sh'
goCheckVM='./go-check-vm.sh'
goCheckBackupServer = './go-checkbackupserver.sh'
goPartialUpgrade = './go-partial-upgrade.sh {0} {1} {2} {3}'
partial_flag_fite = False
partial_flag_sga = False
partial_flag_service = False
opsclusterid = 'CURAPP_OPS_CLUSTER_ID'
        
log = Log('installer')

opts, args = getopt.getopt(sys.argv[1:], 'h', ["address="])
# address = '172.21.120.233:11100'
# address = '13.85.27.5:80'
# address = '{0}:80'
address = ''
opsip = ''

def usage():
    print('go.py --address=<ip:port>')

if len(sys.argv) <= 1:
    usage()
    sys.exit()
    
for op, value in opts:
    if op == "--address":
        address = value
        log.info('address {0}'.format(address))
        opsip = address.split(":")[0]
        log.info('ip {0}'.format(opsip))
    else:
        usage()
        sys.exit()

if not address:
    usage()
    sys.exit() 
    
def createLogin(serverinfo, databaseinfo):
    try:
        
        with open(os.path.join('./config-pdms', serverinfo), 'r') as f:
            serverjson = json.load(f)
        server = serverjson['db-server']
        dbauser = serverjson['dba-user']
        dbapass = serverjson['dba-user-password-decrypted']
    
        with open(os.path.join('./config-pdms', databaseinfo), 'r') as f:
            databasejson = json.load(f)
        dbuser = databasejson['plcm-sg-service-database'][0]['db-user']
        dbpasshex = databasejson['plcm-sg-service-database'][0]['db-user-password']
        if dbpasshex == None:
            log.error('db-user-password is null ')
            return False
        log.info('decrypt db-user-password')
        
        #dbpasscontent = baseDecrypt(dbpasshex)
        jarpath = os.path.join('/opt/installer', 'Pdmsbase.jar')
        decryptcmd = "java -jar " + jarpath + " decryptAES " + dbpasshex
        log.info(decryptcmd)
        ( n, output ) = subprocess.getstatusoutput(decryptcmd)
        if output == None or output == 'ERROR':
            log.error('decrypt failed')
            return False
        dbpasscontent = output
        log.info(dbpasscontent)
        
        dbapassformat = "'" + dbapass + "'"
#         loginsql = "CREATE LOGIN " + dbuser + " WITH PASSWORD='" + dbpasscontent + "'"
#         createlogincom = 'sqlcmd -S ' + server + ' -U ' + dbauser + ' -P ' + dbapassformat + ' -d master -Q "' + loginsql + '"' + ' -o ./config-pdms/server/createlogin-result.txt'
        #2019.2.15 avoid shell transfer $# to 0
        
        exportcmd = "export dbpass='" + dbpasscontent + "'"
        dbpasscontentformat = "'${dbpass}'"
        logincmd = 'sqlcmd -S ' + server + ' -U ' + dbauser + ' -P ' + dbapassformat + ' -d master -Q "CREATE LOGIN ' + dbuser + ' WITH PASSWORD=' + dbpasscontentformat + '"' + ' -o ./config-pdms/server/createlogin-result.txt'
        createlogincmd = exportcmd + " && " + logincmd
        log.info("create login command: {0}, result is saved in ./config-pdms/server/createlogin-result.txt".format(createlogincmd))
        ( n, output ) = subprocess.getstatusoutput(createlogincmd)
        if n == 0 :
            log.info("create login successfully, return code: {0}, output: {1}".format(n, output))
            return True
        else:
            log.info("create login failed, return code: {0}, output: {1}".format(n, output))
            return False
    except BaseException as e:
        log.error(e)
        return False
    else:
        log.info('end of createLogin')
        return True
    
def createUserForLogin(serverinfo, databaseinfo):
    try:
        with open(os.path.join('./config-pdms', serverinfo), 'r') as f:
            serverjson = json.load(f)
        server = serverjson['db-server']
        dbauser = serverjson['dba-user']
        dbapass = serverjson['dba-user-password-decrypted']
    
        with open(os.path.join('./config-pdms', databaseinfo), 'r') as f:
            databasejson = json.load(f)
        dbuser = databasejson['plcm-sg-service-database'][0]['db-user']
        
        #sqlcmd -S tt1-0-pdms-sql-server.database.windows.net -U plcmdbo -P Polycom12#$ -d master -Q "alter user plcmuser with login=plcmuser"
        altersql = "alter user " +dbuser + " with login=" + dbuser
        dbapassformat = "'" + dbapass + "'"
        createusercom = 'sqlcmd -S ' + server + ' -U ' + dbauser + ' -P ' + dbapassformat + ' -d epmdb -Q "' + altersql + '"' + ' -o ./config-pdms/server/createuserforlogin-result.txt'
        log.info("create user for login command: {0}, result is saved in ./config-pdms/server/createuserforlogin-result.txt".format(createusercom))
        ( n, output ) = subprocess.getstatusoutput(createusercom)
        if n == 0 :
            log.info("create user for login successfully, return code: {0}, output: {1}".format(n, output))
            return True
        else:
            log.info("create user for login failed, return code: {0}, output: {1}".format(n, output))
            return False
    except BaseException as e:
        log.error(e)
        return False
    else:
        log.info('end of createUserForLogin')
        return True    
    
def checkJson(str):
    try:
        json.loads(str)
        return True
    except:
        return False

def parseAttr(attr, service, servicejson):
    try:
        if attr != 'None' and attr != None:
            for index in range(len(attr)):
                if attr[index]['name'] == 'Instance_Number' and attr[index]['value'] != None:
                    if not checkJson(attr[index]['value']):
                        log.info("parseAttr--Instance_Number of {0} is not a json format".format(service))
                        #print 'Instance_Number of ' + service + 'is not a json format'
                        return False
                    servicejson['instances'] = json.loads(attr[index]['value'])
                elif attr[index]['name'] == 'cpus' and attr[index]['value'] != None:
                    if not checkJson(attr[index]['value']):
                        log.info("parseAttr--cpus of {0} is not a json format".format(service))
                        return False
                    servicejson['cpus'] = json.loads(attr[index]['value'])
                elif attr[index]['name'] == 'cmd' and attr[index]['value'] != None:
                    if not checkJson(attr[index]['value']):
                        log.info("parseAttr--cmd of {0} is not a json format".format(service))
                        return False
                    servicejson['cmd'] = json.loads(attr[index]['value'])
                elif attr[index]['name'] == 'mem' and attr[index]['value'] != None:
                    if not checkJson(attr[index]['value']):
                        log.info("parseAttr--mem of {0} is not a json format".format(service))
                        return False
                    servicejson['mem'] = json.loads(attr[index]['value'])
                elif attr[index]['name'] == 'volumes' and attr[index]['value'] != None:
                    if not checkJson(attr[index]['value']):
                        log.info("parseAttr--volumes of {0} is not a json format".format(service))
                        return False
                    servicejson['container']['volumes'] = None
                    servicejson['container']['volumes'] = json.loads(attr[index]['value'], object_pairs_hook=OrderedDict)
                elif attr[index]['name'] == 'env' and attr[index]['value'] != None:
                    if not checkJson(attr[index]['value']):
                        log.info("parseAttr--env of {0} is not a json format".format(service))
                        return False
                    servicejson['env'] = None
                    servicejson['env'] = json.loads(attr[index]['value'])
                elif attr[index]['name'] == 'portMappings' and attr[index]['value'] != None:
                    if 'redis' in service or 'sentinel' in service or 'rabbitmq' in service or 'filebeat' in service or 'node-monitor' in service or 'telegraf' in service or 'service-gateway-service' in service:
                        log.info("parseAttr--this service {0} does not need to change format of portMappings".format(service))
                    else:
                        if not checkJson(attr[index]['value']):
                            log.info("parseAttr--portMappings of {0} is not a json format".format(service))
                            return False
                        servicejson['container']['docker']['portMappings'] = None
                        servicejson['container']['docker']['portMappings'] = json.loads(attr[index]['value'], object_pairs_hook=OrderedDict)
                elif attr[index]['name'] == 'healthChecks' and attr[index]['value'] != None:
                    if not checkJson(attr[index]['value']):
                        log.info("parseAttr--healthChecks of {0} is not a json format".format(service))
                        return False
                    servicejson['healthChecks'] = None
                    servicejson['healthChecks'] = json.loads(attr[index]['value'], object_pairs_hook=OrderedDict)
                elif attr[index]['name'] == 'acceptedResourceRoles' and attr[index]['value'] != None:
                    accrole = attr[index]['value'][1:len(attr[index]['value'])-1]
                    roleslist = accrole.split(',')
                    servicejson['acceptedResourceRoles'][:] = []
                    for index in range(int(len(roleslist)) - int(len(servicejson['acceptedResourceRoles']))):
                        servicejson['acceptedResourceRoles'].append('null')
                    for index in range(len(roleslist)):
                        servicejson['acceptedResourceRoles'][index] = json.loads(roleslist[index])
                else:
                    continue
    except BaseException as e:
        log.error(e)
        return False
    else:
        log.info('end of parseAttr')
        return True


def parseMarathonJson(data, newsg, flag=''):
    
    ## copy json-ma-lb
    try:
        if not os.path.exists('./json-ma-lb'):
            os.mkdir('./json-ma-lb')
        for file in os.listdir('./json-ma-lb-tmp'):
            shutil.copy(os.path.join('./json-ma-lb-tmp', file), os.path.join('./json-ma-lb', file))
        
        ## clear marathon.yml
        with open('marathon.yml', 'r') as f:
            with open('marathon.yml.new', 'w') as g:
                for line in f.readlines():
                    if '      - ' not in line:
                        g.write(line)
        shutil.move('marathon.yml.new', 'marathon.yml')
          
        for serviceinfo in data:
            service = serviceinfo['release-service-version']['micro-service-name']
            if serviceinfo['release-service-version']['build-image'] == None or serviceinfo['service-port'] == None:
                log.info("parseJson--image or port is null")
                return False
            ## not parse sgw
            if service == 'service-gateway-service':
                continue
            elif service == 'redis-master' or service == 'redis-slave':
                ### workaround for redis 1.2 version, should be deleted in 1.3
                if flag == 'partialupgrade':
                    continue
                log.info("parseJson--this is redis-master or redis-slave, will using specific redis 1.2 version")
                service = 'redis'
                with open(os.path.join('./json-ma-lb', service + '.json'), 'r') as f:
                    servicejson = json.load(f, object_pairs_hook=OrderedDict)
                ## image
                servicejson['id'] = service
                
                if '-v' in serviceinfo['release-service-version']['build-image']:
                    log.info("this redis image version in category is -v version, will using default version: pdmsdev1reg.azurecr.io/pdms/redis:refactor-redis-1.1.0-71443")
                    servicejson['container']['docker']['image'] = "pdmsdev1reg.azurecr.io/pdms/redis:refactor-redis-1.1.0-71443"
                else:
                    servicejson['container']['docker']['image'] = serviceinfo['release-service-version']['build-image']
                
                servicejson['container']['docker']['portMappings'][0]['containerPort'] = json.loads(serviceinfo['service-port'])
                servicejson['container']['docker']['portMappings'][0]['hostPort'] = json.loads(serviceinfo['service-port'])
                
                if not parseAttr(serviceinfo['container-servers-attribute'], service, servicejson):
                    return False
                ## save update
                with open(os.path.join('./json-ma-lb', service + '.json'), 'w') as f:
                    json.dump(servicejson, f, indent=2)
                log.info("parseJson--parse {0} successfully".format(service))
                
            elif service == 'redis' or service == 'sentinel' or service == 'rabbitmq':
                if flag == 'partialupgrade':
                    continue
                with open(os.path.join('./json-ma-lb', service + '.json'), 'r') as f:
                    servicejson = json.load(f, object_pairs_hook=OrderedDict)
                ## image
                servicejson['id'] = service
                if ((service == 'redis' or service == 'sentinel') and '-v' in serviceinfo['release-service-version']['build-image']):
                    if service == 'redis':
                        log.info("this redis image version in category is -v version, will using default version: pdmsdev1reg.azurecr.io/pdms/redis:refactor-redis-1.1.0-71443")
                        servicejson['container']['docker']['image'] = "pdmsdev1reg.azurecr.io/pdms/redis:refactor-redis-1.1.0-71443"
                    else:
                        log.info("this sentinel image version in category is -v version, will using default version: pdmsdev1reg.azurecr.io/pdms/sentinel:refactor-redis-1.1.0-71443")
                        servicejson['container']['docker']['image'] = "pdmsdev1reg.azurecr.io/pdms/sentinel:refactor-redis-1.1.0-71443"
                else:
                    servicejson['container']['docker']['image'] = serviceinfo['release-service-version']['build-image']
                ## port
                if service == 'redis' or service == 'sentinel':
                    servicejson['container']['docker']['portMappings'][0]['containerPort'] = json.loads(serviceinfo['service-port'])
                    servicejson['container']['docker']['portMappings'][0]['hostPort'] = json.loads(serviceinfo['service-port'])
                elif service == 'rabbitmq':
                    portlist = serviceinfo['service-port'].split(';')
                    if len(portlist) < 3:
                        log.info("parseJson--rabbitmq must has three service port")
                        return False
                    for index in range(len(portlist)):
                        servicejson['container']['docker']['portMappings'][index]['servicePort'] = json.loads(portlist[index])
                    ## modify ./mnt/pdms/conf/newsg/rabbitmq.json
                    with open(os.path.join('./mnt/pdms/conf/', newsg, 'rabbitmq.json'), 'r') as f:
                        rabbitmqjson = json.load(f)
                    rabbitmqjson['address']['amqp']['tcp'] = portlist[0]
                    rabbitmqjson['address']['management']['tcp'] = portlist[1]
                    rabbitmqjson['address']['stomp']['tcp'] = portlist[2]
                    with open(os.path.join('./mnt/pdms/conf/', newsg, 'rabbitmq.json'), 'w') as f:
                        json.dump(rabbitmqjson, f, indent=2)
                ## instances, cpus, cmd, mem, volumes, env, healthChecks, acceptedResourceRoles
                if not parseAttr(serviceinfo['container-servers-attribute'], service, servicejson):
                    return False
                ## save update
                with open(os.path.join('./json-ma-lb', service + '.json'), 'w') as f:
                    json.dump(servicejson, f, indent=2)
                log.info("parseJson--parse {0} successfully".format(service))
                
            elif service == 'filebeat-service' or service == 'telegraf-service' or service == 'node-monitor-service':
                if flag == 'partialupgrade':
                    global partial_flag_fite
                    partial_flag_fite = True
                with open(os.path.join('./json-ma-lb', service + '.json'), 'r') as f:
                    servicejson = json.load(f, object_pairs_hook=OrderedDict)
                ## image
                servicejson['id'] = service
                servicejson['container']['docker']['image'] = serviceinfo['release-service-version']['build-image']
                ## instances, cpus, cmd, mem, volumes, env, healthChecks, acceptedResourceRoles
                if not parseAttr(serviceinfo['container-servers-attribute'], service, servicejson):
                    return False
                ## save update
                with open(os.path.join('./json-ma-lb', service + '.json'), 'w') as f:
                    json.dump(servicejson, f, indent=2)
                log.info("parseJson--parse {0} successfully".format(service))
                
            else:
                ## if container-servers-attribute has cpus, will use service-prototype.json
                protoflag=False
                for index in range(len(serviceinfo['container-servers-attribute'])):
                    if serviceinfo['container-servers-attribute'][index]['name'] == 'cpus':
                        protoflag=True
                        break
                    else:
                        continue
                if protoflag:
                    with open(os.path.join('./json-ma-lb', 'service-prototype.json'), 'r') as f:
                        servicejson = json.load(f, object_pairs_hook=OrderedDict)
                else:
                    with open(os.path.join('./json-ma-lb', service + '.json'), 'r') as f:
                        servicejson = json.load(f, object_pairs_hook=OrderedDict)
                ## instances, cpus, cmd, mem, volumes, env, healthChecks, portmappings, acceptedResourceRoles
                if not parseAttr(serviceinfo['container-servers-attribute'], service, servicejson):
                    return False
                ## image
                servicejson['id'] = service
                servicejson['container']['docker']['image'] = serviceinfo['release-service-version']['build-image']
                ## port
#2019.1.8
#                 if len(servicejson['container']['docker']['portMappings']) <= 0:
#                     log.info("parseJson--there is no portMappings of service {0} ".format(service))
#                     return False 
                if serviceinfo['service-port'].find(';') < 0:
                    servicejson['container']['docker']['portMappings'][0]['servicePort'] = json.loads(serviceinfo['service-port'])
                else:
                    portlist = serviceinfo['service-port'].split(';')
                    for index in range(len(portlist)):
                        servicejson['container']['docker']['portMappings'][index]['servicePort'] = json.loads(portlist[index])
                ## replace service-group-name
                if 'PDMS_TENANT_GROUP' in servicejson['env']:
                    oldsg = servicejson['env']['PDMS_TENANT_GROUP']
                    servicejson['env']['PDMS_TENANT_GROUP'] = newsg
                    servicejson['container']['volumes'] = json.loads(json.dumps(servicejson['container']['volumes'], indent=2).replace(oldsg, newsg))
                elif 'SG_ID' in servicejson['env']:
                    oldsg = servicejson['env']['SG_ID']
                    servicejson['env']['SG_ID'] = newsg
                    servicejson['container']['volumes'] = json.loads(json.dumps(servicejson['container']['volumes'], indent=2).replace(oldsg, newsg))
                else:
                    log.info("parseJson--there is no PDMS_TENANT_GROUP or SG_ID in env of service {0} ".format(service))
                    
                ## replace OPERATION_IP
                if 'OPERATION_IP' in servicejson['env']:
                    servicejson['env']['OPERATION_IP'] = opsip
                    log.info("parseJson--update OPERATION_IP in env of service {0} ".format(service))
                    
                if 'OPERATION_CLUSTER_ID' in servicejson['env']:
                    servicejson['env']['OPERATION_CLUSTER_ID'] = opsclusterid
                    log.info("parseJson--update OPERATION_CLUSTER_ID in env of service {0} ".format(service))
                ## add service to marathon.yml
                if service != 'service-group-agent-service':
                    with open('marathon.yml', 'a') as f:
                        f.write('      - ' + service + '\n')
                    global partial_flag_service
                    partial_flag_service = True
                else:
                    global partial_flag_sga
                    partial_flag_sga = True
                        
                # parse dbpool of service
                connectionpool = serviceinfo['release-service-version']['connection-pool-parameter']
                if service != 'service-group-agent-service' and connectionpool != 'None' and connectionpool != None:
                    if not os.path.exists(os.path.join('./mnt/pdms/conf/', newsg, service)):
                        log.info("create dbpool.json for {0}".format(service))
                        os.makedirs(os.path.join('./mnt/pdms/conf/', newsg, service))
                        shutil.copy('./config-pdms/sg/dbpool-template.json', os.path.join('./mnt/pdms/conf/', newsg, service, 'dbpool.json'))
                        log.info('create dbpool.json over')
                        
                    with open(os.path.join('./mnt/pdms/conf/', newsg, service, 'dbpool.json'), 'r') as f:
                        dbpooljson = json.load(f)
                    for index in range(len(connectionpool)):
                        if connectionpool[index]['name'] == 'dbpool.json' and connectionpool[index]['value'] != None:
                            if not checkJson(connectionpool[index]['value']):
                                log.info("parseJson--dbpool.json of {0} is not a json format, will not update dbpool.json".format(service))
                                break
                            dbpooljson = json.loads(connectionpool[index]['value'], object_pairs_hook=OrderedDict)
                            break
                        else:
                            continue    
                    with open(os.path.join('./mnt/pdms/conf/', newsg, service, 'dbpool.json'), 'w') as f:
                        json.dump(dbpooljson, f, indent=2)
                
                
                ## save update
                with open(os.path.join('./json-ma-lb', service + '.json'), 'w') as f:
                    json.dump(servicejson, f, indent=2)
                log.info("parseJson--parse {0} successfully".format(service))
                
    except BaseException as e:
        log.error(e)
        return False
    else:
        log.info('end of parseMarathonJson')
        return True

def parseJson(newsg):
    
    try:
        ## copy config-pdms/sg
        if os.path.exists(os.path.join('./mnt/pdms/conf/', newsg)):
            shutil.rmtree(os.path.join('./mnt/pdms/conf/', newsg))
        shutil.copytree('./config-pdms/sg', os.path.join('./mnt/pdms/conf/', newsg))   
         
        # modify /mnt/pdms/conf/newsg/db.json
        with open('./config-pdms/dbserver.json', 'r') as f:
            dbserver = json.load(f)
        with open(os.path.join('./mnt/pdms/conf/', newsg, 'db.json'), 'r') as f:
            dbjson = json.load(f)
        dbjson['db-0']['address'] = dbserver['db-server']
        with open(os.path.join('./mnt/pdms/conf/', newsg, 'db.json'), 'w') as f:
            json.dump(dbjson, f, indent=2)
        
                    
        with open('./config-pdms/service-config.json', 'r') as f:
            configdata = json.load(f)
    #     data_json=json.dumps(configdata, indent=2)
        data=configdata['service-group-resource']
        
        log.info("parseJson--begin to generate marathon json file below json-ma-lb")
        if not parseMarathonJson(data, newsg):
            log.info("parseJson--generate marathon json file failed")
            return False
               
    except BaseException as e:
        log.error(e)
        return False
    else:
        log.info('end of parseJson')
        return True

def partialUpgrade(newsg):
    global partial_flag_fite, partial_flag_sga, partial_flag_service
    partial_flag_fite = False
    partial_flag_sga = False
    partial_flag_service = False
    try:
        with open('./config-pdms/service-config.json', 'r') as f:
            configdata = json.load(f)
    #     data_json=json.dumps(configdata, indent=2)
        data=configdata['service-group-resource']
        
        log.info("parseJson--begin to generate marathon json file below json-ma-lb")
        if not parseMarathonJson(data, newsg, 'partialupgrade'):
            log.info("parseJson--generate marathon json file failed")
            return False
        
    except BaseException as e:
        log.error(e)
        return False
    else:
        log.info('end of partialUpgrade')
        return True

def parseServerInfo(deploytype):
    
    try:
        # deploytype can be deploy, upgrade, rollback
        
        # modify ./config-pdms/server/sqlserver.json to create firewall rule
        log.info("parseServerInfo--begin to update /config-pdms/server/sqlserver.json")
        with open('./config-pdms/server/sqlserver.json', 'r') as f:
            sqljson = json.load(f)
        if deploytype == 'deploy':
            #using config-pdms/dbserver.json
            with open('./config-pdms/dbserver.json', 'r') as f:
                dbserver = json.load(f)
            sqljson['properties']['administratorLogin'] = dbserver['dba-user']
            sqljson['properties']['administratorLoginPassword'] = dbserver['dba-user-password-decrypted']
        elif deploytype == 'upgrade':
            #using config-pdms/dbsrver-backup.json
            with open('./config-pdms/dbserver-backup.json', 'r') as f:
                dbbackupserver = json.load(f)
            sqljson['properties']['administratorLogin'] = dbbackupserver['dba-user']
            sqljson['properties']['administratorLoginPassword'] = dbbackupserver['dba-user-password-decrypted']
        with open('./config-pdms/server/sqlserver.json', 'w') as f:
            json.dump(sqljson, f, indent=2)
       
    except BaseException as e:
        log.error(e)
        return False
    else:
        log.info('end of parseServerInfo')
        return True

def parseInstances(installer, newsg):

    try:
        with open('./config-pdms/service-config.json', 'r') as f:
            data = json.load(f)
        data=data['service-group-resource']
    
        for serviceinfo in data:
            service = serviceinfo['release-service-version']['micro-service-name']
            if 'redis' not in service and 'sentinel' not in service and 'rabbitmq' not in service:
                log.info("parseInstances---begin to parse service is {0}".format(service))
                attr = serviceinfo['container-servers-attribute']
                if attr == 'None' or attr == None:
                    continue
                for index in range(len(attr)):
                    if attr[index]['name'] == 'Instance_Number' and attr[index]['value'] != None and attr[index]['value'] != 'None':
                        newinstances = json.loads(attr[index]['value'])
                        break
                    else:
                        continue
                log.info("parseInstances---new instances number is {0}".format(newinstances))
    #            if newinstances.isdigit():
                ( r, output ) = installer.execCommand(goScaleInstance.format(newsg, service, newinstances))
                if not r:
                    log.info("parseInstances---scale {0} fail".format(service))
                    return False
            else:
                continue
    
    except BaseException as e:
        log.error(e)
        return False
    else:
        log.info('end of parseInstances')
        log.info("parseInstances---scale service group {0} successfully".format(newsg))
        return True    

def parseOPSCluster(newsg):
    try:  
        # read config-pdms/app-cluster-config.json to get info
        with open('./config-pdms/ops-cluster-config.json', 'r') as f:
            clusterdetaildata = json.load(f)
            
        if not checkJson(clusterdetaildata['extend-attribute']):
            log.info("extend-attribute in ops-cluster-config.json is not a json format")
            return False
        clusterExtend = json.loads(clusterdetaildata['extend-attribute'], object_pairs_hook=OrderedDict) 
        with open('./config-pdms/ops-cluster-extend.json', 'w') as f:
            json.dump(clusterExtend, f, indent=2, sort_keys=True)

# 2019.1.10 change to open a null json, this will clear old file and fill with all new key and value        
#         with open(os.path.join('./mnt/pdms/conf/', newsg, 'orion.json'), 'r') as f:
#             oriondata = json.load(f)
#         with open(os.path.join('./mnt/pdms/conf/', newsg, 'azure.json'), 'r') as f:
#             azuredata = json.load(f)
        oriondata = json.loads('{}')
        azuredata = json.loads('{}')
            
        for key,value in clusterExtend.items():
            if key == 'azure.azureStorage-account':
                azuredata['azureStorageAccount'] = value
            elif key == 'orion.cloudRelayApiAddress':
                azuredata['cloudRelayApiAddress'] = value
            elif key == 'orion.cloudRelayApiNamespace':
                azuredata['cloudRelayApiNamespace'] = value
            elif key == 'orion.cloudRelayApiEnv':
                azuredata['cloudRelayApiEnv'] = value
            elif key == 'orion.cloudRelayApiCode':
                azuredata['cloudRelayApiCode'] = value
            elif key == 'orion.cloudRelayApiCodeForCRList':
                azuredata['cloudRelayApiCodeForCRList'] = value
            elif key == 'orion.maUrl':
                azuredata['maUrl'] = value
            elif key == 'orion.aquaApiCode':
                azuredata['aquaApiCode'] = value
            elif key == 'orion.aquaNamespace':
                azuredata['aquaNamespace'] = value
            elif key.startswith('azure.'):
                azuredata[key[6:]] = value
            elif key == 'orion.tenantSubject':
                oriondata['subject'] = value
            elif key == 'orion.Service-Tenant-ID':
                oriondata['tid'] = value
            elif key == 'orion.appendix':
                oriondata['appendix'] = value
            elif key == 'orion.Orion-tenantUrl':
                oriondata['url'] = value
            elif key == 'orion.pholioserviceDirectoryUrl':
                oriondata['pholioServiceDirectoryUrl'] = value
            elif key == 'orion.Orion-userAuthServiceName':
                oriondata['userAuthServiceName'] = value
            elif key == 'orion.pholioUserProfileUrl':
                oriondata['pholioUserProfileUrl'] = value
            elif key == 'orion.licensingApiUrl':
                oriondata['licensingApiUrl'] = value
            elif key == 'orion.userAuthApiVersion':
                oriondata['userAuthApiVersion'] = value
            elif key == 'orion.userAuthLoginApiMethod':
                oriondata['userAuthLoginApiMethod'] = value
            elif key == 'orion.userAuthLogoutApiMethod':
                oriondata['userAuthLogoutApiMethod'] = value
            elif key == 'orion.pdmsLoginRedirectUrl':
                oriondata['pdmsLoginRedirectUrl'] = value
            elif key == 'orion.pdmsLogoutRedirectUrl':
                oriondata['pdmsLogoutRedirectUrl'] = value
            elif key == 'orion.appJWT.appId':
                oriondata['appId'] = value
                oriondata['tenantAppId'] = value
            elif key == 'orion.appJWT.secret':
                oriondata['secrets'] = value
                oriondata['tenantSecret'] = value
            elif key == 'orion.appsystemConfigurationDomainName':
                oriondata['clusterDomainName'] = value
            elif key.startswith('orion.ops') or key == 'orion.tenantSubscribeUrl':
                pass
            elif key.startswith('orion.'):
                oriondata[key[6:]] = value
            else:
                continue
        
        log.info('save new orion.json and azure.json to /mnt/pdms/conf/$sg/')
        with open(os.path.join('./mnt/pdms/conf/', newsg, 'orion.json'), 'w') as f:
            json.dump(oriondata, f, indent=2, sort_keys=True)
        with open(os.path.join('./mnt/pdms/conf/', newsg, 'azure.json'), 'w') as f:
            json.dump(azuredata, f, indent=2, sort_keys=True)
            
        log.info('save new orion.json and azure.json to config-pdms/sg/ to update template')
        with open('./config-pdms/sg/orion.json', 'w') as f:
            json.dump(oriondata, f, indent=2, sort_keys=True)
        with open('./config-pdms/sg/azure.json', 'w') as f:
            json.dump(azuredata, f, indent=2, sort_keys=True)
            
    except BaseException as e:
        log.error(e)
        return False
    else:
        log.info('end of parseOPSCluster')
        return True
    
def updateServiceGroupState(installer, serviceGroupId, state):
    r = installer.loop(3, installer.updateServiceGroupState, serviceGroupId, state)
    if not r:
        log.info("update service group state to {0} failed.".format(state))
        return
    return True

def fetchDbServerJson(installer, serviceGroupId, jsonFileName, serverType=''):
    dbServerJson = installer.loop(3, installer.getDbServer, serviceGroupId, serverType)
    if not dbServerJson:
        log.info("get db server {0} failed.".format(jsonFileName))
        return
    log.info('write dbserver json to config-pdms/{0}'.format(jsonFileName))
    installer.writeJson(dbServerJson, 'config-pdms/', jsonFileName) 
    return dbServerJson   

def fetchServiceDatabaseJson(installer, serviceGroupId, dbserver, jsonFileName):
    serviceDatabaseJson = installer.loop(3, installer.searchServiceDatabases, serviceGroupId, dbserver)
    if not serviceDatabaseJson:
        log.info("get service databases failed.")
        return
    log.info('write service databases json to config-pdms/')
    installer.writeJson(serviceDatabaseJson, 'config-pdms/', jsonFileName)
    return serviceDatabaseJson
        
def fetchServiceGroupDetail(installer, serviceGroupId, fileName, detailType=''):
    sgdetail = installer.loop(3, installer.readServiceGroupDetail, serviceGroupId, detailType)
    if  not sgdetail:
        log.info('get service group detail failed.')
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroupId, 'deploying_start', 'common-error-01', 'get service group detail failed.')
        return
    log.info('save service group detail to config-pdms/service-config.json')
    installer.writeJson(sgdetail, 'config-pdms/', fileName) 
    return sgdetail  
    
def waitForSGA(installer, serviceGroupId, waitState ):
    log.info('loop wait 15 minutes, try every 10s, service group state == {0}, deploy application services.'.format(waitState))
    starttime = datetime.datetime.now()
    gap = 900
    state = ''
    while(True):
        log.info('waiting for service group:{0} state {1}'.format(serviceGroupId, waitState))
        state = installer.getServiceGroupState(serviceGroupId)
        if(state == waitState):
            log.info('state == {0}'.format(waitState))
            return True
        elif(state == 'sg_failed'):
            log.info('state == {0}'.format(state))
            return 
        else:
            log.info('state:{0}.'.format( state ))

        time.sleep(10)
        now = datetime.datetime.now()
        if(now - starttime).seconds > gap :
            log.info('waiting for state {0} time out.'.format(waitState))
            installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroupId, state, 'common-error-02', 'waiting for sga time out(900s) failed.')
            return
    log.info('end of while')

def goServices(installer, serviceGroupId, dbserver, waitState ):
    
    log.info('get service databases')
    if not fetchServiceDatabaseJson( installer, serviceGroupId, dbserver, 'servicedatabase.json'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroupId, waitState, 'common-error-03', 'get service database failed.')
        return
        
    log.info('deploy application services')
    ( r, output ) = installer.execCommand(goService.format(serviceGroupId))
    if not r:
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroupId, waitState, 'common-error-04', 'deploy application micro services failed.')
        return
    
    log.info('update service group state to sg_deployed')     
    if not updateServiceGroupState(installer, serviceGroupId, 'sg_deployed'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroupId, waitState, 'common-error-05', 'update status failed.')
        return   
    log.info('service group deployed.')
    return True
        
'''
install service group
'''    
def install(installer, serviceGroup):

    log.info('============= begin to install {0}'.format(serviceGroup.serviceGroupId))
    
    log.info('check vm')
    ( r, output ) = installer.execCommand(goCheckVM)
    
    log.info('update service state to sg_deploy_start')
    if not updateServiceGroupState(installer, serviceGroup.serviceGroupId, 'sg_deploy_start'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_deploy_ready', 'install-error-01', 'update status failed.')
        return
    
    log.info('get db server')
    dbServerJson = fetchDbServerJson(installer, serviceGroup.serviceGroupId, 'dbserver.json')
    if not dbServerJson:
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_deploy_start', 'install-error-02', 'get db server failed.')
        return
    
    log.info('parse server info to create sql server')
    parseServerInfo('deploy')
    
    log.info('create azure db server')
    ( r, output ) = installer.execCommand(goDbServer)
    if not r:
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_deploy_start', 'install-error-03', 'create azure db server failed.')
        return
    
    log.info('fetch service group detail.')
    if not fetchServiceGroupDetail( installer, serviceGroup.serviceGroupId, 'service-config.json'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_deploy_start', 'install-error-04', 'fetch service group detail.')
        return
    
    log.info('parse config-pdms/service-config.json')
    if not parseJson(serviceGroup.serviceGroupId):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_deploy_start', 'install-error-05', 'parse config-pdms/service-config.json failed.')
        return
        
    log.info('fetch operation cluster detail to get orion.json and azure.json from extent-attribute')
    clusterDetail = installer.loop(3, installer.readAPPCluster, opsclusterid)
    if not clusterDetail:
        log.info('fetch ops cluster detail failed')
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_deploy_start', 'install-error-06', 'fetch ops cluster detail failed')
        return
    
    log.info('save ops cluster detail to config-pdms/ops-cluster-config.json')
    installer.writeJson(clusterDetail, 'config-pdms/', 'ops-cluster-config.json') 
    
    log.info('parse ops-cluster-config.json to generate orion.json and azure.json under /mnt/pdms/conf/{0}'.format(serviceGroup.serviceGroupId)) 
    if not parseOPSCluster(serviceGroup.serviceGroupId):
        log.info('parseOPSCluster failed')
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_deploy_start', 'install-error-07', 'parseOPSCluster failed.')
        return
    
    log.info('deploy redis sentinel rabbitmq, then deploy sga')
    ( r, output ) = installer.execCommand(goBaseSga.format(serviceGroup.serviceGroupId))
    if not r:
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_deploy_start', 'install-error-08', 'deploy redis,mq,sga failed.')
        return
    
    log.info('loop for sga operation')
    if waitForSGA(installer, serviceGroup.serviceGroupId, 'sg_db_deployed'):
         goServices(installer, serviceGroup.serviceGroupId, dbServerJson['db-server'], 'sg_db_deployed' )
         
    log.info('end-of-install')

'''
upgrade service group
'''
def upgrade(installer, serviceGroup):
    
    log.info('============= begin to upgrade {0}'.format(serviceGroup.serviceGroupId))
    
    log.info('check vm')
    ( r, output ) = installer.execCommand(goCheckVM)
    
    log.info('get db server')
    dbServerJson = fetchDbServerJson(installer, serviceGroup.serviceGroupId, 'dbserver.json')
    if not dbServerJson:
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_upgrade_ready', 'upgrade-error-01', 'get db server failed.')
        return
    
    log.info('get service databases of db server')
    if not fetchServiceDatabaseJson( installer, serviceGroup.serviceGroupId, dbServerJson['db-server'], 'servicedatabase.json'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_upgrade_ready', 'upgrade-error-02', 'get service database failed.')
        return
    
    log.info('get db server backup')
    dbServerBackupJson = fetchDbServerJson(installer, serviceGroup.serviceGroupId, 'dbserver-backup.json', 'backuped')
    if not dbServerBackupJson:
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_upgrade_ready', 'upgrade-error-03', 'get db server backup failed.')
        return
    
    log.info('get backuped service databases of backuped db server')
    if not fetchServiceDatabaseJson( installer, serviceGroup.serviceGroupId, dbServerBackupJson['db-server'], 'servicedatabase-backup.json'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_upgrade_ready', 'get-service-database-failed', 'get service database failed.')
        return
    
    log.info('parse server info to create sql server')
    parseServerInfo('upgrade')
    
    # dbserver.json must exist since goBackupDbServer will get db server info from it.
    log.info('backup db server')
    ( r, output ) = installer.execCommand(goBackupDbServer.format(dbServerBackupJson['db-server-short-name']))
    if not r:
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_upgrade_ready', 'upgrade-error-04', 'create azure db server failed.')
        return
    
    log.info('create login to backup server')
    clresult = createLogin('dbserver-backup.json', 'servicedatabase-backup.json')
    if not clresult:
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_upgrade_ready', 'upgrade-error-05', 'create login failed.')
        return
     
    log.info('create user for login to backup server')
    cuflresult = createUserForLogin('dbserver-backup.json', 'servicedatabase-backup.json')
    if not cuflresult:
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_upgrade_ready', 'upgrade-error-06', 'create user for login failed.')
        return
    
    log.info('destroy sg')
    ( r, output ) = installer.execCommand(goDestroySg.format(serviceGroup.serviceGroupId))
    if not r:
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_upgrade_ready', 'upgrade-error-07', 'destroy sg failed.')
        return

    log.info('update service state to sg_upgrade_start') 
    if not updateServiceGroupState(installer, serviceGroup.serviceGroupId, 'sg_upgrade_start'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_upgrade_ready', 'upgrade-error-08', 'update status failed.')
        return
            
    log.info('fetch service group detail.')
    if not fetchServiceGroupDetail( installer, serviceGroup.serviceGroupId, 'service-config.json'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_upgrade_start', 'upgrade-error-09', 'fetch service group detail.')
        return  

    log.info('parse config-pdms/service-config.json')
    if not parseJson(serviceGroup.serviceGroupId):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_upgrade_start', 'upgrade-error-10', 'parse config-pdms/service-config.json failed.')
        return
    
    log.info('fetch operation cluster detail to get orion.json and azure.json from extent-attribute')
    clusterDetail = installer.loop(3, installer.readAPPCluster, opsclusterid)
    if not clusterDetail:
        log.info('fetch ops cluster detail failed')
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_upgrade_start', 'upgrade-error-11', 'fetch ops cluster detail failed')
        return
    
    log.info('save ops cluster detail to config-pdms/ops-cluster-config.json')
    installer.writeJson(clusterDetail, 'config-pdms/', 'ops-cluster-config.json') 
    
    log.info('parse ops-cluster-config.json to generate orion.json and azure.json under /mnt/pdms/conf/{0}'.format(serviceGroup.serviceGroupId)) 
    if not parseOPSCluster(serviceGroup.serviceGroupId):
        log.info('parseOPSCluster failed')
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_upgrade_start', 'upgrade-error-12', 'parseOPSCluster failed.')
        return
        
    log.info('deploy redis sentinel rabbitmq, then deploy sga')
    ( r, output ) = installer.execCommand(goBaseSga.format(serviceGroup.serviceGroupId))
    if not r:
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_upgrade_start', 'upgrade-error-13', 'deploy redis,mq,sga failed.')
        return
    
    log.info('loop for sga operation')
    if waitForSGA(installer, serviceGroup.serviceGroupId, 'sg_db_deployed'):
         goServices(installer, serviceGroup.serviceGroupId, dbServerJson['db-server'], 'sg_db_deployed' )
   
    log.info('end-of-upgrade')


'''
upgrade service
'''
def serviceUpgrade(installer, serviceGroup):
    
    log.info('============= begin to upgrade service of {0}'.format(serviceGroup.serviceGroupId))
    
    log.info('check vm')
    ( r, output ) = installer.execCommand(goCheckVM)
    
    log.info('update service state to s_upgrade_start') 
    if not updateServiceGroupState(installer, serviceGroup.serviceGroupId, 's_upgrade_start'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 's_upgrade_ready', 'supgrade-error-01', 'update status failed.')
        return
            
    log.info('fetch service group detail.')
    if not fetchServiceGroupDetail( installer, serviceGroup.serviceGroupId, 'service-config.json', 'partialupgrade'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 's_upgrade_start', 'supgrade-error-02', 'fetch service upgrade group detail.')
        return  

    log.info('parse config-pdms/service-config.json to get marathon deploy json file')
    if not partialUpgrade(serviceGroup.serviceGroupId):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 's_upgrade_start', 'supgrade-error-03', 'parse config-pdms/service-config.json failed.')
        return
    
    log.info('partial upgrade service')
    ( r, output ) = installer.execCommand(goPartialUpgrade.format(serviceGroup.serviceGroupId, partial_flag_fite, partial_flag_sga, partial_flag_service))
    if not r:
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 's_upgrade_start', 'supgrade-error-04', 'upgrade service failed.')
        return
    
    log.info('fetch operation cluster detail to get orion.json and azure.json from extent-attribute') 
    clusterDetail = installer.loop(3, installer.readAPPCluster, opsclusterid) 
    if not clusterDetail: 
        log.info('fetch ops cluster detail failed') 
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 's_upgrade_start', 'supgrade-error-11', 'fetch ops cluster detail failed') 
        return 
     
    log.info('save ops cluster detail to config-pdms/ops-cluster-config.json') 
    installer.writeJson(clusterDetail, 'config-pdms/', 'ops-cluster-config.json')  
     
    log.info('parse ops-cluster-config.json to generate orion.json and azure.json under /mnt/pdms/conf/{0}'.format(serviceGroup.serviceGroupId))  
    if not parseOPSCluster(serviceGroup.serviceGroupId): 
        log.info('parseOPSCluster failed') 
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 's_upgrade_start', 'supgrade-error-12', 'parseOPSCluster failed.') 
        return 
         
    log.info('update /mnt/pdms/conf/{0} of remote agent'.format(serviceGroup.serviceGroupId))  
    copycmd = 'ansible-playbook ./copy-mnt.yml -e deployment=CURAPP_DEPLOYMENT_NAME -e sgid=' + serviceGroup.serviceGroupId 
    ( r, output ) = installer.execCommand(copycmd) 
    if not r: 
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 's_upgrade_start', 'supgrade-error-13', 'update /mnt/pdms/conf/ of remote agent failed.') 
        return 
     
    log.info('update service state to sg_deployed') 
    if not updateServiceGroupState(installer, serviceGroup.serviceGroupId, 'sg_deployed'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 's_upgrade_start', 'supgrade-error-05', 'update status failed.')
        return
    
    log.info('end-of-service-upgrade')


'''
rollback service group when upgrade failed
'''
def rollback(installer, serviceGroup):
    
    log.info('============= begin to rollback {0}'.format(serviceGroup.serviceGroupId))
    
    log.info('check vm')
    ( r, output ) = installer.execCommand(goCheckVM)
    
    log.info('get db server to use')
    dbServerJson = fetchDbServerJson(installer, serviceGroup.serviceGroupId, 'dbserver.json')
    if not dbServerJson:
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_rollback_ready', 'rollback-error-01', 'get db server failed.')
        return
    
    log.info('get service databases of db server')
    if not fetchServiceDatabaseJson( installer, serviceGroup.serviceGroupId, dbServerJson['db-server'], 'servicedatabase.json'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_rollback_ready', 'rollback-error-02', 'get service database failed.')
        return
    
    log.info('check availability of server')
    ( r, output ) = installer.execCommand(goCheckBackupServer)
    if not r:
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_rollback_ready', 'rollback-error-03', 'check availability of server failed.')
        return
    
    log.info('destroy service group')
    ( r, output ) = installer.execCommand(goDestroySg.format(serviceGroup.serviceGroupId))
    if not r:
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_rollback_ready', 'rollback-error-04', 'destroy sg failed.')
        return
    
    log.info('update service group state to sg_rollback_start') 
    if not updateServiceGroupState(installer, serviceGroup.serviceGroupId, 'sg_rollback_start'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_rollback_ready', 'rollback-error-05', 'update status failed.')
        return        
            
    log.info('fetch service group detail.')
    if not fetchServiceGroupDetail( installer, serviceGroup.serviceGroupId, 'service-config.json'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_rollback_start', 'rollback-error-06', 'fetch service group detail.')
        return  

    log.info('parse config-pdms/service-config.json')
    if not parseJson(serviceGroup.serviceGroupId):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_rollback_start', 'rollback-error-07', 'parse config-pdms/service-config.json failed.')
        return
    
    log.info('fetch operation cluster detail to get orion.json and azure.json from extent-attribute')
    clusterDetail = installer.loop(3, installer.readAPPCluster, opsclusterid)
    if not clusterDetail:
        log.info('fetch ops cluster detail failed')
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_rollback_start', 'rollback-error-08', 'fetch ops cluster detail failed')
        return
    
    log.info('save ops cluster detail to config-pdms/ops-cluster-config.json')
    installer.writeJson(clusterDetail, 'config-pdms/', 'ops-cluster-config.json') 
    
    log.info('parse ops-cluster-config.json to generate orion.json and azure.json under /mnt/pdms/conf/{0}'.format(serviceGroup.serviceGroupId)) 
    if not parseOPSCluster(serviceGroup.serviceGroupId):
        log.info('parseOPSCluster failed')
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_rollback_start', 'rollback-error-09', 'parseOPSCluster failed.')
        return
        
    log.info('deploy redis sentinel rabbitmq, then deploy sga')
    ( r, output ) = installer.execCommand(goBaseSga.format(serviceGroup.serviceGroupId))
    if not r:
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_rollback_start', 'rollback-error-10', 'deploy redis,mq,sga failed.')
        return
    
    log.info('loop for sga operation')
    if waitForSGA(installer, serviceGroup.serviceGroupId, 'sg_db_deployed'):
         goServices(installer, serviceGroup.serviceGroupId, dbServerJson['db-server'], 'sg_db_deployed' )
         
    log.info('end-of-rollback')
         
'''
'''
def destroy(installer, serviceGroup):
        
    log.info('============= begin to destroy {0}'.format(serviceGroup.serviceGroupId))
    
    log.info('update service state to sg_delete_start') 
    if not updateServiceGroupState(installer, serviceGroup.serviceGroupId, 'sg_delete_start'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_delete_ready', 'destory-error-01', 'update status failed.')
        return
    
    log.info('get db server')
    dbServerJson = fetchDbServerJson(installer, serviceGroup.serviceGroupId, 'dbserver.json')
    if not dbServerJson:
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_delete_start', 'destory-error-02', 'get db server failed.')
        return
    
    log.info('destroy service group and server')
    ( r, output ) = installer.execCommand(goDestroyAll.format(serviceGroup.serviceGroupId, dbServerJson['db-server-short-name']))
    if not r:
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_delete_start', 'destory-error-03', 'destroy service group failed.')
        return
    
    log.info('update service group state to sg_delete_end') 
    r = installer.loop(3, installer.updateServiceGroupState, serviceGroup.serviceGroupId, 'sg_delete_end')
    if not r:
        log.info("update service group state failed.")
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_delete_start', 'destory-error-04', 'update status failed.')
        return
    
    log.info('end-of-destroy')

'''
'''
def scale(installer, serviceGroup):
        
    log.info('============= begin to scale {0}'.format(serviceGroup.serviceGroupId))
    
    log.info('check vm')
    ( r, output ) = installer.execCommand(goCheckVM)
    
    log.info('fetch service group detail.')
    if not fetchServiceGroupDetail( installer, serviceGroup.serviceGroupId, 'service-config.json'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_scale_ready', 'scale-error-01', 'fetch service group detail.')
        return  

    log.info('update service group state to sg_scale_start')
    if not updateServiceGroupState(installer, serviceGroup.serviceGroupId, 'sg_scale_start'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_scale_ready', 'scale-error-02', 'update status failed.')
        return        
    
    log.info('parse config-pdms/service-config.json to get instances and scale service')
    if not parseInstances(installer, serviceGroup.serviceGroupId):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_scale_start', 'scale-error-03', 'scale failed.')
        return
    
    log.info('update service group state to sg_deployed')
    if not updateServiceGroupState(installer, serviceGroup.serviceGroupId, 'sg_deployed'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_scale_start', 'scale-error-04', 'update status failed.')
        return        
    
    log.info('end-of-scale')
           

'''
upgrade sgw
'''
def upgradesgw(installer, serviceGroup):
    
    log.info('============= begin to upgrade sgw')
    
    log.info('update service state to gw_upgrade_start') 
    if not updateServiceGroupState(installer, serviceGroup.serviceGroupId, 'gw_upgrade_start'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'gw_upgrade_ready', 'sgwupgrade-error-01', 'update status failed.')
        return
            
    log.info('fetch service group detail.')
    if not fetchServiceGroupDetail( installer, serviceGroup.serviceGroupId, 'service-config.json'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'gw_upgrade_start', 'sgwupgrade-error-02', 'fetch service group detail.')
        return  

    log.info('upgrade sgw')
    ( r, output ) = installer.execCommand(goUpgradeSGW)
    if not r:
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'gw_upgrade_start', 'sgwupgrade-error-03', 'upgrade sgw failed.')
        return
    
    log.info('update service state to gw_upgrade_end') 
    if not updateServiceGroupState(installer, serviceGroup.serviceGroupId, 'gw_upgrade_end'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'gw_upgrade_start', 'sgwupgrade-error-04', 'update status failed.')
        return
    
    log.info('end-of-upgrade-sgw')
    
            
'''
'''
def destroysgw(installer, serviceGroup):
        
    log.info('============= begin to destroy {0}'.format(serviceGroup.serviceGroupId))
    
    log.info('update service state to sg_delete_start') 
    if not updateServiceGroupState(installer, serviceGroup.serviceGroupId, 'sg_delete_start'):
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_delete_ready', 'sgwdestory-error-01', 'update status failed.')
        return
    
    log.info('update service group state to sg_delete_end') 
    r = installer.loop(3, installer.updateServiceGroupState, serviceGroup.serviceGroupId, 'sg_delete_end')
    if not r:
        log.info("update service group state failed.")
        installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, 'sg_delete_start', 'sgwdestory-error-02', 'update status failed.')
        return
    
    log.info('end-of-destroy-sgw')

'''
set to failed
'''
def setFailed(installer, serviceGroup):
    
    log.info('============= begin to set service group to failed')
    
    log.info('update intermediate service group state to failed') 
    installer.loop(3, installer.updateServiceGroupStateFailed, serviceGroup.serviceGroupId, serviceGroup.state , 'setfailed-error-01', 'set intermediate start to failed status.')
            
    log.info('end-of-set-to-failed')
           
            
def installAll(clusterId):
    installer = Installer(address)
    log.info('search service group with state=sg_deploy_ready, they are to be installed')
    serviceGroupList = installer.loop(3, installer.searchServiceGroups, clusterId, 'Application', 'sg_deploy_ready')
    if( (not serviceGroupList) or ( len(serviceGroupList) == 0 ) ): 
        log.info('no sg_deploy_ready service group found.') 
    else:
        for serviceGroup in serviceGroupList:    
            log.info(serviceGroup.toString())
            if serviceGroup.state == 'sg_deploy_ready':
                install(installer, serviceGroup)

def upgradeAll(clusterId):
    installer = Installer(address)
    serviceGroupList = installer.loop(3, installer.searchServiceGroups, clusterId, 'Application', 'sg_upgrade_ready')
    if( (not serviceGroupList) or ( len(serviceGroupList) == 0 ) ): 
        log.info('no sg_upgrade_ready service group found.') 
    else:
        for serviceGroup in serviceGroupList:    
            log.info(serviceGroup.toString())
            if serviceGroup.state == 'sg_upgrade_ready':
                upgrade(installer, serviceGroup)

def serviceUpgradeAll(clusterId):
    installer = Installer(address)
    serviceGroupList = installer.loop(3, installer.searchServiceGroups, clusterId, 'Application', 's_upgrade_ready')
    if( (not serviceGroupList) or ( len(serviceGroupList) == 0 ) ): 
        log.info('no s_upgrade_ready service group found.') 
    else:
        for serviceGroup in serviceGroupList:    
            log.info(serviceGroup.toString())
            if serviceGroup.state == 's_upgrade_ready':
                serviceUpgrade(installer, serviceGroup)
                                
def rollbackAll(clusterId):
    installer = Installer(address)
    serviceGroupList = installer.loop(3, installer.searchServiceGroups, clusterId, 'Application', 'sg_rollback_ready')
    if( (not serviceGroupList) or ( len(serviceGroupList) == 0 ) ): 
        log.info('no sg_rollback_ready service group found.') 
    else:
        for serviceGroup in serviceGroupList:    
            log.info(serviceGroup.toString())
            if serviceGroup.state == 'sg_rollback_ready':
                rollback(installer, serviceGroup)

def destroyAll(clusterId):
    log.info('search service group with state=sg_delete_ready, they are to be destroyed')
    installer = Installer(address)
    serviceGroupList = installer.loop(3, installer.searchServiceGroups, clusterId, 'Application', 'sg_delete_ready')
    if( (not serviceGroupList) or ( len(serviceGroupList) == 0 ) ): 
        log.info('no sg_delete_ready service group found.')
    else:
        for serviceGroup in serviceGroupList:
            log.info(serviceGroup.toString())
            if serviceGroup.state == 'sg_delete_ready':
                destroy(installer, serviceGroup)
                

def scaleAll(clusterId):
    log.info('search service group with state=sg_scale_ready, they are to be scaled')
    installer = Installer(address)
    serviceGroupList = installer.loop(3, installer.searchServiceGroups, clusterId, 'Application', 'sg_scale_ready')
    if( (not serviceGroupList) or ( len(serviceGroupList) == 0 ) ): 
        log.info('no sg_scale_ready service group found.')
    else:
        for serviceGroup in serviceGroupList:
            log.info(serviceGroup.toString())
            if serviceGroup.state == 'sg_scale_ready':
                scale(installer, serviceGroup)

def upgradeAllSGW(clusterId):
    log.info('search service group with state=gw_upgrade_ready, they are to be upgrade')
    installer = Installer(address)
    serviceGroupList = installer.loop(3, installer.searchServiceGroups, clusterId, 'Gateway', 'gw_upgrade_ready')
    if( (not serviceGroupList) or ( len(serviceGroupList) == 0 ) ): 
        log.info('no gw_upgrade_ready service group found.') 
    else:
        for serviceGroup in serviceGroupList:    
            log.info(serviceGroup.toString())
            if serviceGroup.state == 'gw_upgrade_ready':
                upgradesgw(installer, serviceGroup)

def destroyAllSGW(clusterId):
    log.info('search sgw service group with state=sg_delete_ready, they are to be destroyed')
    installer = Installer(address)
    serviceGroupList = installer.loop(3, installer.searchServiceGroups, clusterId, 'Gateway', 'sg_delete_ready')
    if( (not serviceGroupList) or ( len(serviceGroupList) == 0 ) ): 
        log.info('no sg_delete_ready sgw service group found.')
    else:
        for serviceGroup in serviceGroupList:
            log.info(serviceGroup.toString())
            if serviceGroup.state == 'sg_delete_ready':
                destroysgw(installer, serviceGroup)
                
                 
def setToFailed(clusterId):
    log.info('search service group with intermediate state, will be set to failed')
    installer = Installer(address)
    serviceGroupList = installer.loop(3, installer.searchServiceGroups, clusterId, 'Application', 'start')
    if( (not serviceGroupList) or ( len(serviceGroupList) == 0 ) ): 
        log.info('no intermediate start status service group found.')
    else:
        for serviceGroup in serviceGroupList:
            log.info(serviceGroup.toString())
            if 'start' in serviceGroup.state :
                setFailed(installer, serviceGroup)  

def checkAvailability(clusterId): 
    log.info('check if this cluster {0} is running normally'.format(clusterId))
    installer = Installer(address)
    clusterFlag = installer.loop(3, installer.checkAPPCluster, clusterId)
    if not clusterFlag: 
        log.info('cluster {0} is not exist in ops, will exit this app python process'.format(clusterId))
        sys.exit(0)
                    
while(True):
    
#     clusterlist = list()
#     writejson()
#     for cluster in clusterlist:
        installAll('CURAPP_CLUSTER_ID')
    
        upgradeAll('CURAPP_CLUSTER_ID')
        
        serviceUpgradeAll('CURAPP_CLUSTER_ID')
        
        destroyAll('CURAPP_CLUSTER_ID')
        
        rollbackAll('CURAPP_CLUSTER_ID')
        
        scaleAll('CURAPP_CLUSTER_ID')
        
        upgradeAllSGW('CURAPP_CLUSTER_ID')
        
        destroyAllSGW('CURAPP_CLUSTER_ID')
        
        setToFailed('CURAPP_CLUSTER_ID')
        
        checkAvailability('CURAPP_CLUSTER_ID')
            
        log.info('wait next loop, sleep 10s.')
        time.sleep(10)        
    
log.info('end of loop')









