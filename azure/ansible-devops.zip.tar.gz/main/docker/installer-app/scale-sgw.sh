destJumphost=$1
newImageVersion=$2
curDeploymentName=$3
origImageVersion=""
newDeployedVersion=""
origDeployedVersion=""
number=$4
timer=40
retry_timer=40
scaleShellYml=./scale-sgw.yml
sgwjson=./json-ma-lb/service-gateway-service.json
scalejson=./config-pdms/scale-instance/scale-sgw.json
sgwimagejson=./config-pdms/scale-instance/service-gateway-version.json
marathonYml=./marathon.yml.gateway
getSgwInfoYml=./get-sgw-info.yml
getSgwVersionYml=./get-sgw-version.yml
copySgwMntYml=./copy-sgw-mnt.yml
sgwInfoJson=./config-pdms/scale-instance/service-gateway-info.json
PLCM=plcm
newCluster=false
function check_variable()
{
    if [ ${destJumphost}x == x ]; then
        echo "destination jumphost cannot be null"
        exit 1
    fi

    if [ "${newImageVersion}"x == x ]; then
        echo "upgrade version cannot be null"
        exit 1
    fi
    
    if [ "${curDeploymentName}"x == x ]; then
        echo "deployment name cannot be null"
        exit 1
    fi

    if [ "${number}"x == x ]; then
        echo "number is null, use the default value"
        number=3
    fi 
}
function copy_pdms_json_to_mnt()
{
    ansible-playbook ${copySgwMntYml} -e deployment=${curDeploymentName}
}
function scaledown_to_1()
{
    format_sgw_json 1 "orig"
    format_sgw_scale_json 1
    ansible-playbook ${scaleShellYml} --private-key=./config-pdms/id_rsa --user=${PLCM} -e "jumphost=${destJumphost}"
    echo "scale down to 1"
}

function init_orig_version()
{
    ansible-playbook ${getSgwVersionYml} --private-key=./config-pdms/id_rsa --user=${PLCM} -e "jumphost=${destJumphost}"
    
    sleep $retry_timer
    count=0
    while true;
    do
        if [ -f ${sgwimagejson} ]; then
            origImageVersion=`jq -r '.app.container.docker.image' ${sgwimagejson}`
            echo "origImageVersion version is ${origImageVersion}"
            grep "service-gateway-service' does not exist" ${sgwimagejson}
            if [ $? == 0 ]; then
                newCluster=true
                echo "new cluster is true"
            fi
            break;
        else
            sleep $retry_timer
            if [ $count == 3 ]; then
                echo "${sgwimagejson} is not exist"
                exit 1   
            fi
            let count=count+1
        fi
   done
}

function format_sgw_scale_json()
{
    scaleNumber=$1
    if [ ${scaleNumber} == x ]; then
        echo "scale number is null, will exist!"
        exit 1
    fi
    echo "{ \"instances\": ${scaleNumber} }" >${scalejson}
}
function format_sgw_json()
{
    instanceNumber=$1
    versionType=$2
    targetVersion=""
    if [ ${versionType}x == "orig"x ]; then
        targetVersion="${origImageVersion}"
    elif [ ${versionType}x == "new"x ]; then
        targetVersion="${newImageVersion}"
    fi
    if [ -f ${sgwjson} ]; then
        # replace image version
        curversion=`jq -r '.container.docker.image' ${sgwjson}`
        echo "current version is ${curversion}"       
        sed -i "s|${curversion}|${targetVersion}|g" ${sgwjson}
        # replace instance number
        curNumber=`grep instances ${sgwjson} |awk -F: '{print $2}'|awk -F, '{print $1}'`
        echo "current instance number is ${curNumber}"
        line=`grep -n instances ${sgwjson} |awk -F: '{print $1}'`
        sed -i "${line}s/${curNumber}/${instanceNumber}/" ${sgwjson}
        
        echo $(cat ${sgwjson})  
    else
        echo "${sgwjson} is not exist"
        exit 1 
    fi

}

function deploy_new_version()
{
    format_sgw_json 1 "new"
    ansible-playbook ${marathonYml} --private-key=./config-pdms/id_rsa --user=${PLCM} -e "jumphost=${destJumphost}" -e "state=deployed"
    #get_version_info "new"
}

function get_version_info()
{
    mod=$1
    if [ -f ${sgwInfoJson} ]; then
        rm -rf ${sgwInfoJson}
    fi
    ansible-playbook ${getSgwInfoYml} --private-key=./config-pdms/id_rsa --user=${PLCM} -e "jumphost=${destJumphost}"
    echo "get version info, mod is $mod"
    sleep $retry_timer
    count=0
    while true;
    do
        if [ -f ${sgwInfoJson} ]; then
            if [ ${mod}x == "new"x ]; then
                 newDeployedVersion=`jq .tasks[].version ${sgwInfoJson}|head -1`
                 echo "new deployed version is ${newDeployedVersion}"
                 if [ ${newDeployedVersion}x == x ]; then
                    echo "cannot get the new deployed version, will exist!"
                    format_sgw_json 1 "orig"
                    rollback
                    exit 1
                 else
                    break;
                 fi
            else
                origDeployedVersion=`jq .app.tasks[].version ${sgwimagejson}|head -1`
                echo "orig deployed version is ${origDeployedVersion}"
                if [ ${origDeployedVersion}x == x ]; then
                    echo "cannot get the old deployed version, will exist!"
                    exit 1
                else
                    break;
                fi
            fi
        else
            sleep $retry_timer
            if [ $count == 3 ]; then
                echo "cannot get service gateway file,rollback failed!"
                exit 1   
            fi
            let count=count+1
        fi
    done
}

function scaleup_to_n()
{
    deploy_mode=$1
    format_sgw_json ${number} ${deploy_mode}
    format_sgw_scale_json ${number}
    echo "scaleup to n and n is ${number}; deploy mod is $deploy_mode"
    ansible-playbook ${scaleShellYml} --private-key=./config-pdms/id_rsa --user=${PLCM} -e "jumphost=${destJumphost}"
}

# deploy old version and then scale to n
function rollback()
{
    echo "start rollback..."
    ansible-playbook ${marathonYml} --private-key=./config-pdms/id_rsa --user=${PLCM} -e "jumphost=${destJumphost}" -e "state=deployed"
    sleep ${timer}
    scaleup_to_n "orig"
    sleep ${timer}

    if [ -f ${sgwInfoJson} ]; then
        rm -rf ${sgwInfoJson}
    fi
    ansible-playbook ${getSgwInfoYml} --private-key=./config-pdms/id_rsa --user=${PLCM} -e "jumphost=${destJumphost}"
    sleep $retry_timer
    count=0
    while true;
    do
        if [ -f ${sgwimagejson} ]; then
            totalNumber=`jq .tasks[].stagedAt ${sgwInfoJson}|wc -l`
            if [ ${totalNumber}x == x ]; then
                echo "cannot get service gateway info,rollback failed"
                exit 1
            elif [ ${totalNumber}x != ${number}x ]; then
                echo "rollback failed"
                exit 1

            else
                break;
            fi
        else
            sleep $retry_timer
            if [ $count == 3 ]; then
                echo "cannot get service gateway file,rollback failed!"
                exit 1   
            fi
            let count=count+1
         fi
    done
}
function check_if_ok()
{
    stepMode=$1
    if [ -f ${sgwInfoJson} ]; then
        rm -rf ${sgwInfoJson}
    fi
    ansible-playbook ${getSgwInfoYml} --private-key=./config-pdms/id_rsa --user=${PLCM} -e "jumphost=${destJumphost}"
    sleep $retry_timer
    count=0
    kill=0
    while true
    do
        if [ -f ${sgwInfoJson} ]; then
            totalNumber=`jq .tasks[].stagedAt ${sgwInfoJson}|wc -l`
            state=`jq .tasks[].state ${sgwInfoJson}`
            echo -e "$state"|while read line
            do
                if [ $line != "\"TASK_RUNNING\"" ]; then
                    let kill=kill+1
                    echo $kill>./a.txt
                fi
            done
            echo "totalNumber is ${totalNumber}"
            echo $(cat ${sgwInfoJson})
            if [ -f ./a.txt ]; then    
                b=`echo $(cat ./a.txt)`
            else
                b=0
            fi
            echo "kill is ${b}"
            if [ ${totalNumber}x == x ]; then
                echo "cannot get service gateway info,rollback failed"
                exit 1
            elif [ ${b} != 0 ]; then
                echo "there is kill state, retry"
                rm -rf ./a.txt
                ansible-playbook ${getSgwInfoYml} --private-key=./config-pdms/id_rsa --user=${PLCM} -e "jumphost=${destJumphost}"
                let count=count+1
                sleep $retry_timer
                if [ $count == 3 ]; then
                    echo "still exist killing task,will rollback!"
                    break;
                fi
            else
                break;
            fi
        else
            sleep $retry_timer
            if [ $count == 3 ]; then
                echo "cannot get service gateway file,will rollback!"
                break;
            fi
            let count=count+1
        fi
    done
    
    if [ ${totalNumber}x == 1x ]; then
        if [ ${stepMode} == 1 ]; then    # scale down 1 
            echo "scale down succeed!"
        elif [ ${stepMode} == 2 ]; then  # deploy new version
            echo "deploy new version succeed!"
        else
            echo "deploy new version failed, will rollback"
            format_sgw_json 1 "orig"
            rollback
            exit 1
        fi
    elif [ ${totalNumber}x == ${number}x ]; then
        if [ ${stepMode} == 3 ]; then    # scale up n
            echo "scale up to ${number} succeed!"
        fi
    else                                 # roll back
        
        if [ ${stepMode} == 1 ]; then
            echo "start to rollback on scale down 1 case"
        elif [ ${stepMode} == 2 ]; then
            echo "start to rollback on deploy new version case"
        else
            echo "start to rollback on scale up to ${number} case"
        fi
        
        format_sgw_json 1 "orig"
        rollback
        exit 1
          
    fi


    
}

function deploy_new_cluster()
{
    format_sgw_json ${number} "new"
    if [ -f ${sgwjson} ]; then
        echo $(cat ${sgwjson})
    else
        echo "${sgwjson} is not exist"
        exit 1
    fi

    ansible-playbook ${marathonYml} --private-key=./config-pdms/id_rsa --user=${PLCM} -e "jumphost=${destJumphost}" -e "state=deployed"
    echo "deploy sgw on new cluster, successfully"
}
##############   main ###############

check_variable
copy_pdms_json_to_mnt
init_orig_version
if [ ${newCluster} == false ]; then
    scaledown_to_1
    check_if_ok 1
    get_version_info "old"
    get_version_info "new"
    deploy_new_version
    check_if_ok 2
    scaleup_to_n "new"
    check_if_ok 3
else
    deploy_new_cluster 
fi
