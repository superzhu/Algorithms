#!/usr/bin/python
# -*- coding: utf-8 -*-

import requests, json
import os
import subprocess
import time
import datetime
import logging
from logging.handlers import RotatingFileHandler
#from pythonjsonlogger import jsonlogger
import json_log_formatter
import jwt

class Log:

    def __init__(self, name):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.DEBUG)
        
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        
        # json format log
        #formatter = json_log_formatter.JSONFormatter()
        
        pythonpath=os.getcwd()
        logpath=pythonpath.replace('installer', 'installer-log')
        #logpath="/opt/polycom/pdms/installer-log/develop-1.0.0-40835/work/ins-app/"
        if (os.path.exists(logpath) != True):
            os.makedirs(logpath)
        filename=logpath+'/installer.log'
        fh = RotatingFileHandler(filename, maxBytes=100*1024*1024, backupCount=10)
        
        ch = logging.StreamHandler()
        fh.setFormatter(formatter)
        ch.setFormatter(formatter)
        if not self.logger.handlers:
            self.logger.addHandler(fh)
            self.logger.addHandler(ch)
    
    def error(self, msg):
        #self.logger.error(msg, extra={'executor': 'installer'})
        self.logger.error(msg)
                          
    def info(self, msg):
        #self.logger.info(msg, extra={'executor': 'installer'})
        self.logger.info(msg)
        
    def debug(self, msg):
        #self.logger.debug(msg, extra={'executor': 'installer'})
        self.logger.debug(msg)
        
log = Log('installer')

class DbServer:
    
    def fromDict(self, froms):
        self.serviceGroupId = froms['service-group-id']
        self.dbServer = froms['db-server']
        self.port = froms['port']
        self.dbaUser = froms['dba-user']
        self.dbaUserPassword = froms['dba-user-password']
        self.resourceGroupName = froms['resource-group-name']        

    def toDict(self):
        tos = dict()
        tos['service-group-id'] = self.serviceGroupId 
        tos['db-server'] = self.dbServer
        tos['port'] = self.port
        tos['dba-user'] = self.dbaUser
        tos['dba-user-password'] = self.dbaUserPassword
        tos['resource-group-name'] = self.resourceGroupName
        return tos
        
    def toString(self):
        return json.dumps(self.toDict())
        
class ServiceGroup:
    
    def fromDict(self, froms):
        self.serviceGroupId = froms['service-group-id']
        self.clusterId = froms['cluster-id']
        self.state = froms['state']
        self.serviceCategoryVersion = froms['service-category-version']
        self.extendAttribute = froms['extend-attribute']
        
    def toDict(self):
        tos = dict()
        tos['service-group-id'] = self.serviceGroupId 
        tos['cluster-id'] = self.clusterId
        tos['state'] = self.state
        tos['service-category-version'] = self.serviceCategoryVersion
        tos['extend-attribute'] = self.extendAttribute
        return tos
    
    def toString(self):
        return json.dumps(self.toDict())
        
            
class Installer:
    
    service_group_base_url = 'https://{0}/api/rest/rprm/service-groups'
    cluster_base_url = 'https://{0}/api/rest/rprm/cluster'
    pdms_verify=False
    
    def __init__(self, address):
        self.service_group_base_url = self.service_group_base_url.format(address)
        self.cluster_base_url = self.cluster_base_url.format(address)
        
    def create_token(self):
        try:
            # get pdms.json
            with open('./config-pdms/sg/pdms.json', 'r') as f:
                data = json.load(f)
                
            pdms_secrets=data['secrets']
            pdms_issuer=data['issuer']
            pdms_audience=data['audience']
            pdms_uid=data['uid']
            
            payload = {
                "iss": pdms_issuer,
                "exp": int(time.time()) + 86400 * 365,
                "aud": pdms_audience,
                "uid": pdms_uid
            }
            token = jwt.encode(payload, pdms_secrets, algorithm='HS256')
            #print(token)
            return token
        
        except BaseException as e:
            return None
        else:
            pass
    
    def get_tid(self):
        try:
            with open('/opt/installer/EnvParams/CURAPP_APPENV/ops.json', 'r') as f:
                data = json.load(f)
            pdms_tid=data['orion_tid']
            tid = pdms_tid
            return tid
        
        except BaseException as e:
            return None
        else:
            pass
    
    
    def createServiceGroup(self, serviceGroup):
        log.debug('=== createDbServer serviceGroup:{0}'.format(serviceGroup.serviceGroupId))
        token=self.create_token()
        tid=self.get_tid()
        if token == '' or token == None or tid == '' or tid == None:
            log.error('token or tid is null')
            return False
        headers = {'content-type': 'application/vnd.plcm.plcm-service-group+json', 'X-CA-JWT': token, 'X-CA-Tenant-ID': tid}
        respText = ''
        try:
            r = requests.post(self.service_group_base_url, data=json.dumps(serviceGroup.toDict()), headers=headers, verify=self.pdms_verify, timeout=10)
            respText = r.text
            r.raise_for_status()
        except requests.RequestException as e:
            log.error(e)
            log.error(respText)
            return False
        else:
            return True
    
    def searchServiceGroups(self, clusterId, categoryType, state):
        log.debug('=== searchServiceGroups clusterId:{0}, categoryType:{1}, state:{2}'.format(clusterId, categoryType, state))
        token=self.create_token()
        tid=self.get_tid()
        if token == '' or token == None or tid == '' or tid == None:
            log.error('token or tid is null')
            return False
        headers = {'X-CA-JWT': token, 'X-CA-Tenant-ID': tid}
        respText = ''
        try:
            r = requests.get(self.service_group_base_url, params={'cluster-id': clusterId, 'categoryType': categoryType}, headers=headers, verify=self.pdms_verify, timeout=10)
            respText = r.text
            r.raise_for_status()
        except requests.RequestException as e:
            log.error(e)
            log.error(respText)
        else:
            result = r.json()
            serviceGroupListDict = result['plcm-service-group']
            serviceGroupList = list()
            if(serviceGroupListDict): 
                for serviceGroupDict in serviceGroupListDict:
                    if(state):
                        if(serviceGroupDict['state'] == state):
                            serviceGroup = ServiceGroup()
                            serviceGroup.fromDict(serviceGroupDict)
                            serviceGroupList.append(serviceGroup)
                        elif( state in serviceGroupDict['state']):
                            serviceGroup = ServiceGroup()
                            serviceGroup.fromDict(serviceGroupDict)
                            serviceGroupList.append(serviceGroup)
                    else:
                        serviceGroup = ServiceGroup()
                        serviceGroup.fromDict(serviceGroupDict)
                        serviceGroupList.append(serviceGroup)
                        
            return serviceGroupList
    
    def updateServiceGroupState(self, serviceGroupId, state):
        log.debug('=== updateServiceGroupState serviceGroupId:{0}, state:{1}'.format(serviceGroupId, state))
        token=self.create_token()
        tid=self.get_tid()
        if token == '' or token == None or tid == '' or tid == None:
            log.error('token or tid is null')
            return False
        headers = {'content-type': 'application/json', 'X-CA-JWT': token, 'X-CA-Tenant-ID': tid}
        respText = ''
        try:
            r = requests.put(self.service_group_base_url + '/{0}/states'.format(serviceGroupId), params={'state':state}, headers=headers, verify=self.pdms_verify, timeout=10)
            respText = r.text
            r.raise_for_status()
        except requests.RequestException as e:
            log.error(e)
            log.error(respText)
            return False
        else:
            return True

    def updateServiceGroupStateFailed(self, serviceGroupId, currentState, errorCode, failedException):
        log.debug('=== updateServiceGroupStateFailed serviceGroupId:{0}, currentState:{1}'.format(serviceGroupId, currentState))
        token=self.create_token()
        tid=self.get_tid()
        if token == '' or token == None or tid == '' or tid == None:
            log.error('token or tid is null')
            return False
        headers = {'content-type': 'application/vnd.plcm.plcm-sg-service-group-state+json', 'X-CA-JWT': token, 'X-CA-Tenant-ID': tid}
        serviceGroupState = dict()
        serviceGroupState['current-state'] = currentState
        serviceGroupState['error-code'] = errorCode
        serviceGroupState['error-description'] = failedException
        respText = ''
        try:
            r = requests.put(self.service_group_base_url + '/{0}/states/exceptions'.format(serviceGroupId), data=json.dumps(serviceGroupState), headers=headers, verify=self.pdms_verify, timeout=10)
            respText = r.text
            r.raise_for_status()
        except requests.RequestException as e:
            log.error(e)
            log.error(respText)
            return False
        else:
            return True

    def getServiceGroupState(self, serviceGroupId):
        log.debug('=== getServiceGroupState serviceGroupId:{0}'.format(serviceGroupId))
        token=self.create_token()
        tid=self.get_tid()
        if token == '' or token == None or tid == '' or tid == None:
            log.error('token or tid is null')
            return False
        headers = {'Accept': 'application/vnd.plcm.plcm-string+json', 'X-CA-JWT': token, 'X-CA-Tenant-ID': tid}
        respText = ''
        try:
            r = requests.get(self.service_group_base_url + '/{0}/states'.format(serviceGroupId), headers=headers, verify=self.pdms_verify, timeout=10)
            respText = r.text
            r.raise_for_status()
        except requests.RequestException as e:
            log.error(e)
            log.error(respText)
            return False
        else:
            result = r.json();
            return result['value']
    
    def readServiceGroupDetail(self, serviceGroupId, detailType):
        log.debug('=== readServiceGroupDetail serviceGroupId:{0}'.format(serviceGroupId))
        token=self.create_token()
        tid=self.get_tid()
        if token == '' or token == None or tid == '' or tid == None:
            log.error('token or tid is null')
            return False
        headers = {'X-CA-JWT': token, 'X-CA-Tenant-ID': tid}
        respText = ''
        try:
            r = requests.get(self.service_group_base_url + '/{0}/detail'.format(serviceGroupId), params={'type':detailType}, headers=headers, verify=self.pdms_verify, timeout=10)
            respText = r.text
            r.raise_for_status()
        except requests.RequestException as e:
            log.error(e)
            log.error(respText)
            return False
        else:
            result = r.json()
            # write detail json
            #self.writeJson(result, 'config-pdms/', 'sgdetail.json')
            if result['service-group-resource']:
                return result
            else:
                return False
            
    def getDbServer(self, serviceGroupId, serverType):
        log.debug('=== getDbServer serviceGroupId:{0}'.format(serviceGroupId))
        token=self.create_token()
        tid=self.get_tid()
        if token == '' or token == None or tid == '' or tid == None:
            log.error('token or tid is null')
            return False
        headers = {'X-CA-JWT': token, 'X-CA-Tenant-ID': tid}
        respText = ''
        try:
            r = requests.get(self.service_group_base_url + '/{0}/dbserver'.format(serviceGroupId), params={'type':serverType}, headers=headers, verify=self.pdms_verify, timeout=10)
            respText = r.text
            r.raise_for_status()
        except requests.RequestException as e:
            log.error(e)
            log.error(respText)
            return False
        else:
            dbServerJson = r.json()
            return dbServerJson

    def searchServiceDatabases(self, serviceGroupId, dbServer):
        log.debug('=== searchServiceDatabases serviceGroupId:{0}'.format(serviceGroupId))
        token=self.create_token()
        tid=self.get_tid()
        if token == '' or token == None or tid == '' or tid == None:
            log.error('token or tid is null')
            return False
        headers = {'X-CA-JWT': token, 'X-CA-Tenant-ID': tid}
        respText = ''
        try:
            r = requests.get(self.service_group_base_url + '/{0}/dbserver/servicedatabases'.format(serviceGroupId), params={'db-server':dbServer}, headers=headers, verify=self.pdms_verify, timeout=10)
            respText = r.text
            r.raise_for_status()
        except requests.RequestException as e:
            log.error(e)
            log.error(respText)
            return False
        else:
            serviceDatabasesJson = r.json()
            return serviceDatabasesJson
    
    def checkAPPCluster(self, clusterid):
        log.debug('=== check if cluster {0} is existing'.format(clusterid))
        token=self.create_token()
        tid=self.get_tid()
        if token == '' or token == None or tid == '' or tid == None:
            log.error('token or tid is null')
            return True
        headers = {'X-CA-JWT': token, 'X-CA-Tenant-ID': tid, 'Accept': 'application/vnd.plcm.plcm-pdms-cluster+json'}
        respText = ''
        try:
            r = requests.get(self.cluster_base_url  + '/{0}'.format(clusterid), headers=headers, verify=self.pdms_verify, timeout=10)
            respText = r.text
            r.raise_for_status()
        except requests.RequestException as e:
            log.error(e)
            log.error(respText)
            return True
        else:
            if r.status_code == 204:
                log.debug('get cluster {0} detail return code is 204'.format(clusterid))
                return False
            #result = r.json()
            #if result and result['cluster-id'] == clusterid:
            #    return result
            else:
                return True               

    def readAPPCluster(self, clusterid):
        log.debug('=== readCluster detail:{0}'.format(clusterid))
        token=self.create_token()
        tid=self.get_tid()
        if token == '' or token == None or tid == '' or tid == None:
            log.error('token or tid is null')
            return False
        headers = {'X-CA-JWT': token, 'X-CA-Tenant-ID': tid, 'Accept': 'application/vnd.plcm.plcm-pdms-cluster+json'}
        respText = ''
        try:
            r = requests.get(self.cluster_base_url  + '/{0}'.format(clusterid), headers=headers, verify=self.pdms_verify, timeout=10)
            respText = r.text
            r.raise_for_status()
        except requests.RequestException as e:
            log.error(e)
            log.error(respText)
            return False
        else:
            if r.status_code == 204:
                return False
            result = r.json()
            if result and result['cluster-id'] == clusterid:
                return result
            else:
                return False
            
    def writeJson(self, objJson, path, file_name):
        if not os.path.exists(path):
            os.makedirs(path)
        configFile = path + file_name
#         with open(configFile, 'wt') as f:
#             f.write("{0}".format(json.dumps(objJson, indent=4)))
#             f.close()
        with open(configFile, 'w') as f:
            json.dump(objJson, f, indent=2)
    
    def execCommand(self, command):
        # n = os.system(command)
        ( n, output ) = subprocess.getstatusoutput(command)
        #n = n >> 8
        if( n == 0 ):
            log.debug('=== execute command {0} success.'.format(command))
            log.debug(output)
        else:
            log.error('=== execute command {0} failed with {1}.'.format(command, n))
            log.error(output)
        return ( n==0, output )
    
    def loop(self, loops, func, *args, **kwargs):
        for i in range(loops - 1):
            rst = func(*args, **kwargs)
            if rst:
                return rst
            
            log.debug('=== sleep 3s, try again.')
            time.sleep(3)
        return func(*args, **kwargs)
  






