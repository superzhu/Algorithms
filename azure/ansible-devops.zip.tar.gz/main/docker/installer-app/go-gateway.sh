#!/bin/bash

# destory service-gateway-service
#result_destory=$(ansible-playbook ./marathon.yml.gateway --private-key=./config-pdms/id_rsa --user=plcm -e "jumphost=CURAPP_JUMPHOST_NAME" -e "state=undeployed")
#echo $result_destory
#if [[ $result_destory =~ "unreachable=0" && $result_destory =~ "failed=0" ]]; then
#    echo "destory service-gateway-service successful"
#else
#    echo "destory service-gateway-service failed"
#    exit 1
#fi

# deploy service-gateway-service
result_deploy=$(ansible-playbook ./marathon.yml.gateway --private-key=./config-pdms/id_rsa --user=plcm -e "jumphost=CURAPP_JUMPHOST_NAME" -e "state=deployed")
echo "$result_deploy"
if [[ $result_deploy =~ "unreachable=0" && $result_deploy =~ "failed=0" ]]; then
    echo "deploy service-gateway-service successful"
else
    echo "deplory service-gateway-service failed"
    exit 2
fi

exit 0
