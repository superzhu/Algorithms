import os

def getJumphost(_hostvars, _groups, _name):
    try:
        mgmtGroup =  _hostvars[_name]['tags']['deployment'] + '-mgmt'
        typeTag = 'jump-linux'
    except KeyError:
        if _hostvars[_name]['tags']['jumphost'] == 'analytics':
            if 'AZURE_LOCATION' not in os.environ or os.environ['AZURE_LOCATION'] == "":
                raise Exception('Must set AZURE_LOCATION environment variable to filter inventory to a specific region.')
            mgmtGroup =  'analyticsrg'
            typeTag = 'jumphost'
        else:
            mgmtGroup =  _hostvars[_name]['tags']['jumphost'] + '-mgmt'
            typeTag = 'jump-linux'

    for i in _groups[mgmtGroup]:
        if _hostvars[i]['tags']['type'] == typeTag:
            return _hostvars[i]['ansible_host']
    return '';

class FilterModule(object):
     def filters(self):
         return { 'getJumphost': getJumphost }


