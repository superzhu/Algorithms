#!/bin/bash

sg=$1
partial_flag_fite=$2
partial_flag_sga=$3
partial_flag_service=$4

echo 'begin to partial upgrade service'
echo "partial_flag_fite: $partial_flag_fite"
echo "partial_flag_sga: $partial_flag_sga"
echo "partial_flag_service: $partial_flag_service"

updateInstanceNum() {
	# change id_rsa mode to 600
	chmod 600 ./config-pdms/id_rsa

	if [ ! -d "./json-ma-lb" ]; then
	  \cp -rf json-ma-lb-tmp json-ma-lb
	fi

	# get public and private agent num
	echo "get token"
	curl -X "POST" "https://login.microsoftonline.com/CURAPP_TENANT_ID/oauth2/token" \
	-H "Cookie: flight-uxoptin=true; stsservicecookie=ests; x-ms-gateway-slice=productionb; stsservicecookie=ests" \
	-H "Content-Type: application/x-www-form-urlencoded" \
	--data-urlencode "client_id=CURAPP_CLIENT_ID" \
	--data-urlencode "grant_type=client_credentials" \
	--data-urlencode "client_secret=CURAPP_CLIENT_SECRET" \
	--data-urlencode "resource=https://management.azure.com/" > ./config-pdms/server/token.json
	token=$(jq -r '.access_token' ./config-pdms/server/token.json)
	if [ $token == null ];then
		echo "get token failed"
		exit 1
	fi

	echo 'get scale set name'
	\cp -rpf ./config-pdms/scale-instance/get-scaleset.sh ./
	sed -i "s/TOKEN/$token/g" ./get-scaleset.sh
	./get-scaleset.sh
	scaleset=$(jq -r '.value[].name' ./config-pdms/scale-instance/get-scaleset-return.json)
	if [[ $scaleset == null ]]; then
		echo "there is no scale set"
		exit 2
	fi

	prinum=0
	pubnum=0
	newnum=0
	for setname in $scaleset; do
	  echo $setname
	  \cp -rpf ./config-pdms/scale-instance/get-scaleset-agent-num.sh ./
	  sed -i "s/TOKEN/$token/g" ./get-scaleset-agent-num.sh
	  sed -i "s/CURAPP_SCALESET/$setname/g" ./get-scaleset-agent-num.sh
	  ./get-scaleset-agent-num.sh
	  agentnum=$(jq -r '.virtualMachine.statusesSummary[0].count' ./config-pdms/scale-instance/get-scaleset-agent-num-return.json)
	  if [[ $agentnum == null || "$agentnum"x == ""x ]]; then
		echo "get $setname agent number failed"
		exit 3
	  fi
	  if [[ $setname =~ "private" ]]; then
		prinum=$agentnum
		echo "$setname private agent num is: $prinum"
	  elif [[ $setname =~ "public" ]]; then
		pubnum=$agentnum
		echo "$setname public agent num is: $pubnum"
	  fi
	  newnum=`expr $newnum + $agentnum`
	done
	echo "private plus public agent num is: $newnum"

	curfilenum=$(jq -r '.instances' ./json-ma-lb/marathon-lb-pdms.json)
	cur='"instances": '$curfilenum
	new='"instances": '$pubnum
	sed -i "s%$cur%$new%g" ./json-ma-lb/marathon-lb-pdms.json

	curfilenum=$(jq -r '.instances' ./json-ma-lb/filebeat-service.json)
	cur='"instances": '$curfilenum
	new='"instances": '$newnum
	sed -i "s%$cur%$new%g" ./json-ma-lb/filebeat-service.json

	curtelenum=$(jq -r '.instances' ./json-ma-lb/telegraf-service.json)
	cur='"instances": '$curtelenum
	sed -i "s%$cur%$new%g" ./json-ma-lb/telegraf-service.json
	curfilenum=$(jq -r '.instances' ./json-ma-lb/node-monitor-service.json)
	cur='"instances": '$curfilenum
	new='"instances": '$prinum
	sed -i "s%$cur%$new%g" ./json-ma-lb/node-monitor-service.json

}

if [ "$partial_flag_fite"x == "True"x ]; then
  echo "will modify instance num"
  updateInstanceNum
  echo 'will redeploy filebeat and telegraf and node-monitor-service'
  result_deploy=$(ansible-playbook ./marathon.yml.filetelenode --private-key=./config-pdms/id_rsa --user=plcm -e "jumphost=CURAPP_JUMPHOST_NAME" -e "state=deployed")
  echo "$result_deploy"
  if [[ $result_deploy =~ "unreachable=0" && $result_deploy =~ "failed=0" ]]; then
    echo "deploy filebeat, telegraf node-monitor-service successful"
  else
    echo "deplory filebeat, telegraf node-monitor-service failed"
    exit 1
  fi
fi

if [ "$partial_flag_sga"x == "True"x ]; then
  echo 'will redeploy sga'
  result_deploy=$(ansible-playbook ./marathon.yml.sga --private-key=./config-pdms/id_rsa --user=plcm -e "jumphost=CURAPP_JUMPHOST_NAME" -e "state=deployed" -e "sgid=$sg")
  echo "$result_deploy"
  if [[ $result_deploy =~ "unreachable=0" && $result_deploy =~ "failed=0" ]]; then
    echo "deploy sga successful"
  else
    echo "deplory sga failed"
    exit 2
  fi
fi

if [ "$partial_flag_service"x == "True"x ]; then
  echo "partial upgrade service"
  result_service=$(ansible-playbook ./marathon.yml --private-key=./config-pdms/id_rsa --user=plcm -e "jumphost=CURAPP_JUMPHOST_NAME" -e "state=deployed" -e "sgid=$sg")
  echo "$result_service"
  if [[ $result_service =~ "unreachable=0" && $result_service =~ "failed=0" ]]
  then
    echo "partial upgrade service successful"
  else
    echo "partial upgrade service failed"
    exit 3
  fi
fi

echo 'successfully done'
exit 0
