#!/bin/bash

# change id_rsa mode to 600
chmod 600 ./config-pdms/id_rsa


echo "get existing mnt of agent, and copy to local /mnt"
result=$(ansible-playbook ./get-mnt.yml -e "deployment=CURAPP_DEPLOYMENT_NAME")
echo "$result"
if [[ $result =~ "unreachable=0" && $result =~ "failed=0" ]]
then
    echo "get mnt successful"
else
    echo "get mnt failed"
    exit 1
fi

echo "tar mnt.tar.gz"
tar -zxvf ./config-pdms/mnt.tar.gz -C ./

exit 0
