#!/bin/bash

# change id_rsa mode to 600
chmod 600 ./config-pdms/id_rsa

echo "this operation will copy jumphost's authorized_keys to all master, public and private agent"
result=$(ansible-playbook ./get-ssh-auth.yml --private-key=./config-pdms/id_rsa --user=plcm -e "jumphost=CURAPP_JUMPHOST_NAME" -e "deployment=CURAPP_DEPLOYMENT_NAME")
echo "$result"
if [[ $result =~ "unreachable=0" && $result =~ "failed=0" ]]
then
    echo "copy successful"
else
    echo "copy failed"
    exit 1
fi

exit 0
