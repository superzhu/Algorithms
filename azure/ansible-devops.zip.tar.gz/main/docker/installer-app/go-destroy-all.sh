#!/bin/bash

sg=$1
servername=$2

# change id_rsa mode to 600
chmod 600 ./config-pdms/id_rsa

# destroy service group
echo "destroy service group: "$sg
./go-destroy-sg.sh $sg
if [ $? != 0 ];then
    echo "destroy service group failed: "$sg
    exit 1
fi

# destroy sql server
echo "destroy sql server: "$servername
./go-destroy-server.sh $servername
if [ $? != 0 ];then
    echo "destroy sql server failed: "$servername
    exit 2
fi

echo "destroy service group, sql server and database over"
exit 0
