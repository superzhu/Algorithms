#!/bin/bash

# change id_rsa mode to 600
chmod 600 ./config-pdms/id_rsa


echo "execute mount-disk.yml"
result=$(ansible-playbook ./mount-disk.yml -e "deployment=CURAPP_DEPLOYMENT_NAME")
echo "$result"
if [[ $result =~ "unreachable=0" && $result =~ "failed=0" ]]
then
    echo "execute mount-disk.yml successful"
else
    echo "execute mount-disk.yml failed"
    exit 1
fi

exit 0
