#!/bin/bash

# change id_rsa mode to 600
chmod 600 ./config-pdms/id_rsa


echo "modify /etc/hosts of all agent and jumphost, copy filebeat.yml to /etc/filebeat/filebeat.yml"
result=$(ansible-playbook ./filebeat-config.yml --private-key=./config-pdms/id_rsa --user=plcm -e "jumphost=CURAPP_JUMPHOST_NAME" -e "deployment=CURAPP_DEPLOYMENT_NAME")
echo "$result"
if [[ $result =~ "unreachable=0" && $result =~ "failed=0" ]]
then
    echo "modify /etc/hosts successful"
else
    echo "modify /etc/hosts failed"
    exit 1
fi

exit 0
