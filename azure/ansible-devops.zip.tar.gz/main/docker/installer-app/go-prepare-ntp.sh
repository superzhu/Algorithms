#!/bin/bash
# change id_rsa mode to 600
chmod 600 ./config-pdms/id_rsa


echo "ntp"
result=$(ansible-playbook ./ntp_config.yml --private-key=./config-pdms/id_rsa --user=plcm -e deployment=CURAPP_DEPLOYMENT_NAME -e "jumphost=CURAPP_JUMPHOST_NAME")
echo "$result"
if [[ $result =~ "unreachable=0" && $result =~ "failed=0" ]]
then
    echo "ntp successful"
else
    echo "ntp failed"
    exit 1
fi

exit 0
