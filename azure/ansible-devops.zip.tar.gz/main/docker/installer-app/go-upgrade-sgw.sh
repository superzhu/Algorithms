#!/bin/bash

# change id_ras mode to 600
chmod 600 ./config-pdms/id_rsa

# prevent json-ma-lb not exists
echo "create json-ma-lb from json-ma-lb-tmp"
\rm -rf json-ma-lb
\cp -rf json-ma-lb-tmp json-ma-lb

# parse service-config.properties to get sgw image
num=0
sgw_image=""
while [[ $(jq -r --argjson servicenum "$num" '."service-group-resource"[$servicenum]."release-service-version"."micro-service-name"' ./config-pdms/service-config.json) != null ]]; do
  servicename=$(jq -r --argjson servicenum "$num" '."service-group-resource"[$servicenum]."release-service-version"."micro-service-name"' ./config-pdms/service-config.json)
  if [[ $servicename == "service-gateway-service" ]]; then
    sgw_image=$(jq -r --argjson servicenum "$num" '."service-group-resource"[$servicenum]."release-service-version"."build-image"' ./config-pdms/service-config.json)
  fi
  num=$[$num+1]
done

if [[ "$sgw_image"x == ""x ]]; then
  echo "there is no sgw info in ./config-pdms/service-config.json"
  exit 2
fi


jumphost="CURAPP_JUMPHOST_NAME"
deployment="CURAPP_DEPLOYMENT_NAME"
# execute scale-sgw.sh
echo "begin to execute scale-sgw.sh"
./scale-sgw.sh $jumphost $sgw_image $deployment
if [ $? != 0 ]; then
  echo "execute scale-sgw.sh failed"
  exit 3
fi

exit 0
