#!/bin/bash


echo "reboot agent"
flag=$1
if [[ "$flag"x == ""x ]]; then
    echo "will only reboot public and private agent"
    result=$(ansible-playbook ./reboot-agent.yml  -e "deployment=CURAPP_DEPLOYMENT_NAME" -e "agent=:&dcos_slave")
elif [[ $flag == "master" ]]; then
    echo "will reboot master, public and private agent"
    result=$(ansible-playbook ./reboot-agent.yml  -e "deployment=CURAPP_DEPLOYMENT_NAME" -e "agent=")
else 
    echo "error parameter, only null or master can work"
    exit 1
fi
#result=$(ansible-playbook ./reboot-agent.yml  -e "deployment=CURAPP_DEPLOYMENT_NAME")
echo "$result"
if [[ $result =~ "unreachable=0" && $result =~ "failed=0" ]]
then
    echo "reboot agent successful"
else
    echo "reboot agent failed"
    exit 1
fi

exit 0
