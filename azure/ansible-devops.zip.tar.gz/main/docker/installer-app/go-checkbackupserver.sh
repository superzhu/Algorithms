#!/bin/bash

echo "parse dbserver.json to get server name"
file="./config-pdms/dbserver.json"
if [ -f "$file" ]
then
  servername=$(jq -r '."db-server-short-name"' ./config-pdms/dbserver.json)
  echo $servername
  if [[ $servername == null ]]; then
    echo "servername from dbserver.json is null"
    exit 2
  fi
else
  echo "$file not found."
  exit 1
fi

echo "parse servicedatabase.json to get database name"
file="./config-pdms/servicedatabase.json"
if [ -f "$file" ]
then
  dbnames=$(jq -r '."plcm-sg-service-database"[]."db-name"' ./config-pdms/servicedatabase.json)
  echo "databases are: "$dbnames
  if [[ $dbnames == null ]]; then
    echo "db-name is null"
    exit 4
  fi
else
  echo "$file not found."
  exit 3
fi

echo "get token"
curl -X "POST" "https://login.microsoftonline.com/CURAPP_TENANT_ID/oauth2/token" \
-H "Cookie: flight-uxoptin=true; stsservicecookie=ests; x-ms-gateway-slice=productionb; stsservicecookie=ests" \
-H "Content-Type: application/x-www-form-urlencoded" \
--data-urlencode "client_id=CURAPP_CLIENT_ID" \
--data-urlencode "grant_type=client_credentials" \
--data-urlencode "client_secret=CURAPP_CLIENT_SECRET" \
--data-urlencode "resource=https://management.azure.com/" > ./config-pdms/server/token.json
token=$(jq -r '.access_token' ./config-pdms/server/token.json)
echo $token
if [ $token == null ];then
    echo "get token failed"
    exit 5
fi

echo "check $servername existence"
\cp -rf ./config-pdms/server/checkserver.sh ./
sed -i "s/TOKEN/$token/g" ./checkserver.sh
sed -i "s/OLDSERVERNAME/$servername/g" ./checkserver.sh
./checkserver.sh
if grep -q 'Ready' ./config-pdms/server/checkserver-return.json; then
    echo "$servername exists"
else
    echo "$servername not exists"
    result_error=$(jq -r '.error.message' ./config-pdms/server/checkserver-return.json)
    echo $result_error
    exit 6
fi

echo "check $dbnames existence"
for dbname in $dbnames
do
    \cp -rf ./config-pdms/server/checkdb.sh ./
    sed -i "s/TOKEN/$token/g" ./checkdb.sh
    sed -i "s/OLDSERVERNAME/$servername/g" ./checkdb.sh
    sed -i "s/OLDDATABASE/$dbname/g" ./checkdb.sh
    ./checkdb.sh
    if grep -q 'Online' ./config-pdms/server/checkdb-return.json; then
        echo "$dbname exists"
    else
        echo "$dbname not exists"
        result_derror=$(jq -r '.error.message' ./config-pdms/server/checkdb-return.json)
        echo $result_derror
        exit 7
    fi
done

exit 0
