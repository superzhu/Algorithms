#!/bin/bash

sg=$1
servicename=$2
newinstancenum=$3

targetservice=""
services="$servicename pdms-$servicename"
for service in $services
do
    echo "check if $sg/$service exists"
    result=$(ansible-playbook ./get-scale-check.yml --private-key=./config-pdms/id_rsa --user=plcm -e "jumphost=CURAPP_JUMPHOST_NAME" -e "sgid=$sg" -e "servicename=$service")
    echo "$result"
    if [[ $result =~ "unreachable=0" && $result =~ "failed=0" ]]; then
        echo "exec check successful"
    else
        echo "exec check failed"
    fi
    if [ ! -f  "./config-pdms/scale-instance/scale-check.json" ]; then
        echo "there is no ./config-pdms/scale-instance/scale-check.json"
    else
        checkresult=$(jq -r '.app' ./config-pdms/scale-instance/scale-check.json)
        if [[ $checkresult == "null" ]]; then
            checkesult=$(jq -r '.message' ./config-pdms/scale-instance/scale-check.json)
            echo "$service not exists : $checkresult"
        else
            echo "$sg/$service exists"
            targetservice=$service
            break
        fi
    fi
done

if [[ "$targetservice"x == ""x ]]; then
    echo "$services not exists, will exit"
    exit 1
fi

echo "begin to scale $sg/$targetservice"
curinstancenum=$(jq -r '.instances' ./config-pdms/scale-instance/scale.json)
sed -i "s%$curinstancenum%$newinstancenum%g" ./config-pdms/scale-instance/scale.json
result_scale=$(ansible-playbook ./get-scale-info.yml --private-key=./config-pdms/id_rsa --user=plcm -e "jumphost=CURAPP_JUMPHOST_NAME" -e "sgid=$sg" -e "servicename=$targetservice")
echo "$result_scale"
if [[ $result_scale =~ "unreachable=0" && $result_scale =~ "failed=0" ]]; then
  echo "exec scale and fetch scale-result.json successful"
else
  echo "exec scale and fetch scale-result.json failed"
  exit 2
fi
# parse scale-result.json
if [ ! -f  "./config-pdms/scale-instance/scale-result.json" ]; then
  echo "there is no ./config-pdms/scale-instance/scale-result.json"
  exit 2
else
  scaleresult=$(jq -r '.version' ./config-pdms/scale-instance/scale-result.json)
  if [[ $scaleresult == "null" ]]; then
    scaleresult=$(jq -r '.message' ./config-pdms/scale-instance/scale-result.json)
    echo "scale "$sg/$targetservice" failed: "$scaleresult
    exit 2
  else
    echo "$sg/$targetservice scale successful"
  fi
fi

exit 0

