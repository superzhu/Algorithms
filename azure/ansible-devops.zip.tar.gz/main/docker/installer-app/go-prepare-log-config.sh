#!/bin/bash

# change id_rsa mode to 600
chmod 600 ./config-pdms/id_rsa


echo "log rollover"
result=$(ansible-playbook ./log-config.yml  -e "deployment=CURAPP_DEPLOYMENT_NAME")
echo "$result"
if [[ $result =~ "unreachable=0" && $result =~ "failed=0" ]]
then
    echo "add log config successful"
else
    echo "add log config failed"
    exit 1
fi

echo "syslog config, execute change_log_rotate.sh"
result=$(ansible-playbook ./syslog-config.yml -e "deployment=CURAPP_DEPLOYMENT_NAME")
echo "$result"
if [[ $result =~ "unreachable=0" && $result =~ "failed=0" ]]
then
    echo "syslog config successful"
else
    echo "syslog config failed"
    exit 2
fi

exit 0
