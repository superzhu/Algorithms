#!/bin/bash
FILE=/etc/fstab
`grep /dev/sdb $FILE`
if [ $? != 0 ]; then
    mkfs.ext4 /dev/sdb1|echo yes
    mkfs.ext4 /dev/sdb2|echo yes
    mkfs.ext4 /dev/sdb3|echo yes
    uuid1=`blkid /dev/sdb1|grep UUID|awk '{print $2}'|awk -F= '{print $2}'`
    uuid2=`blkid /dev/sdb2|grep UUID|awk '{print $2}'|awk -F= '{print $2}'`
    uuid3=`blkid /dev/sdb3|grep UUID|awk '{print $2}'|awk -F= '{print $2}'`
    line=`grep -n "/var/lib/mesos" ${FILE}|awk -F: '{print $1}'`
    if [ ${line}x != x ]; then
        sed -i "${line}d" ${FILE}
    fi
    if [ ${uuid1}x != x ]; then
        echo "UUID=${uuid1}       /var/lib/mesos        ext4   defaults,discard        0 0" >>$FILE
    fi
    if [ ${uuid1}x != x ]; then
        echo "UUID=${uuid2}       /var/log        ext4   defaults,discard        0 0" >>$FILE
    fi
    if [ ${uuid1}x != x ]; then
        echo "UUID=${uuid3}       /media        ext4   defaults,discard        0 0" >>$FILE
    fi
    
fi
