#!/bin/bash

sg=$1

# change id_ras mode to 600
chmod 600 ./config-pdms/id_rsa

echo "clean up agent, including delete images, containers, volumes"
result_delete=$(ansible-playbook ./delete-images.yml -e deployment=CURAPP_DEPLOYMENT_NAME)
echo "clean up done"

# deploy redis sentinel rabbitmq
echo "deploy redis sentinel rabbitmq"
./go-base.sh $sg
if [ $? != 0 ];then
    echo "go-base-sga.sh failed at deploy redis sentinel rabbitmq"
    exit 2
fi

# deploy sga
echo "deploy sga"
./go-sga.sh $sg
if [ $? != 0 ];then
    echo "go-base-sga.sh failed at deploy sga"
    exit 3
fi

exit 0
