file="/etc/default/grub"
swap_partition=/var/lib/mesos/swapfile
variable="GRUB_CMDLINE_LINUX="
line=`grep -n $variable $file|awk -F: '{print $1}'`
if [ ${line}x != x ]; then
    sed -i.bak "/${variable}/d" ${file}
    sed -i "${line} i\GRUB_CMDLINE_LINUX=\"cgroup_enable=memory swapaccount=1\"" $file
    update-grub
fi

ret=`free -h|grep Swap|awk '{print $2}'`
if [ ${ret}x == 0Bx ]; then
   fallocate -l 4G ${swap_partition}
   chmod 600 ${swap_partition}
   mkswap ${swap_partition}
   swapon ${swap_partition}
   cp /etc/fstab /etc/fstab.bak
   echo '/var/lib/mesos/swapfile none swap sw 0 0' | tee -a /etc/fstab
fi
grep swappiness /etc/sysctl.conf
if [ $? != 0 ]; then
    echo 'vm.swappiness=10'|tee -a /etc/sysctl.conf
fi
grep vfs_cache_pressure /etc/sysctl.conf
if [ $? != 0 ]; then
    echo 'vm.vfs_cache_pressure=50'|tee -a /etc/sysctl.conf
fi

