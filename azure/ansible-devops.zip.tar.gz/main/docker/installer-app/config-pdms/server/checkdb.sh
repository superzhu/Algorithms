#!/bin/bash

curl -X "GET" "https://management.azure.com/subscriptions/CURAPP_SUBSCRIPTION_ID/resourceGroups/CURAPP_RESOURCEGROUP_DCOS/providers/Microsoft.Sql/servers/OLDSERVERNAME/databases/OLDDATABASE?api-version=2014-04-01" \
-H "Authorization: Bearer TOKEN" > ./config-pdms/server/checkdb-return.json

