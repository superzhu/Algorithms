#!/bin/bash

#curl -X "PUT" "https://management.azure.com/subscriptions/CURAPP_SUBSCRIPTION_ID/resourceGroups/CURAPP_RESOURCEGROUP_DCOS/providers/Microsoft.Sql/servers/SERVERNAME/firewallRules/pdms-rule?api-version=2014-04-01" \
#-d "@./config-pdms/server/serverrule.json" \
#-H "Content-type: application/json" \
#-H "Authorization: Bearer TOKEN"


curl -X "PUT" "https://management.azure.com/subscriptions/CURAPP_SUBSCRIPTION_ID/resourceGroups/CURAPP_RESOURCEGROUP_DCOS/providers/Microsoft.Sql/servers/SERVERNAME/firewallRules/pdms-rule?api-version=2014-04-01" \
-d "@./config-pdms/server/serverrule.json" \
-H "Content-type: application/json" \
-H "Authorization: Bearer TOKEN" > ./config-pdms/server/createserverrule-return.json

