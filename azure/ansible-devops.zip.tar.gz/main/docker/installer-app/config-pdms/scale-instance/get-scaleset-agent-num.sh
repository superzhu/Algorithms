#!/bin/bash
curl -X "GET" "https://management.azure.com/subscriptions/CURAPP_SUBSCRIPTION_ID/resourceGroups/CURAPP_RESOURCEGROUP_DCOS/providers/Microsoft.Compute/VirtualMachineScaleSets/CURAPP_SCALESET/instanceView?api-version=2016-04-30-preview" \
-H "Authorization: Bearer TOKEN" > ./config-pdms/scale-instance/get-scaleset-agent-num-return.json
