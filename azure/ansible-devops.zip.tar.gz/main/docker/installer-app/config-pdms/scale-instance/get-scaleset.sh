#!/bin/bash
curl -X "GET" "https://management.azure.com/subscriptions/CURAPP_SUBSCRIPTION_ID/resourceGroups/CURAPP_RESOURCEGROUP_DCOS/providers/Microsoft.Compute/virtualMachineScaleSets?api-version=2017-12-01" \
-H "Authorization: Bearer TOKEN" > ./config-pdms/scale-instance/get-scaleset-return.json
