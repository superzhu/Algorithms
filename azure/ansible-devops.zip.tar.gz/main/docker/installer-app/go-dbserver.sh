#!/bin/bash

#sgid=$1

# parse dbserver.json to get servername, user, passwd
echo "begin to parse dbserver.json"

file="./config-pdms/dbserver.json"
if [ -f "$file" ]
then
  echo "$file found."
  
  servername=$(jq -r '."db-server-short-name"' ./config-pdms/dbserver.json)
  serveruser=$(jq -r '."dba-user"' ./config-pdms/dbserver.json)
  serverpass=$(jq -r '."dba-user-password-decrypted"' ./config-pdms/dbserver.json)
  if [[ $servername == null || $serveruser == null || $serverpass == null ]]; then
    echo "at least one of these three is null:"
    echo "server name:"$servername" server user:"$serveruser" server password:"$serverpass
    exit 2
  fi
  echo "new server info: "$servername" "$serveruser" "$serverpass
  # modify config-pdms/server/sqlserver.json
#  curuser=$(jq -r '.properties.administratorLogin' ./config-pdms/server/sqlserver.json)
#  curpass=$(jq -r '.properties.administratorLoginPassword' ./config-pdms/server/sqlserver.json)
#  sed -i "s/$curuser/$serveruser/g" ./config-pdms/server/sqlserver.json
#  sed -i "s/$curpass/$serverpass/g" ./config-pdms/server/sqlserver.json
#  echo "replaced sqlserver.json successfully"
else
  echo "$file not found."
  exit 1
fi

# create sql server
echo "begin to create sql server: "$servername

echo "get token"
curl -X "POST" "https://login.microsoftonline.com/CURAPP_TENANT_ID/oauth2/token" \
-H "Cookie: flight-uxoptin=true; stsservicecookie=ests; x-ms-gateway-slice=productionb; stsservicecookie=ests" \
-H "Content-Type: application/x-www-form-urlencoded" \
--data-urlencode "client_id=CURAPP_CLIENT_ID" \
--data-urlencode "grant_type=client_credentials" \
--data-urlencode "client_secret=CURAPP_CLIENT_SECRET" \
--data-urlencode "resource=https://management.azure.com/" > ./config-pdms/server/token.json
token=$(jq -r '.access_token' ./config-pdms/server/token.json)
echo $token
if [ $token == null ];then
    echo "get token failed"
    exit 3
fi

echo "create server"
\cp -rf ./config-pdms/server/createserver.sh ./
sed -i "s/TOKEN/$token/g" ./createserver.sh 
sed -i "s/SERVERNAME/$servername/g" ./createserver.sh

\cp -rf ./config-pdms/server/checkserver.sh ./
sed -i "s/TOKEN/$token/g" ./checkserver.sh
sed -i "s/OLDSERVERNAME/$servername/g" ./checkserver.sh


busy_code="40501 49918 49919"
timesnum=1
sleeptime=10
while [[ $timesnum -le 5 ]]; do
    ./createserver.sh
    if grep -q 'Ready' ./config-pdms/server/createserver-return.json; then
        echo "create server:"$servername" successfully"
        break
    else
        result_timeout=$(jq -r '.error.code' ./config-pdms/server/createserver-return.json)
        result_busy=$(jq -r '.code' ./config-pdms/server/createserver-return.json)
        if [[ $result_timeout == "GatewayTimeout" || $busy_code =~ $result_busy ]]; then
            sleeptime=$[$sleeptime*2]
            #sleeptime=$[$timesnum*10]
            echo "ERROR---$result_timeout $result_busy, will sleep $sleeptime seconds and try again, the $timesnum time"
            sleep $sleeptime
            echo 'check new server existence'
            ./checkserver.sh
            if grep -q 'Ready' ./config-pdms/server/checkserver-return.json; then
                echo "new server $servername exists"
                break
            fi
            timesnum=$[$timesnum+1]
            continue
        else
            result_error=$(jq -r '.error' ./config-pdms/server/createserver-return.json)
            result_code=$(jq -r '.message' ./config-pdms/server/createserver-return.json)
            if [[ $result_error != null ]]; then
                echo $result_error
            fi
            if [[ $result_code != null ]]; then
                echo $result_code
            fi
            echo "create server:"$servername" failed"
            exit 4
        fi
    fi
done


echo "create firewall rule "
\cp -rf ./config-pdms/server/createserverrule.sh ./
sed -i "s/TOKEN/$token/g" ./createserverrule.sh
sed -i "s/SERVERNAME/$servername/g" ./createserverrule.sh
./createserverrule.sh
if grep -q 'pdms-rule' ./config-pdms/server/createserverrule-return.json; then
    echo "create rule successfully"
else
    echo "create rule failed"
    exit 5
fi

exit 0
