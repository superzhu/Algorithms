#!/bin/bash

sg=$1

### deploy service

result_sga=$(ansible-playbook ./marathon.yml.sga --private-key=./config-pdms/id_rsa --user=plcm -e "jumphost=CURAPP_JUMPHOST_NAME" -e "state=deployed" -e "sgid=$sg")
echo "$result_sga"
if [[ $result_sga =~ "unreachable=0" && $result_sga =~ "failed=0" ]]
then
    echo "deploy sga successful"
else
    echo "deploy sga failed"
    exit 1
fi

exit 0
