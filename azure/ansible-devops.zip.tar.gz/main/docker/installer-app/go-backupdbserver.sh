#!/bin/bash

#sg=$1
newservername=$1

#oldservername="sg75-pdms-sql-server"
#newservername="sg75-bak-pdms-sql-server"
#dbnames="epmdb userdb"

echo "begin to backup server and database"
# get oldservername from dbserver.json, get old database from servicedatabase.json
echo "begin to parse dbserver.json to get old server name"
file="./config-pdms/dbserver.json"
if [ -f "$file" ]
then
  echo "$file found."
  oldservername=$(jq -r '."db-server-short-name"' ./config-pdms/dbserver.json)
  echo $oldservername
  if [[ $oldservername == null ]]; then
    echo "oldservername from dbserver.json is null"
    exit 2
  fi
else
  echo "$file not found."
  exit 1
fi

echo "begin to parse servicedatabase.json to get old database name"
file="./config-pdms/servicedatabase.json"
if [ -f "$file" ]
then
  echo "$file found."
  dbnames=$(jq -r '."plcm-sg-service-database"[]."db-name"' ./config-pdms/servicedatabase.json)
  echo "databases are: "$dbnames
  if [[ $dbnames == null ]]; then
    echo "db-name is null"
    exit 4
  fi
else
  echo "$file not found."
  exit 3
fi

### create a new server
# get token
echo "get token"
curl -X "POST" "https://login.microsoftonline.com/CURAPP_TENANT_ID/oauth2/token" \
-H "Cookie: flight-uxoptin=true; stsservicecookie=ests; x-ms-gateway-slice=productionb; stsservicecookie=ests" \
-H "Content-Type: application/x-www-form-urlencoded" \
--data-urlencode "client_id=CURAPP_CLIENT_ID" \
--data-urlencode "grant_type=client_credentials" \
--data-urlencode "client_secret=CURAPP_CLIENT_SECRET" \
--data-urlencode "resource=https://management.azure.com/" > ./config-pdms/server/token.json
token=$(jq -r '.access_token' ./config-pdms/server/token.json)
echo $token
if [ $token == null ];then
    echo "get token failed"
    exit 5
fi

echo 'check new server existence'
\cp -rf ./config-pdms/server/checkserver.sh ./
sed -i "s/TOKEN/$token/g" ./checkserver.sh
sed -i "s/OLDSERVERNAME/$newservername/g" ./checkserver.sh
./checkserver.sh
if grep -q 'Ready' ./config-pdms/server/checkserver-return.json; then
    echo "ERROR---new server $newservername is already exists"
    exit 6
else
    echo "new server $newservername not exists"
fi


# create new server
echo "create backup server"
\cp -rf ./config-pdms/server/createserver.sh ./
sed -i "s/TOKEN/$token/g" ./createserver.sh
sed -i "s/SERVERNAME/$newservername/g" ./createserver.sh

busy_code="40501 49918 49919"
timesnum=1
sleeptime=10
while [[ $timesnum -le 5 ]]; do
    ./createserver.sh
    if grep -q 'Ready' ./config-pdms/server/createserver-return.json; then
        echo "create server:"$newservername" successfully"
        break
    else
        result_timeout=$(jq -r '.error.code' ./config-pdms/server/createserver-return.json)
        result_busy=$(jq -r '.code' ./config-pdms/server/createserver-return.json)
        if [[ $result_timeout == "GatewayTimeout" || $busy_code =~ $result_busy ]]; then
            sleeptime=$[$sleeptime*2]
            echo "ERROR---$result_timeout $result_busy, will sleep $sleeptime seconds and try again, the $timesnum time"
            sleep $sleeptime
            echo 'check new server existence'
            ./checkserver.sh
            if grep -q 'Ready' ./config-pdms/server/checkserver-return.json; then
                echo "new server $newservername exists"
                break
            fi
	    timesnum=$[$timesnum+1]
            continue
        else
            result_error=$(jq -r '.error' ./config-pdms/server/createserver-return.json)
            result_code=$(jq -r '.message' ./config-pdms/server/createserver-return.json)
            if [[ $result_error != null ]]; then
                echo $result_error
            fi
            if [[ $result_code != null ]]; then
                echo $result_code
            fi
            echo "create server:"$newservername" failed"
            exit 7
        fi
    fi
done

# create firewall rule
echo "create firewall rule "
\cp -rf ./config-pdms/server/createserverrule.sh ./
sed -i "s/TOKEN/$token/g" ./createserverrule.sh
sed -i "s/SERVERNAME/$newservername/g" ./createserverrule.sh

ruletimes=1
while [[ $ruletimes -le 5 ]]; do
  ./createserverrule.sh
  if grep -q 'pdms-rule' ./config-pdms/server/createserverrule-return.json; then
    echo "create rule successfully"
    break
  else
    echo "create rule failed, will sleep 20s and try again"
    ruletimes=$[$ruletimes+1]
    sleep 20
    continue
  fi
done

if [[ $ruletimes -gt 5 ]]; then
    echo "timeout for create rule, so failed"
    exit 8
fi

### copy database of old server to new server

# when the old server or database not exist, the copy command will not return error, so need to check the existence of old server and old database
echo "check old server and database's existence"

# check server's existence
\cp -rf ./config-pdms/server/checkserver.sh ./
sed -i "s/TOKEN/$token/g" ./checkserver.sh
sed -i "s/OLDSERVERNAME/$oldservername/g" ./checkserver.sh
./checkserver.sh
if grep -q 'Ready' ./config-pdms/server/checkserver-return.json; then
    echo "old server:"$oldservername" exists"
else
    echo "old server:"$oldservername" not exists"
    result_serror=$(jq -r '.error.message' ./config-pdms/server/checkserver-return.json)
    echo $result_serror
    exit 9
fi

# check database's existence
for dbname in $dbnames
do
    \cp -rf ./config-pdms/server/checkdb.sh ./
    sed -i "s/TOKEN/$token/g" ./checkdb.sh
    sed -i "s/OLDSERVERNAME/$oldservername/g" ./checkdb.sh
    sed -i "s/OLDDATABASE/$dbname/g" ./checkdb.sh
    ./checkdb.sh
    if grep -q 'Online' ./config-pdms/server/checkdb-return.json; then
        echo "old database:"$dbname" exists"
    else
        echo "old database:"$dbname" not exists"
        result_derror=$(jq -r '.error.message' ./config-pdms/server/checkdb-return.json)
        echo $result_derror
        exit 10
    fi
done

# copy database
for dbname in $dbnames
do
    echo "begin to copy database"
    \cp -rf ./config-pdms/server/copydb-template.json ./config-pdms/server/copydb.json
    sed -i "s/OLDSERVERNAME/$oldservername/g" ./config-pdms/server/copydb.json
    sed -i "s/OLDDATABASE/$dbname/g" ./config-pdms/server/copydb.json

    \cp -rf ./config-pdms/server/copydb.sh ./
    sed -i "s/TOKEN/$token/g" ./copydb.sh
    sed -i "s/SERVERNAME/$newservername/g" ./copydb.sh
    sed -i "s/DATABASE/$dbname/g" ./copydb.sh
    ./copydb.sh

    result_copydb=$(jq -r '.operation' ./config-pdms/server/copydb-return.json)
    if [[ $result_copydb == null ]]; then
        echo "copy database:"$dbname" failed"
        result_failed=$(jq -r '.message' ./config-pdms/server/copydb-return.json)
        if [[ $result_failed != null ]]; then
            echo $result_failed
        fi
        result_failed=$(jq -r '.error.message' ./config-pdms/server/copydb-return.json)
        if [[ $result_failed != null ]]; then
            echo $result_failed
        fi
        echo $result_failed
        exit 11
    else
        echo "copy database:"$dbname" successfully"
    fi
done

echo "check if database finish copy"
for dbname in $dbnames
do
    \cp -rf ./config-pdms/server/checkdb.sh ./
    sed -i "s/TOKEN/$token/g" ./checkdb.sh
    sed -i "s/OLDSERVERNAME/$newservername/g" ./checkdb.sh
    sed -i "s/OLDDATABASE/$dbname/g" ./checkdb.sh
    sleep 120
    timesnum=1
    while [[ $timesnum -le 9 ]]; do
        echo "$timesnum times check"
        ./checkdb.sh
        if grep -q 'Online' ./config-pdms/server/checkdb-return.json; then
            echo "database "$dbname" finish copy"
            break
        else
            timesnum=$[$timesnum+1]
            sleep 120
            continue
        fi
    done
done

if [[ $timesnum -gt 9 ]]; then
    echo "timeout for copy database with 20 minutes, copy failed"
    exit 12
fi

echo "backup server and database successfully"
exit 0
