#!/bin/bash

sg=$1


# parse servicedatabase.json to get dbserver, dbuser, dbpass
echo "begin to parse servicedatabase.json"

file="./config-pdms/servicedatabase.json"
if [ -f "$file" ]
then
  echo "$file found."
  
  dbserver=$(jq -r '."plcm-sg-service-database"[0]."db-server"' ./config-pdms/servicedatabase.json)
  dbuser=$(jq -r '."plcm-sg-service-database"[0]."db-user"' ./config-pdms/servicedatabase.json)
  dbpass=$(jq -r '."plcm-sg-service-database"[0]."db-user-password"' ./config-pdms/servicedatabase.json)
  if [[ $dbserver == null || $dbuser == null || $dbpass == null ]]; then
    echo "use default"
  else
    echo "new server database info: "$dbserver" "$dbuser" "$dbpass
    # modify ./mnt/pdms/conf/$sg/db.json
    curserver=$(jq -r '."db-0"."address"' ./mnt/pdms/conf/$sg/db.json)
    curuser=$(jq -r '."db-0"."username"' ./mnt/pdms/conf/$sg/db.json)
    curpass=$(jq -r '."db-0"."password"' ./mnt/pdms/conf/$sg/db.json)
    sed -i "s/$curserver/$dbserver/g" ./mnt/pdms/conf/$sg/db.json
    sed -i "s/$curuser/$dbuser/g" ./mnt/pdms/conf/$sg/db.json
    sed -i "s/$curpass/$dbpass/g" ./mnt/pdms/conf/$sg/db.json
    echo "replaced db.json successfully"
    echo "begin to copy /mnt to agent"
    result_copy=$(ansible-playbook ./copy-mnt.yml -e deployment=CURAPP_DEPLOYMENT_NAME -e sgid=$sg)
    echo "$result_copy"
    if [[ $result_copy =~ "unreachable=0" && $result_copy =~ "failed=0" ]]
    then
      echo "copy ./mnt/pdms/conf/$sg successful"
    else
      echo "copy ./mnt/pdms/conf/$sg failed"
      exit 3
    fi
  fi
else
  echo "$file not found."
fi

### deploy service
echo "begin to deploy other service"
result_service=$(ansible-playbook ./marathon.yml --private-key=./config-pdms/id_rsa --user=plcm -e "jumphost=CURAPP_JUMPHOST_NAME" -e "state=deployed" -e "sgid=$sg")
echo "$result_service"
if [[ $result_service =~ "unreachable=0" && $result_service =~ "failed=0" ]]
then
    echo "deploy all service successful"
else
    echo "deploy all service failed"
    exit 4
fi

exit 0
