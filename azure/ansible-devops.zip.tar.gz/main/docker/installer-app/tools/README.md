### check server's existence
source ./check-server-existence.sh <short server name>
e.g. source ./check-server-existence.sh sgname-0-pdms-sql-server

### delete server
source ./delete-server.sh <short server name>
e.g. source ./delete-server.sh sgname-0-pdms-sql-server
