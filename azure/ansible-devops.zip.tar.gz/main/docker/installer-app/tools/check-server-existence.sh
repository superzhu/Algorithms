#!/bin/bash
servername=$1
if [ "$servername"x == ""x ]; then
    echo "please add server name"
    exit 1
fi

cd ../
pwd

echo "get token"
curl -X "POST" "https://login.microsoftonline.com/CURAPP_TENANT_ID/oauth2/token" \
-H "Cookie: flight-uxoptin=true; stsservicecookie=ests; x-ms-gateway-slice=productionb; stsservicecookie=ests" \
-H "Content-Type: application/x-www-form-urlencoded" \
--data-urlencode "client_id=CURAPP_CLIENT_ID" \
--data-urlencode "grant_type=client_credentials" \
--data-urlencode "client_secret=CURAPP_CLIENT_SECRET" \
--data-urlencode "resource=https://management.azure.com/" > ./config-pdms/server/token.json
token=$(jq -r '.access_token' ./config-pdms/server/token.json)
echo $token
if [ $token == null ];then
    echo "get token failed"
    exit 1
fi

echo "check $servername existence"
\cp -rf ./config-pdms/server/checkserver.sh ./
sed -i "s/TOKEN/$token/g" ./checkserver.sh
sed -i "s/OLDSERVERNAME/$servername/g" ./checkserver.sh
./checkserver.sh
if grep -q 'Ready' ./config-pdms/server/checkserver-return.json; then
    echo "$servername exists"
else
    echo "$servername not exists"
    result_error=$(jq -r '.error.message' ./config-pdms/server/checkserver-return.json)
    echo $result_error
    exit 1
fi

