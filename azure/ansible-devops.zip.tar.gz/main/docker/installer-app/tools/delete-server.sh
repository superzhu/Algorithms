#!/bin/bash
servername=$1
if [ "$servername"x == ""x ]; then
    echo "please add server name"
    exit 1
fi

cd ../
pwd

echo "get token"
curl -X "POST" "https://login.microsoftonline.com/CURAPP_TENANT_ID/oauth2/token" \
-H "Cookie: flight-uxoptin=true; stsservicecookie=ests; x-ms-gateway-slice=productionb; stsservicecookie=ests" \
-H "Content-Type: application/x-www-form-urlencoded" \
--data-urlencode "client_id=CURAPP_CLIENT_ID" \
--data-urlencode "grant_type=client_credentials" \
--data-urlencode "client_secret=CURAPP_CLIENT_SECRET" \
--data-urlencode "resource=https://management.azure.com/" > ./config-pdms/server/token.json
token=$(jq -r '.access_token' ./config-pdms/server/token.json)
echo $token
if [ $token == null ];then
    echo "get token failed"
    exit 1
fi

echo "delete sql server: "$servername
\cp -rf ./config-pdms/server/destroydbserver.sh ./
sed -i "s/TOKEN/$token/g" ./destroydbserver.sh
sed -i "s/SERVERNAME/$servername/g" ./destroydbserver.sh
./destroydbserver.sh

echo "check $servername existence"
\cp -rf ./config-pdms/server/checkserver.sh ./
sed -i "s/TOKEN/$token/g" ./checkserver.sh
sed -i "s/OLDSERVERNAME/$servername/g" ./checkserver.sh
./checkserver.sh
if grep -q 'Ready' ./config-pdms/server/checkserver-return.json; then
    echo "$servername still exists"
else
    echo "$servername has been deleted"
    result_error=$(jq -r '.error.message' ./config-pdms/server/checkserver-return.json)
fi

