#!/usr/bin/env bash

# open debug mode
set -x

HOST_DIR=/opt/polycom/pdms/installer
LOCAL_DIR=/opt/installer

VERSION=`cat $LOCAL_DIR/version.txt | grep -v "#" | xargs`

#if [ -f $HOST_DIR/$VERSION/version.txt ]; then
#    echo "installed already. ignore. "
#    exit 0
#fi

#if [ -f $HOST_DIR/not_mounted.txt ]; then
#    echo "$HOST_DIR not mounted. please mount the docker with '-v /opt/polycom/:/opt/polycom/'"
#    exit 0
#fi

mkdir -p $HOST_DIR/$VERSION

echo "installing to $HOST_DIR/$VERSION/ ... "

\cp $LOCAL_DIR/* $HOST_DIR/$VERSION/ -rf

echo "installation done. "

ls -l $HOST_DIR/$VERSION





