#!/bin/bash

echo "STRATUS starting cloud-init deployment"

export STRATUS_MACHINE_ID=`cat /etc/machine-id`
export STRATUS_HOSTNAME=`hostname`
export STRATUS_IPADDRESS=`ip-detect`
export STRATUS_VM_UNIQUE_NAME=${STRATUS_RG_NAME}_${STRATUS_HOSTNAME}

if [ "$STRATUS_VM_TYPE" == "agent" ]
then
  echo "STRATUS fix core_pattern file"
  echo '/var/crash/core.%h.%e.%t' > /proc/sys/kernel/core_pattern

  echo "STRATUS Installing docker-gc"
  wget --no-check-certificate https://plcmstratusfilestorage.blob.core.windows.net/publicblobstorage/docker-gc
  wget --no-check-certificate https://plcmstratusfilestorage.blob.core.windows.net/publicblobstorage/docker-gc-daily-cron
  chmod +x docker-gc
  mv docker-gc /usr/sbin
  chmod +x docker-gc-daily-cron
  mv docker-gc-daily-cron /etc/cron.daily
fi

echo "STRATUS Fixing NTP Configuration"
echo -e "[Time]\nNTP=0.polycom.pool.ntp.org 1.polycom.pool.ntp.org 2.polycom.pool.ntp.org 3.polycom.pool.ntp.org\nFallbackNTP=ntp.ubuntu.com\n" > /etc/systemd/timesyncd.conf
systemctl restart systemd-timesyncd

echo "STRATUS Installing Filebeat"

#download files
wget --no-check-certificate https://plcmstratusfilestorage.blob.core.windows.net/publicblobstorage/filebeat-5.0.0-amd64.deb
wget --no-check-certificate https://plcmstratusfilestorage.blob.core.windows.net/publicblobstorage/filebeat-$STRATUS_VM_TYPE.0.1.yml

#install filebeat
dpkg -i filebeat-5.0.0-amd64.deb

#compile the template for filebeat config
TEMPLATE=filebeat-$STRATUS_VM_TYPE.0.1.yml
OUTPUT=/etc/filebeat/filebeat.yml
perl -pe 's;(\\*)(\$([a-zA-Z_][a-zA-Z_0-9]*)|\$\{([a-zA-Z_][a-zA-Z_0-9]*)\})?;substr($1,0,int(length($1)/2)).($2&&length($1)%2?$2:$ENV{$3||$4});eg' $TEMPLATE > $OUTPUT

#add the hosts names for kafka clusters
echo "192.168.50.8 analytics-kafka-scus-1
192.168.50.7 analytics-kafka-scus-2
192.168.50.9 analytics-kafka-scus-3" >> /etc/hosts

#start filebeat
systemctl enable filebeat
systemctl start filebeat

echo "STRATUS Installing Telegraf"

#download files
wget --no-check-certificate https://plcmstratusfilestorage.blob.core.windows.net/publicblobstorage/telegraf_1.1.2_amd64.deb
wget --no-check-certificate https://plcmstratusfilestorage.blob.core.windows.net/publicblobstorage/telegraf.0.1.yml
wget --no-check-certificate https://plcmstratusfilestorage.blob.core.windows.net/publicblobstorage/telegraf-mesos-$STRATUS_VM_TYPE.0.1.yml

#install
dpkg -i telegraf_1.1.2_amd64.deb

if [ "$STRATUS_VM_TYPE" == "agent" ]
then
  # patch it if its agents
  echo "STRATUS patching the telegraf binary"
  wget --no-check-certificate https://plcmstratusfilestorage.blob.core.windows.net/publicblobstorage/telegraf-1.1.2.patched.tgz
  tar -xvf telegraf-1.1.2.patched.tgz
  cp -f telegraf /usr/bin
fi

#compile the template for telegraf config
TEMPLATE=telegraf.0.1.yml
OUTPUT=/etc/telegraf/telegraf.conf
perl -pe 's;(\\*)(\$([a-zA-Z_][a-zA-Z_0-9]*)|\$\{([a-zA-Z_][a-zA-Z_0-9]*)\})?;substr($1,0,int(length($1)/2)).($2&&length($1)%2?$2:$ENV{$3||$4});eg' $TEMPLATE > $OUTPUT

#compile the template for telegraf mesos config
TEMPLATE=telegraf-mesos-$STRATUS_VM_TYPE.0.1.yml
OUTPUT=/etc/telegraf/telegraf.d/mesos.conf
perl -pe 's;(\\*)(\$([a-zA-Z_][a-zA-Z_0-9]*)|\$\{([a-zA-Z_][a-zA-Z_0-9]*)\})?;substr($1,0,int(length($1)/2)).($2&&length($1)%2?$2:$ENV{$3||$4});eg' $TEMPLATE > $OUTPUT

#start
systemctl enable telegraf
systemctl restart telegraf

echo "STRATUS Installing Consul"

# donwload files
wget --no-check-certificate https://plcmstratusfilestorage.blob.core.windows.net/publicblobstorage/consul_0.7.4_linux_amd64.zip
wget --no-check-certificate https://plcmstratusfilestorage.blob.core.windows.net/publicblobstorage/consul.0.1.conf
wget --no-check-certificate https://plcmstratusfilestorage.blob.core.windows.net/publicblobstorage/consul.0.1.service
wget --no-check-certificate https://plcmstratusfilestorage.blob.core.windows.net/publicblobstorage/consul.0.1.logrotate

mkdir /etc/consul.d
#compile the template for consul config
TEMPLATE=consul.0.1.conf
OUTPUT=/etc/consul.d/consul.conf
perl -pe 's;(\\*)(\$([a-zA-Z_][a-zA-Z_0-9]*)|\$\{([a-zA-Z_][a-zA-Z_0-9]*)\})?;substr($1,0,int(length($1)/2)).($2&&length($1)%2?$2:$ENV{$3||$4});eg' $TEMPLATE > $OUTPUT

#copy the consul systemd script
mv consul.0.1.service /etc/systemd/system/consul.service
chmod 644 /etc/systemd/system/consul.service
mkdir /var/log/consul/

#copy the logrotate script
mv consul.0.1.logrotate /etc/logrotate.d/consul

# install consul
unzip consul_0.7.4_linux_amd64.zip
mv consul /usr/bin

# start consul
systemctl enable consul
systemctl start consul

echo "STRATUS done all tasks"
