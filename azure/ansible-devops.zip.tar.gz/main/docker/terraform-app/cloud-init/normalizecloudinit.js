var fs = require('fs');


var masterList = [
  null,
  "[\"', reference(variables('masterVMNic')[0]).ipConfigurations[0].properties.privateIPAddress,'\"]\\n",
  null,
  "[\"', reference(variables('masterVMNic')[0]).ipConfigurations[0].properties.privateIPAddress,'\", \"', reference(variables('masterVMNic')[1]).ipConfigurations[0].properties.privateIPAddress,'\", \"', reference(variables('masterVMNic')[2]).ipConfigurations[0].properties.privateIPAddress,'\"]\\n"
];

var packageGUID = [
  null,
  "556978041b6ed059cc0f474501083e35ea5645b8",
  null,
  "1eb387eda0403c7fd6f1dacf66e530be74c3c3de"
];

// Single Master Template
renderTemplate(1,"dcostemplate_single_master.json");

// Three Master Template
renderTemplate(3,"dcostemplate.json");

function renderTemplate(masterCount, outputfilename) {

  var template = fs.readFileSync("./dcostemplate.json", "utf8")
  var agentdata = (JSON.parse(fs.readFileSync("./dcos-agent-cloud-init.json", "utf8")));
  var masterdata = (JSON.parse(fs.readFileSync("./dcos-master-cloud-init.json", "utf8")));

  fixCloudInit(masterCount,agentdata);
  // fs.writeFileSync("output/agenttpl.json",JSON.stringify(agentdata,null,2));
  var mydata = convertToString(agentdata);
  template = template.replace(/<<AGENT_CLOUD_INIT>>/,mydata);


  fixCloudInit(masterCount,masterdata);
  // fs.writeFileSync("output/mastertpl.json",JSON.stringify(masterdata,null,2));
  var mydata = convertToString(masterdata);
  template = template.replace(/<<MASTER_CLOUD_INIT>>/,mydata);

  fs.writeFileSync("../modules/production/global-dcos/"+outputfilename,template);
  fs.writeFileSync("../modules/production/tenant-dcos/"+outputfilename,template);

}

function convertToString(jsondata) {
  var mydata = JSON.stringify(jsondata);
  mydata = mydata.replace(/\\\"/g,"&");
  mydata = mydata.replace(/\"/g,"\\\"");
  mydata = mydata.replace(/&/g,"\\\\\\\"");
  return mydata;
}

function fixCloudInit(masterCount,data) {

  for(var i=0; i<data.write_files.length; i++) {
    if( data.write_files[i].path === "/etc/mesosphere/setup-packages/dcos-provider-azure--setup/etc/master_list") {
      data.write_files[i].content = masterList[masterCount];
    } else if (data.write_files[i].path === "/etc/mesosphere/setup-flags/cluster-packages.json") {
      data.write_files[i].content = "[\"dcos-config--setup_"+packageGUID[masterCount]+"\", \"dcos-metadata--setup_"+packageGUID[masterCount]+"\"]\\n";
    }

  }

};
