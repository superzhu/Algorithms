# Terraform Deployment for Azure

## Overview
This project allows you to create infrastructure in Azure for various Stratus environments.

## Getting Started

[Learn about Terraform](https://www.terraform.io/intro/index.html)

[Install instructions](https://www.terraform.io/intro/getting-started/install.html)

Install terraform version **0.8.8**

Make sure that the Environment Variable `ARM_CLIENT_SECRET` is set.

### Directory Structure

Directory | Description
---|---
cloud-init | contains the cloud-init scripts for Global and Tenant DCOS deployment.
common-infra | terraform configs for common infrastucture, such as DNS Zone and Docker Container Registry
env | terraform configs for each environment
modules | terraform reusable modules that describe each element of the deployment.

## Creating an Environment

To create an environment, create a directory under `env` and copy the `main.tf` and `terraform.tfvars` file from one of the existing environments.

Edit the `terraform.tfvars` to give this new environment a unique name. Prefereable keep the name small as it is used as a prefix for most assets and resource groups. You can also change the SSH Key that is used to SSH into the Jump Host and other VMs.

To start deploying this new environment, run the following commands:

Step 1: Get the required modules
```
terraform get
```
Step 2: Plan and verify the deployment
```
terraform plan
```
The above command should print out all the infra assets that will be created in Azure. Please go through the list to ensure they are as expected with the correct names.
Step 3: Execute the plan
```
terraform apply
```
When the plan is created, terraform will create one or two .tfstate files which contains details on what was created in Azure. These tfstate files must be checked in to GIT to ensure that we can manage these resoruces via terraform.

> **Note** The terraform apply command will take approximately 30 minutes to complete. It will fail during creation of VNET Peering about 25 minutes into the process. Just run the terraform apply command again to complete it.

Once the assets are created, your VMs are ready for the Ansible deployment of various software on those VMs.

## Adding DNS entries for a new Environment

After creating the environment, you will need to create the DNS entries to use it.

Step 1: Add DNS configuration for the environment
Edit the `common-infra\envs-dev.tf` file and make a copy of an existing module. Name the new module after the environment. The module looks as follows:

```
module "dns-<envName>" {

  source = "../modules/base/dns"

  envName              = "<envName>"
  jumpHostIpAddress    = "<public IP>"
  frontEndIpAddress    = "<public IP>"

  zone_name            = "${azurerm_dns_zone.dnszone.name}"
  resource_group_name  = "${azurerm_resource_group.rg.name}"

}
```

Fill in the details about the environment name and the public IP addresses allocated to the jump host and the front end load balancer for that environment.

Step 2: Get the required modules.
In the `common-infra` directory:
```
terraform get
```
Step 3: Plan and verify the deployment
```
terraform plan
```
The above command should print out all the dns entries. Please check to make sure they are as expected with the correct names.
Step 4: Execute the plan
```
terraform apply
```
When the plan is created, terraform will change the .tfstate files which contains details on what was changed in Azure. These tfstate files must be checked in to GIT to ensure that we can manage these resoruces via terraform.

## Destroying an Environment

To destroy an environment cd into that directory under `env` and run the following commands

Step 1: Plan and verify the changes
```
terraform plan --destroy
```
The above command should print out all the infra assets that will be deleted in Azure. Please go through the list to ensure they are as expected with the correct names.
Step 2: Execute the plan
```
terraform destroy
```

## Modifing an Environment

If anything is modified in the modules or the configuration of an environment. Use the commands below to apply those changes to Azure:

Step 1: Plan and verify the deployment
```
terraform plan
```
The above command should print out all the infra assets that will be modified in Azure. Please go through the list to ensure they are as expected with the correct names.
Step 2: Execute the plan
```
terraform apply
```
When the plan is modified, terraform will change the .tfstate files which contains details on what was changed in Azure. These tfstate files must be checked in to GIT to ensure that we can manage these resoruces via terraform.
