#!/usr/bin/env bash

function help
{
    echo "Usage: $0 plan/apply -var-file ../../../../EnvParams/terraform/app/conf/pdmsjhtest.tfvars -state pdmsjhtest.tfstate"
}

if [ $# -eq 0 ]; then
    help
    exit 1
fi

set -x

terraform $@

