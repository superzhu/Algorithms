package com;

import java.nio.charset.Charset;
import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class PdmsBase
{
    private static final String AESCRYPTOALGORITHM = "AES";
    private static final String AESSECURERANDOMALGORITHM = "SHA1PRNG";
    private static final String AESCRYPTPASSWORD = "Polycom!123";
    private static final Charset CHARSET = Charset.forName("UTF-8");
    private static byte[] KEYBYTES = AESCRYPTPASSWORD.getBytes(CHARSET);

    public String encryptAES(String content)
    {
        try
        {
            byte[] byteContent = content.getBytes(CHARSET);
            SecretKey secretKey = getKey(AESCRYPTPASSWORD);
            byte[] byteKey = secretKey.getEncoded();
            SecretKeySpec key = new SecretKeySpec(byteKey, AESCRYPTOALGORITHM);
            Cipher cipher = Cipher.getInstance(AESCRYPTOALGORITHM);
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] encryptResult = cipher.doFinal(byteContent);
            String hexStr = java.util.Base64.getUrlEncoder().encodeToString(encryptResult);
            return hexStr;
        }
        catch (Exception e)
        {
        }
        return null;
    }

    public String decryptAES(String hexString)
    {
        try
        {
            byte[] content = java.util.Base64.getUrlDecoder().decode(hexString);
            SecretKey secretKey = getKey(AESCRYPTPASSWORD);
            byte[] byteKey = secretKey.getEncoded();
            SecretKeySpec key = new SecretKeySpec(byteKey, AESCRYPTOALGORITHM);
            Cipher cipher = Cipher.getInstance(AESCRYPTOALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, key);
            byte[] decryptResult = cipher.doFinal(content);
            String strResult = new String(decryptResult);
            return strResult;
        }
        catch (Exception e)
        {
        }
        return null;
    }

    private static SecretKey getKey(String strpwd)
    {
        try
        {
            KeyGenerator keyGenerator = KeyGenerator.getInstance(AESCRYPTOALGORITHM);
            SecureRandom secureRandom = SecureRandom.getInstance(AESSECURERANDOMALGORITHM);
            secureRandom.setSeed(strpwd.getBytes());
            keyGenerator.init(128, secureRandom);
            return keyGenerator.generateKey();
        }
        catch (Exception e)
        {
            throw new RuntimeException("keyGenerator generate key error");
        }
    }

    public static void main(String[] args)
    {
        if (args.length >= 2)
        {
            PdmsBase pb = new PdmsBase();
            String method = args[0];
            String content = args[1];
            switch (method)
            {
                case "encryptAES":
                    System.out.println(pb.encryptAES(content));
                    break;
                case "decryptAES":
                    System.out.println(pb.decryptAES(content));
                    break;
            }

        }
        else
        {
            System.out.println("ERROR");
        }
    }

}
