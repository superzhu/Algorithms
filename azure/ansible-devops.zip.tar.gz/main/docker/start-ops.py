#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, sys, os.path, stat, shutil, getopt
import time, datetime, json
import subprocess, jwt, requests


opts, args = getopt.getopt(sys.argv[1:], 'h', ["version=", "appenv="])
version=''
appenv=''

def usage():
    print('start-ops.py --version=<version> --appenv=<appenv>')
    
if len(sys.argv) <= 1:
    usage()
    raise SystemExit('failed')
    
for op, value in opts:
    if op == "--version":
        version = value
        print("version is: ", version)
    elif op == "--appenv":
        appenv = value
        print("appenv is : ", appenv)
    else:
        usage()
        raise SystemExit('failed')

if (not version) or (not appenv):
    usage()
    raise SystemExit('failed')
    
class InstallerAPI:
    
    cluster_base_url = 'https://{0}/api/rest/rprm/cluster'
    pdms_verify=False
    
    def __init__(self, address):
        self.cluster_base_url = self.cluster_base_url.format(address)
        
    def create_token(self):
        try:
            # get pdms.json
            with open(os.path.join('./EnvParams', appenv, 'ops-pdms.json'), 'r') as f:
                data = json.load(f)
                
            pdms_secrets=data['secrets']
            pdms_issuer=data['issuer']
            pdms_audience=data['audience']
            pdms_uid=data['uid']
            
            payload = {
                "iss": pdms_issuer,
                "exp": int(time.time()) + 86400 * 365,
                "aud": pdms_audience,
                "uid": pdms_uid
            }
            token = jwt.encode(payload, pdms_secrets, algorithm='HS256')
            return token
        except BaseException as e:
            return None
        else:
            pass
    
    def get_tid(self):
        try:
            with open(os.path.join('./EnvParams', appenv, 'ops.json'), 'r') as f:
                data = json.load(f)
            pdms_tid=data['orion_tid']
            tid = pdms_tid
            return tid
        
        except BaseException as e:
            return None
        else:
            pass

    def readAPPCluster(self, clusterid):
        token=self.create_token()
        tid=self.get_tid()
        if token == None or tid == None:
            print('token or tid is None')
            return False
        headers = {'X-CA-JWT': token, 'X-CA-Tenant-ID': tid, 'Accept': 'application/vnd.plcm.plcm-pdms-cluster+json'}
        respText = ''
        try:
            r = requests.get(self.cluster_base_url  + '/{0}'.format(clusterid), headers=headers, verify=self.pdms_verify, timeout=10)
            respText = r.text
            r.raise_for_status()
        except requests.RequestException as e:
            print(e)
            print(respText)
            return False
        else:
            if r.status_code == 204:
                return False
            result = r.json()
            if result and result['cluster-id'] == clusterid:
                return result
            else:
                return False
      
    

def parseOPSJson():
    try:
        with open(os.path.join('./EnvParams', appenv, 'ops.json'), 'r') as f:
            opsdata = json.load(f)
        ops_address = opsdata['ops_vm_pubip'] + ':443'
        ops_cluster_id = opsdata['ops_cluster_id']
        
        ins_api = InstallerAPI(ops_address)
        cluster_detail = ins_api.readAPPCluster(ops_cluster_id)
        if not cluster_detail:
            print('cluster_detail is None')
            raise SystemExit('failed')
            
        clusterExtend = json.loads(cluster_detail['extend-attribute'])
        
        for key,value in clusterExtend.items():
            if key == 'subscription.subscription name': 
                opsdata['credentials_id'] = value
            elif key == 'subscription.subscription id': 
                opsdata['subscription_id'] = value    
            elif key == 'subscription.client-id': 
                opsdata['client_id'] = value  
            elif key == 'subscription.client-secret': 
                opsdata['client_secret'] = value  
            elif key == 'subscription.tenant-id': 
                opsdata['tenant_id'] = value  
            elif key == 'operation.env-type': 
                opsdata['cert_mode'] = value   
            elif key == 'operation.operation-db-server-name': 
                opsdata['ops_server_name'] = value   
            elif key == 'operation.operation-jumphost-name': 
                opsdata['jumphost'] = value   
            elif key == 'operation.operation-resource-group-name': 
                opsdata['resourcegroup_infra'] = value   
            elif key == 'operation.operation-service-group-name': 
                opsdata['ops_sg'] = value   
            elif key == 'operation.operation-vm-host-name': 
                opsdata['ops_vm_hostname'] = value  
            elif key == 'operation.operation-vm-private-ip-address': 
                opsdata['ops_vm_priip'] = value  
            else:
                continue
        
        opsdata['location'] = cluster_detail['location']
        with open(os.path.join('./EnvParams', appenv, 'ops.json'), 'w') as f:
            json.dump(opsdata, f, indent=2)
        
        print('end of parseOPSJson')
        return True
        
    except BaseException as e:
        return False
    else:
        pass

def generateOPS():
    try:
        print('copy ops-vm, ops-pdms.json, ops-idrsa, chmod 600 id_rsa')
        if os.path.exists('./work/ops'):
            print('ERROR -- ./work/ops is already exists, please exit and run installer container again')
            return False
        shutil.copytree('./ops-vm', './work/ops')
        shutil.copy(os.path.join('./EnvParams', appenv, 'ops-pdms.json'), './work/ops/config-pdms/sg/pdms.json')
        shutil.copy(os.path.join('./EnvParams', appenv, 'ops-idrsa'), './work/ops/config-pdms/id_rsa')
        os.chmod('./work/ops/config-pdms/id_rsa', stat.S_IREAD|stat.S_IWRITE)
        
        print('replace all capital parameters of ops script')
        # python has no better method to replace, so use shell
        
        paramdict = {
            'CUR_OPS_VM_HOSTNAME': 'ops_vm_hostname',
            'CUR_JUMPHOST_NAME': 'jumphost',
            'CUR_RESOURCEGROUP_INFRA': 'resourcegroup_infra',
            'CUR_OPS_VM_PRIIP': 'ops_vm_priip',
            'CUR_OPS_VM_PUBIP': 'ops_vm_pubip',
            'CUR_OPSSG_NAME': 'ops_sg',
            'CUR_CERT_MODE': 'cert_mode',
            'CUR_CREDENTIALS_ID': 'credentials_id',
            'CUR_SUBSCRIPTION_ID': 'subscription_id',
            'CUR_CLIENT_ID': 'client_id',
            'CUR_CLIENT_SECRET': 'client_secret',
            'CUR_TENANT_ID': 'tenant_id',
            'CUR_CLUSTER_ID': 'ops_cluster_id',
            'CUR_LOCATION': 'location'
            }
        
        with open(os.path.join('./EnvParams', appenv, 'ops.json'), 'r') as f:
            opsdata = json.load(f)
        filename = './work/ops/'   
            
        for key, value in paramdict.items():
            print(key, value, opsdata[value])
            replacecmd = 'sed -i "s%' + key + '%' + opsdata[value] + '%g" `grep -rl "' + key + '" ' + filename + '`'
            print(replacecmd)
            ( n, output ) = subprocess.getstatusoutput(replacecmd)
            if n != 0 :
                print('ERROR -- replace parameters failed, ', output)
                return False
        
        replacecmd = 'sed -i "s%' + 'CUR_APP_ENV' + '%' + appenv + '%g" `grep -rl "' + 'CUR_APP_ENV' + '" ' + filename + '`'
        print(replacecmd)
        ( n, output ) = subprocess.getstatusoutput(replacecmd)
        if n != 0 :
            print('ERROR -- replace parameters failed, ', output)
            return False
                    
        print('end of generateOPS')
        return True
        
    except BaseException as e:
        return False
    else:
        pass

if __name__ == "__main__":
    
    print('current user: ', os.environ['USER'])
    os.chdir(os.path.join('/opt/polycom/pdms/installer', version))
    print('working path: ', os.getcwd())
    
    with open(os.path.join('./EnvParams', appenv, 'ops.json'), 'r') as f:
        opsdata = json.load(f)
    
    print('check if all config files are exist')
    if (not os.path.isfile(os.path.join('./EnvParams', appenv, 'ops.json')) 
        or not os.path.isfile(os.path.join('./EnvParams', appenv, 'ops-pdms.json'))
        or not os.path.isfile(os.path.join('./EnvParams', appenv, 'ops-idrsa'))
        or not os.path.isfile(os.path.join('./EnvParams', appenv, 'app-idrsa'))
        or not os.path.isfile(os.path.join('./EnvParams', appenv, 'app-pdms.json'))):
        print('ERROR -- files under EnvParams is incomplete')
        raise SystemExit('failed')
    
    print('parse ops.json under ./EnvParams/', appenv, 'ops.json')
    if not parseOPSJson():
        print('ERROR -- parseOPSJson failed')
        raise SystemExit('failed')
    
    print('generate operation script')
    if not generateOPS():
        print('ERROR -- generateOPS failed')
        raise SystemExit('failed')
    
    print('generate operation script successfully, will execute preparing script')
    os.chdir('./work/ops/')
    print('working path: ', os.getcwd())
    
    pythoncmd = "nohup python `pwd`/go.py --address=" + opsdata['ops_vm_pubip'] + ":443 > /dev/null 2>&1 &"
    listcmd = ['./credentials_add.sh', './go-prepare-existing-mnt.sh', pythoncmd]
    for index in range(len(listcmd)):
        preparecmd = listcmd[index]
        print("execute: ", preparecmd)
        ( n, output ) = subprocess.getstatusoutput(preparecmd)
        if n != 0 :
            print('ERROR -- execute ', preparecmd, ' failed: ', output) 
            raise SystemExit('failed')
    
    print('end successfully')    
    sys.exit()
    
    
    
    
    
    
    
    
    
    
    