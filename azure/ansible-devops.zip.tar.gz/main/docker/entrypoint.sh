#!/bin/bash

echo "docker run. version: `cat /opt/installer/version.txt | grep -v "#" | xargs`"
#echo "appenv: $1"
echo "appenv: $appenv"

if [[ "$appenv"x == ""x ]]; then
    echo "wrong env parameter"
    exit 1
fi

if [ ! -d "/opt/installer/EnvParams/$appenv" ]; then
    echo "wrong env parameter"
    exit 1
fi

LOCAL_DIR=/opt/installer
VERSION=`cat $LOCAL_DIR/version.txt | grep -v "#" | xargs`
FILE_DIR=/opt/polycom/pdms/installer/$VERSION

id -u plcm

if [ $? -ne 0 ]; then
    echo "user plcm not mapped. "
    echo "to use plcm, run docker with '-v /etc/passwd:/etc/passwd -v /etc/group:/etc/group' "
#    echo "will use root to install files. "
#    /opt/installer/install-to-host.sh
else
    su plcm -c /opt/installer/install-to-host.sh
    chown -R plcm:plcm /opt
#    su plcm -c "$FILE_DIR/ops-vm.sh -f /opt/installer/EnvParams/$appenv/ops.json --pdmscfg /opt/installer/EnvParams/$appenv/ops-pdms.json --idrsa /opt/installer/EnvParams/$appenv/ops-idrsa --appenv $appenv > /opt/polycom/pdms/startlog.txt"
    su plcm -c "$FILE_DIR/start-ops.py --version $VERSION --appenv $appenv > $FILE_DIR/start-ops.log"
fi

chown -R plcm:plcm /opt
su plcm

/bin/bash

